package main

import (
	"bytes"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
)

type FileType int

const (
	FILE_NONE = iota
	FILE_C
	FILE_ASM
	FILE_OBJ
	FILE_AR
	FILE_DSO
)

type CompilerOptions struct {
	opt_E       bool
	opt_c       bool
	opt_cc1     bool
	opt_S       bool
	opt_s       bool
	opt_o       string
	opt_I       IncludePaths
	opt_D       Defines
	opt_U       Undefines
	opt_fcommon bool
	opt_preI    PreIncludes
	opt_x       FileType
	opt_l       Libraries
	opt_M       bool
	opt_MF      string
	opt_MP      bool
	opt_MT      MakeRuleTargets
	opt_MD      bool
	opt_MQ      bool
	opt_MMD     bool
	opt_fpic    bool
	opt_static  bool
	opt_shared  bool
	opt_L       LibDirs
	opt_Wl      string
	opt_xlinker XLinkers
}

var CC1 string

var opt_E_ptr = flag.Bool("E", false, "")
var opt_S_ptr = flag.Bool("S", false, "")
var opt_s_ptr = flag.Bool("s", false, "")
var opt_c_ptr = flag.Bool("c", false, "")
var opt_cc1_ptr = flag.Bool("cc1", false, "")
var opt_hash_hash_hash_ptr = flag.Bool("###", false, "dump subprocess' command line")
var opt_cc1_input_ptr = flag.String("cc1-input", "", "base file (for subprocess)")
var opt_cc1_output_ptr = flag.String("cc1-output", "", "output file (for subprocess)")
var opt_o_ptr = flag.String("o", "", "")
var opt_fcommon_ptr = flag.Bool("fcommon", true, "")
var opt_fnocommon_ptr = flag.Bool("fno-common", false, "")
var opt_x_ptr = flag.String("x", "none", "")
var opt_M_ptr = flag.Bool("M", false, "")
var opt_MF_ptr = flag.String("MF", "", "")
var opt_MP_ptr = flag.Bool("MP", false, "")
var opt_MD_ptr = flag.Bool("MD", false, "")
var opt_MQ_ptr = flag.Bool("MQ", false, "")
var opt_MMD_ptr = flag.Bool("MMD", false, "")
var opt_fpic_ptr = flag.Bool("fpic", false, "")
var opt_fpic2_ptr = flag.Bool("fPIC", false, "")
var opt_static_ptr = flag.Bool("static", false, "")
var opt_shared_ptr = flag.Bool("shared", false, "")
var opt_Wl_ptr = flag.String("Wl", "", "")

var base_file string
var output_file string

var input_paths []string
var tmpfiles []string

var g_std_include_paths []string

type IncludePaths []string

var include_paths IncludePaths

func (i *IncludePaths) String() string {
	return strings.Join(*i, ", ")
}

func (i *IncludePaths) Set(value string) error {
	*i = append(*i, value)
	return nil
}

type Defines map[string]string

var defines Defines = make(map[string]string)

func (d *Defines) String() string {
	var bld strings.Builder
	for k, v := range *d {
		bld.WriteString(fmt.Sprintf("%s=%s ", k, v))
	}
	return bld.String()
}

func (d *Defines) Set(kv string) error {
	var k, v string
	eq := strings.IndexByte(kv, '=')
	if eq != -1 {
		k, v = kv[:eq], kv[eq+1:]
	} else {
		k, v = kv, "1"
	}
	defines[k] = v
	return nil
}

type Undefines []string

var undefines Undefines

func (u *Undefines) String() string {
	return strings.Join(*u, ", ")
}

func (u *Undefines) Set(value string) error {
	*u = append(*u, value)
	return nil
}

type IDirAfters []string

var idir_afters IDirAfters

func (i *IDirAfters) String() string {
	return strings.Join(*i, ", ")
}

func (i *IDirAfters) Set(value string) error {
	*i = append(*i, value)
	return nil
}

type Libraries []string

var libraries Libraries

func (l *Libraries) String() string {
	return strings.Join(*l, ", ")
}

func (l *Libraries) Set(value string) error {
	*l = append(*l, value)
	return nil
}

type MakeRuleTargets []string

var makeruletargets MakeRuleTargets

func (mrt *MakeRuleTargets) String() string {
	return strings.Join(*mrt, ", ")
}

func (mrt *MakeRuleTargets) Set(value string) error {
	*mrt = append(*mrt, value)
	return nil
}

func append_idirafters() {
	include_paths = append(include_paths, idir_afters...)
}

type PreIncludes []string

var preincludes PreIncludes

func (i *PreIncludes) String() string {
	return strings.Join(*i, ", ")
}

func (i *PreIncludes) Set(value string) error {
	*i = append(*i, value)
	return nil
}

type LibDirs []string

var libdirs LibDirs

func (l *LibDirs) String() string {
	return strings.Join(*l, ", ")
}

func (l *LibDirs) Set(value string) error {
	*l = append(*l, value)
	return nil
}

type XLinkers []string

var xlinkers XLinkers

func (l *XLinkers) String() string {
	return strings.Join(*l, ", ")
}

func (l *XLinkers) Set(value string) error {
	*l = append(*l, value)
	return nil
}

var opt_O_ignored = flag.String("O", "", "")
var opt_Wall_ignored = flag.String("Wall", "", "")
var opt_g_ignored = flag.String("g", "", "")
var opt_std_ignored = flag.String("std", "", "")
var opt_freestanding_ignored = flag.String("ffreestanding", "", "")
var opt_fnobuiltin_ignored = flag.String("fno-builtin", "", "")
var opt_fomitframepointer_ignored = flag.String("fno-omit-frame-pointer", "", "")
var opt_fnostackprotector_ignored = flag.String("fno-stack-protector", "", "")
var opt_fnostrictaliasing_ignored = flag.String("fno-strict-aliasing", "", "")
var opt_m64_ignored = flag.String("m64", "", "")
var opt_mnoredzone_ignored = flag.String("mno-red-zone", "", "")
var opt_w_ignored = flag.String("w", "", "")

func usage() {
	fmt.Fprintf(os.Stderr, "petitecc [ -o=<path> ] [other options] <file>\n")
	fmt.Fprintf(os.Stderr, " <file> file to compile, - means stdin\n")
	fmt.Fprintf(os.Stderr, " -o=<path> output path, - means stdout\n")
	fmt.Fprintf(os.Stderr, " -S compile to assembly\n")
	fmt.Fprintf(os.Stderr, " -s omit all symbol information from the output file\n")
	fmt.Fprintf(os.Stderr, " -c compile to object files\n")
	fmt.Fprintf(os.Stderr, " -E preprocess only; do not compile, assemble or link\n")
	fmt.Fprintf(os.Stderr, " -I=path Add directory to include search path (can be used multiple times)\n")
	fmt.Fprintf(os.Stderr, " -include=<file> Preinclude file to all compilations (can be used multiple times)\n")
	fmt.Fprintf(os.Stderr, " -idirafter=path Add directory to include search path after other includes (can be used multiple times)\n")
	fmt.Fprintf(os.Stderr, " -D=key or -D=key=value Add preprocessor define (without value implicit value is 1)\n")
	fmt.Fprintf(os.Stderr, " -U=key Remove preprocessor define\n")
	fmt.Fprintf(os.Stderr, " -fcommon traditional handling of uninitialized global variables (default)\n")
	fmt.Fprintf(os.Stderr, " -fno-common modern handling of uninitialized global variables\n")
	fmt.Fprintf(os.Stderr, " -x=<type> specify the source language of input files (c / assembler / none). none is default -> determines from file extension.\n")
	fmt.Fprintf(os.Stderr, " -l=<lib> link to a library <lib> (can be used multiple times)\n")
	fmt.Fprintf(os.Stderr, " -M generate makefile dependency rule for source files to stdout\n")
	fmt.Fprintf(os.Stderr, " -MF=<file> generate makefile dependency rule for source files to specific file\n")
	fmt.Fprintf(os.Stderr, " -MP adds a dummy (phony) target for each dependency file\n")
	fmt.Fprintf(os.Stderr, " -MT=<target> set the target name of generated dependency rule (can be used multiple times)\n")
	fmt.Fprintf(os.Stderr, " -MD generate makefile dependency rules to .d file as part of normal compilation\n")
	fmt.Fprintf(os.Stderr, " -MQ helper flag for -MT, automatically escapes (-MT's) characters that have special meaning in makefiles\n")
	fmt.Fprintf(os.Stderr, " -MMD identical to -MD, but ignores system header files (like <stdio.h>)\n")
	fmt.Fprintf(os.Stderr, " -fpic (or fPIC) generate position independent code (PIC)\n")
	fmt.Fprintf(os.Stderr, " -static create a statically linked executable\n")
	fmt.Fprintf(os.Stderr, " -shared compile to shared object (.so) file\n")
	fmt.Fprintf(os.Stderr, " -L=path Add directory to library search path (can be used multiple times)\n")
	fmt.Fprintf(os.Stderr, " -Wl=args,for,linker,separated,by,commas\n")
	fmt.Fprintf(os.Stderr, " -Xlinker=<arg> another way to pass linker arguments (can be used multiple times)\n")
}

func add_default_include_paths(argv0 string) {
	var std_inc_paths []string

	// We expect that chibicc-specific include files are installed
	// to ./include relative to argv[0].
	std_inc_paths = append(std_inc_paths, fmt.Sprintf("%s/include", filepath.Dir(argv0)))

	// Add standard include paths.
	std_inc_paths = append(std_inc_paths, "/usr/local/include")
	std_inc_paths = append(std_inc_paths, "/usr/include/x86_64-linux-gnu")
	std_inc_paths = append(std_inc_paths, "/usr/include")

	for _, s := range std_inc_paths {
		include_paths = append(include_paths, s)

		// Keep a copy of the standard include paths for -MMD option.
		g_std_include_paths = append(g_std_include_paths, s)
	}
}

func define(str string) {
	defines.Set(str)
}

func quote_makefile(s string) string {
	var bld strings.Builder

	for i := 0; i < len(s); i++ {
		switch s[i] {
		case '$':
			bld.WriteByte('$')
			bld.WriteByte('$')
		case '#':
			bld.WriteByte('\\')
			bld.WriteByte('#')
		case ' ':
		case '\t':
			for k := i - 1; k >= 0 && s[k] == '\\'; k-- {
				bld.WriteByte('\\')
			}
			bld.WriteByte('\\')
			bld.WriteByte(s[i])
		default:
			bld.WriteByte(s[i])
		}
	}
	return bld.String()
}

func open_file(path string) *os.File {
	if path == "" || path == "-" {
		return os.Stdout
	}

	out, err := os.Create(path)
	if err != nil {
		errorf("cannot open output file: %s: %v", path, err)
	}
	return out
}

func endswith(p string, q string) bool {
	return strings.LastIndex(p, q) != -1
}

// Replace file extension
func replace_extn(tmpl string, extn string) string {
	filename := filepath.Base(tmpl)
	dot := strings.LastIndex(filename, ".")
	if dot != -1 {
		filename = filename[:dot]
	}
	return fmt.Sprintf("%s%s", filename, extn)
}

func cleanup() {
	for _, name := range tmpfiles {
		os.Remove(name)
	}
}

func create_tmpfile() string {
	f, err := os.CreateTemp("", "petitecc-XXXXXX")
	if err != nil {
		errorf("CreateTemp: %v", err)
	}
	tmpfiles = append(tmpfiles, f.Name())
	f.Close()
	return f.Name()
}

func get_args_str(args []string) string {
	ret := ""
	for i, arg := range args {
		ret += fmt.Sprintf(" arg[%d]: %s", i, arg)
	}
	return ret
}

var g_stdin_data []byte

// Check if stdin is a terminal or a pipe
func check_stdin() {
	stat, _ := os.Stdin.Stat()
	isTerminal := (stat.Mode() & os.ModeCharDevice) != 0
	if !isTerminal {
		g_stdin_data, _ = io.ReadAll(os.Stdin)
	}
}

// Helper function to detect broken pipe or SIGPIPE
func isBrokenPipeOrSigPipe(err error) bool {
	// 1. Check if the error message explicitly contains the Go runtime signal
	if strings.Contains(err.Error(), "signal: broken pipe") {
		return true
	}

	// 2. Check for standard I/O EPIPE
	var pathErr *os.PathError
	if errors.As(err, &pathErr) && errors.Is(pathErr.Err, syscall.EPIPE) {
		return true
	}

	// 3. Check for subprocess killed by SIGPIPE via exec.Command
	var exitErr *exec.ExitError
	if errors.As(err, &exitErr) {
		if status, ok := exitErr.Sys().(syscall.WaitStatus); ok {
			if status.Signaled() && status.Signal() == syscall.SIGPIPE {
				return true
			}
		}
	}

	return false
}

func run_subprocess(cmd string, args []string) {
	//fmt.Fprintf(os.Stderr, "In run_subprocess: cmd: %s, args: %s\n", cmd, get_args_str(args))

	// If -### is given, dump the subprocess's command line.
	if *opt_hash_hash_hash_ptr {
		//fmt.Fprintf(os.Stderr, "%s", cmd)
		for _, arg := range args {
			fmt.Fprintf(os.Stderr, " %s", arg)
		}
		fmt.Fprintf(os.Stderr, "\n")
	}

	c := exec.Command(cmd, args...)
	check_stdin()
	if g_stdin_data != nil {
		c.Stdin = bytes.NewReader(g_stdin_data)
	} else {
		c.Stdin = os.Stdin
	}
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	err := c.Run()

	if err != nil {
		//Don't care about broken pipe error (AI tells me it's common and expected)
		if isBrokenPipeOrSigPipe(err) {
			return
		}
		errorf("%s returned error: %v", cmd, err)
	}
}

func run_cc1(cmd string, input string, output string, opt_cc *CompilerOptions) {
	var args []string
	args = append(args, "-cc1")

	if input != "" {
		args = append(args, "-cc1-input")
		args = append(args, input)
	}

	if output != "" {
		args = append(args, "-cc1-output")
		args = append(args, output)
	}

	if opt_cc.opt_E {
		args = append(args, "-E")
	}

	if opt_cc.opt_M {
		args = append(args, "-M")
	}

	if opt_cc.opt_MD {
		args = append(args, "-MD")
	}

	if opt_cc.opt_MMD {
		args = append(args, "-MMD")
	}

	if opt_cc.opt_MF != "" {
		args = append(args, fmt.Sprintf("-MF=%s", opt_cc.opt_MF))
	}

	if opt_cc.opt_MP {
		args = append(args, "-MP")
	}

	if !opt_cc.opt_fcommon {
		args = append(args, "-fno-common")
	}

	if opt_cc.opt_fpic {
		args = append(args, "-fpic")
	}

	for _, s := range opt_cc.opt_MT {
		args = append(args, fmt.Sprintf("-MT=%s", s))
	}

	for _, s := range opt_cc.opt_I {
		args = append(args, fmt.Sprintf("-I=%s", s))
	}

	for _, s := range opt_cc.opt_preI {
		args = append(args, fmt.Sprintf("-include=%s", s))
	}

	for k, v := range opt_cc.opt_D {
		args = append(args, fmt.Sprintf("-D=%s=%s", k, v))
	}

	for _, s := range opt_cc.opt_U {
		args = append(args, fmt.Sprintf("-U=%s", s))
	}
	run_subprocess(cmd, args)
}

// Print tokens to stdout. Used for -E.
func print_tokens(tok *Token, outfile string) {
	var path string
	if outfile != "" {
		path = outfile
	} else {
		path = "-"
	}
	out := open_file(path)

	line := 1
	for tok.kind != TK_EOF {
		if line > 1 && tok.at_bol {
			fmt.Fprintln(out)
		}

		if tok.has_space && !tok.at_bol {
			fmt.Fprint(out, " ")
		}

		if tok.kind == TK_STR {
			fmt.Fprintf(out, "\"%s\"", tok.lexeme)
		} else {
			fmt.Fprintf(out, "%s", tok.lexeme)
		}
		line++
		tok = tok.next
	}
	fmt.Fprintln(out)
}

func in_std_include_path(path string) bool {
	for i := 0; i < len(g_std_include_paths); i++ {
		dir := g_std_include_paths[i]
		l := len(dir)
		if path == dir && path[l] == '/' {
			return true
		}
	}
	return false
}

// If -M options is given, the compiler write a list of input files to
// stdout in a format that "make" command can read. This feature is
// used to automate file dependency management.
func print_dependencies(opt_o string, opt_MF string, opt_MP bool, opt_MT MakeRuleTargets, opt_MD bool, opt_MQ bool, opt_MMD bool) {
	var path string
	if opt_MF != "" {
		path = opt_MF
	} else if opt_MD {
		if opt_o != "" && opt_o != "-" {
			path = replace_extn(opt_o, ".d")
		} else {
			path = replace_extn(base_file, ".d")
		}
	} else {
		path = opt_o
	}
	out := open_file(path)

	var mrt string
	if len(opt_MT) != 0 {
		for i, s := range opt_MT {
			if i == 0 {
				mrt = s
			} else {
				mrt = mrt + " " + s
			}
		}
	} else {
		mrt = replace_extn(base_file, ".o")
	}

	if opt_MQ {
		mrt = quote_makefile(mrt)
	}

	fmt.Fprintf(out, "%s:", mrt)

	files := get_input_files()

	for i := 0; i < len(files); i++ {
		if opt_MMD && in_std_include_path(files[i].name) {
			continue
		}
		fmt.Fprintf(out, " \\\n  %s", files[i].name)
	}
	fmt.Fprintf(out, "\n\n")

	if opt_MP {
		for i := 1; i < len(files); i++ {
			if opt_MMD && in_std_include_path(files[i].name) {
				continue
			}
			fmt.Fprintf(out, "%s:\n\n", files[i].name)
		}
	}
}

func must_tokenize_file(path string) *Token {
	tok, err := tokenize_file(path)
	if err != nil {
		errorf("%s: %v", path, err)
	}
	return tok
}

func append_tokens(tok1 *Token, tok2 *Token) *Token {
	if tok1 == nil || tok1.kind == TK_EOF {
		return tok2
	}

	t := tok1
	for t.next.kind != TK_EOF {
		t = t.next
	}
	t.next = tok2
	return tok1
}

func cc1(opt_cc1_output string, opt_cc *CompilerOptions) {
	var tok *Token

	// Process -include option
	for i := 0; i < len(opt_cc.opt_preI); i++ {
		incl := opt_cc.opt_preI[i]

		var path string
		if file_exists(incl) {
			path = incl
		} else {
			path = search_include_paths(incl)
			if path == "" {
				errorf("-include: %s: file not found", incl)
			}
		}

		tok2 := must_tokenize_file(path)
		tok = append_tokens(tok, tok2)
	}

	// Tokenize and parse.
	tok2 := must_tokenize_file(base_file)
	tok = append_tokens(tok, tok2)

	for k, v := range opt_cc.opt_D {
		define_macro(k, v)
	}

	for _, s := range opt_cc.opt_U {
		undef_macro(s)
	}

	tok = preprocess(tok)

	// If -M or -MD are given, print file dependencies.
	if opt_cc.opt_M || opt_cc.opt_MD {
		print_dependencies(opt_cc.opt_o, opt_cc.opt_MF, opt_cc.opt_MP, opt_cc.opt_MT, opt_cc.opt_MD, opt_cc.opt_MQ, opt_cc.opt_MMD)
		if opt_cc.opt_M {
			return
		}
	}

	// If -E is given, print out preprocessed C code as a result.
	if opt_cc.opt_E {
		print_tokens(tok, opt_cc1_output)
		return
	}

	prog := parse(tok)

	// Traverse the AST to emit assembly.
	out := open_file(output_file)
	codegen(prog, out, opt_cc.opt_fcommon, opt_cc.opt_fpic)
}

func assemble(input string, output string) {
	cmd := "as"
	args := []string{"-c", input, "-o", output}
	run_subprocess(cmd, args)
}

func find_file(pattern string) string {
	files, err := filepath.Glob(pattern)
	if err != nil {
		errorf("find_file: %v\n", err)
	}
	if len(files) == 0 {
		errorf("find_file: pattern %s not found\n", pattern)
	}
	return files[0]
}

// Returns true if a given file exists.
func file_exists(path string) bool {
	if _, err := os.Stat(path); err == nil {
		return true
	}
	return false
}

func find_libpath() string {
	if file_exists("/usr/lib/x86_64-linux-gnu/crti.o") {
		return "/usr/lib/x86_64-linux-gnu"
	}
	if file_exists("/usr/lib64/crti.o") {
		return "/usr/lib64"
	}
	errorf("library path is not found")
	return "" //Won't be reached
}

func find_gcc_libpath() string {
	paths := []string{
		"/usr/lib/gcc/x86_64-linux-gnu/*/crtbegin.o",
		"/usr/lib/gcc/x86_64-pc-linux-gnu/*/crtbegin.o", // For Gentoo
		"/usr/lib/gcc/x86_64-redhat-linux/*/crtbegin.o", // For Fedora
	}

	for _, pth := range paths {
		path := find_file(pth)
		if path != "" {
			return filepath.Dir(path)
		}
	}

	errorf("gcc library path is not found")
	return "" //Wonät be reached
}

func run_linker(inputs []string, output string, opt_static bool, opt_shared bool) {
	var arr = []string{}

	arr = append(arr, "-o")
	arr = append(arr, output)
	arr = append(arr, "-m")
	arr = append(arr, "elf_x86_64")

	libpath := find_libpath()
	gcc_libpath := find_gcc_libpath()

	if opt_shared {
		arr = append(arr, fmt.Sprintf("%s/crti.o", libpath))
		arr = append(arr, fmt.Sprintf("%s/crtbeginS.o", gcc_libpath))
	} else {
		arr = append(arr, fmt.Sprintf("%s/crt1.o", libpath))
		arr = append(arr, fmt.Sprintf("%s/crti.o", libpath))
		arr = append(arr, fmt.Sprintf("%s/crtbegin.o", gcc_libpath))
	}
	arr = append(arr, fmt.Sprintf("-L%s", gcc_libpath))
	arr = append(arr, "-L/usr/lib/x86_64-linux-gnu")
	arr = append(arr, "-L/usr/lib64")
	arr = append(arr, "-L/lib64")
	arr = append(arr, "-L/usr/lib/x86_64-linux-gnu")
	arr = append(arr, "-L/usr/lib/x86_64-pc-linux-gnu")
	arr = append(arr, "-L/usr/lib/x86_64-redhat-linux")
	arr = append(arr, "-L/usr/lib")
	arr = append(arr, "-L/lib")

	if !opt_static {
		arr = append(arr, "-dynamic-linker")
		arr = append(arr, "/lib64/ld-linux-x86-64.so.2")
	}

	for _, s := range inputs {
		arr = append(arr, s)
	}

	if opt_static {
		arr = append(arr, "--start-group")
		arr = append(arr, "-lgcc")
		arr = append(arr, "-lgcc_eh")
		arr = append(arr, "-lc")
		arr = append(arr, "--end-group")
	} else {
		arr = append(arr, "-lc")
		arr = append(arr, "-lgcc")
		arr = append(arr, "--as-needed")
		arr = append(arr, "-lgcc_s")
		arr = append(arr, "--no-as-needed")
	}

	if opt_shared {
		arr = append(arr, fmt.Sprintf("%s/crtendS.o", gcc_libpath))
	} else {
		arr = append(arr, fmt.Sprintf("%s/crtend.o", gcc_libpath))
	}

	arr = append(arr, fmt.Sprintf("%s/crtn.o", libpath))

	run_subprocess("ld", arr)
}

func parse_opt_x(opt_E bool, s string) FileType {
	if s == "c" {
		return FILE_C
	}
	if s == "assembler" {
		return FILE_ASM
	}

	// -E implies that the input is the C macro language.
	if opt_E {
		return FILE_C
	}

	if s == "none" {
		return FILE_NONE
	}

	errorf("<command line>: unknown argument for -x: %s", s)
	return FILE_NONE //Won't be reached
}

func get_file_type(opt_x FileType, filename string) FileType {
	if opt_x != FILE_NONE {
		return opt_x
	}

	if endswith(filename, ".a") {
		return FILE_AR
	}

	if endswith(filename, ".so") {
		return FILE_DSO
	}

	if endswith(filename, ".o") {
		return FILE_OBJ
	}

	if endswith(filename, ".c") {
		return FILE_C
	}

	if endswith(filename, ".s") {
		return FILE_ASM
	}

	errorf("<command line>: unknown file extension: %s", filename)
	return FILE_NONE //Won't be reached
}

func append_libs_and_ldparams(opt_l Libraries, opt_s bool, opt_static bool, opt_shared bool, opt_L LibDirs, opt_Wl string, opt_xlinker XLinkers) []string {
	var ld_args []string
	for _, lib := range opt_l {
		ld_args = append(ld_args, fmt.Sprintf("-l%s", lib))
	}

	if opt_s {
		ld_args = append(ld_args, "-s")
	}

	if opt_static {
		ld_args = append(ld_args, "-static")
	}

	if opt_shared {
		ld_args = append(ld_args, "-shared")
	}

	for _, s := range opt_L {
		ld_args = append(ld_args, fmt.Sprintf("-L%s", s))
	}

	for _, s := range strings.Split(opt_Wl, ",") {
		if len(s) > 0 {
			ld_args = append(ld_args, fmt.Sprintf("%s", s))
		}
	}

	for _, s := range opt_xlinker {
		ld_args = append(ld_args, fmt.Sprintf("%s", s))
	}

	return ld_args
}

func main() {
	if len(os.Args) == 1 {
		usage()
		os.Exit(1)
	}
	CC1 = os.Args[0]
	flag.Usage = usage
	flag.Var(&include_paths, "I", "")
	flag.Var(&defines, "D", "")
	flag.Var(&undefines, "U", "")
	flag.Var(&idir_afters, "idirafter", "")
	flag.Var(&preincludes, "include", "")
	flag.Var(&libraries, "l", "")
	flag.Var(&makeruletargets, "MT", "")
	flag.Var(&libdirs, "L", "")
	flag.Var(&xlinkers, "Xlinker", "")
	flag.Parse()
	append_idirafters()

	cc_opt := CompilerOptions{opt_E: *opt_E_ptr, opt_c: *opt_c_ptr, opt_cc1: *opt_cc1_ptr, opt_S: *opt_S_ptr, opt_s: *opt_s_ptr,
		opt_o: *opt_o_ptr, opt_I: include_paths, opt_D: defines, opt_U: undefines, opt_fcommon: *opt_fcommon_ptr,
		opt_preI: preincludes, opt_x: FILE_C, opt_l: libraries, opt_M: *opt_M_ptr, opt_MF: *opt_MF_ptr,
		opt_MP: *opt_MP_ptr, opt_MT: makeruletargets, opt_MD: *opt_MD_ptr, opt_MQ: *opt_MQ_ptr, opt_MMD: *opt_MMD_ptr,
		opt_fpic: *opt_fpic_ptr, opt_static: *opt_static_ptr, opt_shared: *opt_shared_ptr, opt_L: libdirs, opt_Wl: *opt_Wl_ptr,
		opt_xlinker: xlinkers}
	if true == *opt_fnocommon_ptr {
		cc_opt.opt_fcommon = false
	}
	cc_opt.opt_x = parse_opt_x(cc_opt.opt_E, *opt_x_ptr)
	if cc_opt.opt_MMD {
		cc_opt.opt_MD = true
	}
	if cc_opt.opt_fpic == false {
		cc_opt.opt_fpic = *opt_fpic2_ptr
	}

	//dump_args(&cc_opt)

	if cc_opt.opt_cc1 {
		add_default_include_paths(CC1)
		base_file = *opt_cc1_input_ptr
		output_file = *opt_cc1_output_ptr
		cc1(output_file, &cc_opt)
		cleanup()
		os.Exit(0)
	}

	input_paths = flag.Args()
	if len(input_paths) > 1 && (cc_opt.opt_o != "") && (cc_opt.opt_c || cc_opt.opt_S || cc_opt.opt_E) {
		errorf("cannot specify '-o' with '-c,' '-S' or '-E' with multiple files")
	}

	ld_args := append_libs_and_ldparams(cc_opt.opt_l, cc_opt.opt_s, cc_opt.opt_static, cc_opt.opt_shared, cc_opt.opt_L, cc_opt.opt_Wl, cc_opt.opt_xlinker)
	for _, name_ := range input_paths {
		input := name_
		var output string
		if "" != cc_opt.opt_o {
			output = cc_opt.opt_o
		} else if cc_opt.opt_S {
			output = replace_extn(input, ".s")
		} else {
			output = replace_extn(input, ".o")
		}

		ft := get_file_type(cc_opt.opt_x, input)

		//Handle .o, .a and .so
		if ft == FILE_OBJ || ft == FILE_AR || ft == FILE_DSO {
			ld_args = append(ld_args, input)
			continue
		}

		//Handle .s
		if ft == FILE_ASM {
			if !cc_opt.opt_S {
				assemble(input, output)
			}
			continue
		}

		myassert(ft == FILE_C)

		// Just preprocess
		if cc_opt.opt_E || cc_opt.opt_M {
			var out string
			if cc_opt.opt_o != "" {
				out = cc_opt.opt_o
			} else {
				out = ""
			}
			run_cc1(CC1, input, out, &cc_opt)
			continue
		}

		// Compile
		if cc_opt.opt_S {
			run_cc1(CC1, input, output, &cc_opt)
			continue
		}

		// Compile and assemble
		if cc_opt.opt_c {
			tmp := create_tmpfile()
			run_cc1(CC1, input, tmp, &cc_opt)
			assemble(tmp, output)
			continue
		}

		// Compile, assemble and link
		tmp1 := create_tmpfile()
		tmp2 := create_tmpfile()
		run_cc1(CC1, input, tmp1, &cc_opt)
		assemble(tmp1, tmp2)
		ld_args = append(ld_args, tmp2)
		continue
	}

	if len(ld_args) > 0 {
		var ld_out string
		if cc_opt.opt_o == "" {
			ld_out = "a.out"
		} else {
			ld_out = cc_opt.opt_o
		}
		run_linker(ld_args, ld_out, cc_opt.opt_static, cc_opt.opt_shared)
	}

	cleanup()
	os.Exit(0)
}
