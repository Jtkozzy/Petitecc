package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"os"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf16"
)

//
// Tokenizer
//

type TokenKind int

// Token
const (
	TK_IDENT   = iota //Identifiers
	TK_PUNCT          //Punctuators
	TK_KEYWORD        //Keywords
	TK_STR            //String literals
	TK_NUM            //Numeric literals
	TK_PP_NUM         // Preprocessing numbers
	TK_EOF            //Enf-of-file markers
)

type File struct {
	name     string
	file_no  int
	contents string

	// For #line directive
	display_name string
	line_delta   int
}

type Token struct {
	kind                  TokenKind //Token kind
	next                  *Token    //Next token
	val                   int64     //If kind is TK_NUM, its value
	fval                  float64   //If kind is TK_NUM, its value
	loc                   int       //Token location
	lexeme                string    //Token string. In case of TK_STR, contains C end marker '\0'
	has_oct_or_hex_escape bool      //TK_STR has octal or hex escapes_
	str16                 []uint16  //TK_STR, if utf16 encoded, nil otherwise
	str32                 []uint32  //TK_STR, if utf32 encoded, nil otherwise
	raw                   []byte    //Used for stringizing when joining TK_STRs
	ty                    *Type     //Used if TK_NUM or TK_STR

	file       *File    //Source location
	filename   string   // Filename
	line_no    int      //Line number
	line_delta int      // Line number
	at_bol     bool     //True if this token is at beginning of line
	has_space  bool     // True if this token follows a space character
	hideset    *Hideset // For macro expansion
	origin     *Token   // If this is expanded from a macro, the original token
}

// Input file
var current_file *File

// A list of all input files.
var input_files []*File

// True if the current position is at the beginning of a line
var at_bol bool

// True if the current position follows a space character
var has_space bool

// Reports an error and exit.
func errorf(format string, args ...interface{}) {
	fmt.Fprintf(os.Stderr, format, args...)
	fmt.Fprintln(os.Stderr)
	os.Exit(1)
}

func unreachable() {
	_, fileName, fileLine, ok := runtime.Caller(1)
	var s string
	if ok {
		s = fmt.Sprintf("%s:%d", fileName, fileLine)
	} else {
		s = "(unknown)"
	}
	errorf("internal error at %s", s)
	debug.PrintStack()
}

/*
// Reports an error message in the following format
//
// foo.c:10: x = y + 1;
//	^ <error message here>
//
*/
func verror_at(filename string, input string, line_no int, loc int, format string, args ...interface{}) {
	// Find a line containing `loc`.
	line := loc
	for 0 < line && input[line-1] != '\n' {
		line--
	}

	len := len(input)
	end := loc
	for end < len && input[end] != '\n' {
		end++
	}

	// Print out the line.
	indent, _ := fmt.Fprintf(os.Stderr, "%s:%d: ", filename, line_no)
	fmt.Fprintf(os.Stderr, "%.*s\n", end-line, input[line:end])

	// Show the error message.
	pos := display_width(line, input[line:end]) + indent

	fmt.Fprintf(os.Stderr, "%*s", pos, "") // print pos spaces.
	fmt.Fprintf(os.Stderr, "^ ")
	fmt.Fprintf(os.Stderr, format, args...)
	fmt.Fprintf(os.Stderr, "\n")
}

func error_at(loc int, format string, args ...interface{}) {
	line_no := 1
	for i := range loc {
		if current_file.contents[i] == '\n' {
			line_no++
		}
	}
	verror_at(current_file.name, current_file.contents, line_no, loc, format, args...)
	os.Exit(1)
}

func error_tok(tok *Token, format string, args ...interface{}) {
	verror_at(tok.file.name, tok.file.contents, tok.line_no, tok.loc, format, args...)
	os.Exit(1)
}

func warn_tok(tok *Token, format string, args ...interface{}) {
	verror_at(tok.file.name, tok.file.contents, tok.line_no, tok.loc, format, args...)
}

// Consumes the current token if it matches `op`.
func equal(tok *Token, op string) bool {
	return op == tok.lexeme
}

// Ensure that the current token is `s`.
func skip(tok *Token, s string) *Token {
	if !equal(tok, s) {
		error_tok(tok, "expected '%s'", s)
	}
	return tok.next
}

func consume(rest **Token, tok *Token, s string) bool {
	if equal(tok, s) {
		*rest = tok.next
		return true
	}
	*rest = tok
	return false
}

// Create a new token.
func new_token(kind TokenKind, loc int, lexeme string) *Token {
	ret := &Token{kind: kind, loc: loc, lexeme: lexeme, file: current_file, filename: current_file.display_name, at_bol: at_bol, has_space: has_space}
	at_bol = false
	has_space = false
	return ret
}

func startswith(i int, q string) bool {
	return strings.HasPrefix(current_file.contents[i:], q)
}

// Read an identifier and returns the length of it.
// If p does not point to a valid identifier, 0 is returned.
func read_ident(start int) int {
	p := start
	var c, l int
	c, l = decode_utf8(start, current_file.contents[p:])
	if !is_ident1(c) {
		return 0
	}
	p += l

	for {
		c, l = decode_utf8(start, current_file.contents[p:])
		if !is_ident2(c) {
			return p - start
		}
		p += l
	}
}

func from_hex(c byte) int {
	if '0' <= c && c <= '9' {
		return int(c - '0')
	}
	if 'a' <= c && c <= 'f' {
		return int(c - 'a' + 10)
	}
	return int(c - 'A' + 10)
}

// Read a punctuator token from p and returns its length.
func read_punct(i int) int {
	kw := []string{
		"<<=", ">>=", "...", "==", "!=", "<=", ">=", "->", "+=",
		"-=", "*=", "/=", "++", "--", "%=", "&=", "|=", "^=", "&&",
		"||", "<<", ">>", "##",
	}

	for _, s := range kw {
		if startswith(i, s) {
			return len(s)
		}
	}

	if isPunctASCII(current_file.contents[i]) {
		return 1
	}
	unreachable()
	return 0 //Won't be reached
}

var kwmap map[string]bool = make(map[string]bool)
var kw = []string{"return", "if", "else", "for", "while", "int", "sizeof", "char",
	"struct", "union", "short", "long", "void", "typedef", "_Bool",
	"enum", "static", "goto", "break", "continue", "switch", "case",
	"default", "extern", "_Alignof", "_Alignas", "do", "signed",
	"unsigned", "const", "volatile", "auto", "register", "restrict",
	"__restrict", "__restrict__", "_Noreturn", "float", "double",
	"typeof", "asm", "_Thread_local", "__thread", "_Atomic", "__attribute__",
}

func is_keyword(tok *Token) bool {
	if len(kwmap) == 0 {
		for _, s := range kw {
			kwmap[s] = true
		}
	}
	return kwmap[tok.lexeme] == true
}

func isXDigit(r byte) bool {
	return (r >= '0' && r <= '9') || (r >= 'a' && r <= 'f') || (r >= 'A' && r <= 'F')
}

// convert from Go's unsigned byte, e.g. 229 to C's signed, e.g -27
func g2c(g int) int {
	if (g >= 128) && (g < 256) {
		g = -256 + g
	}
	return g
}

func read_escaped_char(start int, s string, char_signed bool) (int, int, bool) {
	i := 0
	if '0' <= s[i] && s[i] <= '7' {
		var c int
		// Read an octal number.
		c = int(s[i]) - int('0')
		i++
		if '0' <= s[i] && s[i] <= '7' {
			c = (c << 3) + (int(s[i]) - int('0'))
			i++
			if '0' <= s[i] && s[i] <= '7' {
				c = (c << 3) + (int(s[i]) - int('0'))
				i++
			}
		}
		if char_signed {
			return g2c(c), i, true
		}
		return c, i, true
	}

	if s[i] == 'x' {
		// Read a hexadecimal number.
		i++
		if !isXDigit(s[i]) {
			error_at(start+i, "invalid hex escape sequence")
		}

		c := 0
		for isXDigit(s[i]) {
			c = (c << 4) + from_hex(s[i])
			i++
		}
		if char_signed {
			return g2c(c), i, true
		}
		return c, i, true
	}

	ret := 1

	// Escape sequences are defined using themselves here. E.g.
	// '\n' is implemented using '\n'. This tautological definition
	// works because the compiler that compiles our compiler knows
	// what '\n' actually is. In other words, we "inherit" the ASCII
	// code of '\n' from the compiler that compiles our compiler,
	// so we don't have to teach the actual code here.
	//
	// This fact has huge implications not only for the correctness
	// of the compiler but also for the security of the generated code.
	// For more info, read "Reflections on Trusting Trust" by Ken Thompson.
	// https://github.com/rui314/chibicc/wiki/thompson1984.pdf
	switch s[i] {
	case 'a':
		return '\a', ret, false
	case 'b':
		return '\b', ret, false
	case 't':
		return '\t', ret, false
	case 'n':
		return '\n', ret, false
	case 'v':
		return '\v', ret, false
	case 'f':
		return '\f', ret, false
	case 'r':
		return '\r', ret, false
	// [GNU] \e for the ASCII escape character is a GNU C extension.
	case 'e':
		return 27, ret, false
	default:
		return int(s[i]), ret, false
	}
}

// Find a closing double-quote.
func string_literal_end(p int) int {
	start := p

	sp := func() byte {
		return current_file.contents[p]
	}

	for sp() != '"' {
		if p >= len(current_file.contents) || sp() == '\n' {
			error_at(start, "unclosed string literal")
		}
		if sp() == '\\' {
			p++
		}

		p++
	}
	return p
}

func read_string_literal(start int, quote int) (int, *Token) {
	var lexbld strings.Builder
	var has_oct_hex_escape bool
	end := string_literal_end(quote + 1)
	p := quote + 1

	consumed := func() int {
		return end + 1 - start
	}

	sp := func() byte {
		return current_file.contents[p]
	}

	var c, l int
	for p < end {
		if sp() == '\\' {
			p++
			res, consumed, f := read_escaped_char(start, current_file.contents[p:], false)
			if f {
				has_oct_hex_escape = true
			}
			lexbld.WriteByte(byte(res))
			p += consumed
		} else {
			c, l = decode_utf8(start, current_file.contents[p:])
			lexbld.WriteRune(rune(c))
			p += l
		}
	}

	lexbld.WriteByte(0) //C string end marker for compatibility
	lexeme := lexbld.String()
	tok := new_token(TK_STR, start, lexeme)
	tok.ty = array_of(ty_char, len(lexeme))
	tok.raw = []byte(current_file.contents[start : end+1])
	tok.has_oct_or_hex_escape = has_oct_hex_escape
	return consumed(), tok
}

// Read a UTF-8-encoded string literal and transcode it in UTF-16.
//
// UTF-16 is yet another variable-width encoding for Unicode. Code
// points smaller than U+10000 are encoded in 2 bytes. Code points
// equal to or larger than that are encoded in 4 bytes. Each 2 bytes
// in the 4 byte sequence is called "surrogate", and a 4 byte sequence
// is called a "surrogate pair".
func read_utf16_string_literal(start int, quote int) (int, *Token) {
	end := string_literal_end(quote + 1)
	p := quote + 1

	consumed := func() int {
		return end + 1 - start
	}

	sp := func() byte {
		return current_file.contents[p]
	}

	var c, l int
	var buf []uint16

	for p < end {
		if sp() == '\\' {
			p++
			res, consumed, _ := read_escaped_char(start, current_file.contents[p:], false)
			buf = append(buf, uint16(res))
			p += consumed
			continue
		}
		c, l = decode_utf8(start, current_file.contents[p:])
		buf = utf16.AppendRune(buf, rune(c))
		p += l
	}

	buf = append(buf, uint16(0)) //C string end marker for compatibility
	var lexbld strings.Builder
	decoded := utf16.Decode(buf)
	for i := 0; i < len(decoded); i++ {
		lexbld.WriteRune(decoded[i])
	}
	lexeme := lexbld.String()

	tok := new_token(TK_STR, start, lexeme)
	tok.ty = array_of(ty_ushort, len(buf))
	tok.raw = []byte(current_file.contents[start : end+1])
	tok.str16 = buf
	return consumed(), tok
}

// Read a UTF-8-encoded string literal and transcode it in UTF-32.
//
// UTF-32 is a fixed-width encoding for Unicode. Each code point is
// encoded in 4 bytes.
func read_utf32_string_literal(start int, quote int, ty *Type) (int, *Token) {
	end := string_literal_end(quote + 1)
	p := quote + 1

	consumed := func() int {
		return end + 1 - start
	}

	sp := func() byte {
		return current_file.contents[p]
	}

	var c, l int
	var buf []uint32

	for p < end {
		if sp() == '\\' {
			p++
			res, consumed, _ := read_escaped_char(start, current_file.contents[p:], false)
			buf = append(buf, uint32(res))
			p += consumed
			continue
		}
		c, l = decode_utf8(start, current_file.contents[p:])
		buf = append(buf, uint32(c))
		p += l
	}

	buf = append(buf, uint32(0)) //C string end marker for compatibility
	var lexbld strings.Builder
	for i := 0; i < len(buf); i++ {
		lexbld.WriteRune(rune(buf[i]))
	}
	lexeme := lexbld.String()

	tok := new_token(TK_STR, start, lexeme)
	tok.ty = array_of(ty, len(buf))
	tok.raw = []byte(current_file.contents[start : end+1])
	tok.str32 = buf
	return consumed(), tok
}

func read_char_literal(start int, quote int, ty *Type) (int, *Token) {
	var end int
	p := quote + 1
	if p >= len(current_file.contents) {
		error_at(start, "unclosed char literal")
	}

	consumed := func() int {
		return end + 1 - start
	}

	sp := func() byte {
		return current_file.contents[p]
	}

	strchr := func(b byte) int {
		for i := p; i < len(current_file.contents); i++ {
			if current_file.contents[i] == b {
				return i
			}
		}
		return -1
	}

	var c, l int
	if sp() == '\\' {
		c, l, _ = read_escaped_char(start, current_file.contents[p+1:], true)
		p += l
	} else {
		c, l = decode_utf8(start, current_file.contents[p:])
		p += l
	}

	end = strchr('\'')
	if end == -1 {
		error_at(start, "unclosed char literal")
	}

	tok := new_token(TK_NUM, start, current_file.contents[start:end+1])
	tok.val = int64(c)
	tok.ty = ty

	return consumed(), tok
}

func hex_start(s string) bool {
	if len(s) > 2 {
		b1 := strings.HasPrefix(s, "0x")
		b2 := strings.HasPrefix(s, "0X")
		b3 := isXDigit(s[2])
		return (b1 || b2) && b3
	}
	return false
}

func bin_start(s string) bool {
	if len(s) > 2 {
		b1 := (strings.HasPrefix(s, "0b") || strings.HasPrefix(s, "0B"))
		b2 := (s[2] == '0') || (s[2] == '1')
		return b1 && b2
	}
	return false
}

func is_base2_digit(b byte) bool {
	return b == '0' || b == '1'
}

func is_base10_digit(b byte) bool {
	return b >= '0' && b <= '9'
}

func is_base8_digit(b byte) bool {
	return b >= '0' && b <= '7'
}

func is_hex_digit(b byte) bool {
	return (b >= '0' && b <= '9') || (b >= 'a' && b <= 'f') || (b >= 'A' && b <= 'F')
}

func is_c_float_suffix(b byte) bool {
	return b == 'f' || b == 'F' || b == 'l' || b == 'L'
}

func convert_pp_int(tok *Token) bool {
	toklen := len(tok.lexeme)
	p := 0
	s := tok.lexeme
	base := 10

	strtoul := func() (uint64, int) {
		var f func(b byte) bool
		after_last := toklen
		if base == 2 {
			f = is_base2_digit
		} else if base == 10 {
			f = is_base10_digit
		} else if base == 8 {
			f = is_base8_digit
		} else {
			f = is_hex_digit
		}

		for i := p; i < toklen; i++ {
			if !f(s[i]) {
				after_last = i
				break
			}
		}

		tmp := s[p:after_last]
		val, err := strconv.ParseUint(tmp, base, 64)
		if err != nil {
			return 0, after_last
		}

		return val, after_last
	}

	suf := func(sufstr string) bool {
		if p >= toklen {
			return false
		}

		return strings.Index(s[p:], sufstr) == 0
	}

	sufnocase := func(sufstr string) bool {
		if p >= toklen {
			return false
		}

		sufstr = strings.ToLower(sufstr)
		tmp := strings.ToLower(s[p:])
		return strings.Index(tmp, sufstr) == 0
	}

	// Read a binary, octal, decimal or hexadecimal number.
	if hex_start(s) {
		p += 2
		base = 16
	} else if bin_start(s) {
		p += 2
		base = 2
	} else if s[0] == '0' {
		base = 8
	}

	var val uint64
	val, p = strtoul()

	// Read U, L or LL suffixes.
	l := false
	u := false

	if suf("LLU") || suf("LLu") ||
		suf("llU") || suf("llu") ||
		suf("ULL") || suf("Ull") ||
		suf("uLL") || suf("ull") {
		p += 3
		l, u = true, true
	} else if sufnocase("lu") || sufnocase("ul") {
		p += 2
		l, u = true, true
	} else if suf("LL") || suf("ll") {
		p += 2
		l = true
	} else if suf("L") || suf("l") {
		p++
		l = true
	} else if suf("U") || suf("u") {
		p++
		u = true
	}

	if p != toklen {
		return false
	}

	// Infer a type.
	var ty *Type
	if base == 10 {
		if l && u {
			ty = ty_ulong
		} else if l {
			ty = ty_long
		} else if u {
			if (val >> 32) != 0 {
				ty = ty_ulong
			} else {
				ty = ty_uint
			}
		} else {
			if (val >> 31) != 0 {
				ty = ty_long
			} else {
				ty = ty_int
			}
		}
	} else {
		if l && u {
			ty = ty_ulong
		} else if l {
			if (val >> 63) != 0 {
				ty = ty_ulong
			} else {
				ty = ty_long
			}
		} else if u {
			if (val >> 32) != 0 {
				ty = ty_ulong
			} else {
				ty = ty_uint
			}
		} else if (val >> 63) != 0 {
			ty = ty_ulong
		} else if (val >> 32) != 0 {
			ty = ty_long
		} else if (val >> 31) != 0 {
			ty = ty_uint
		} else {
			ty = ty_int
		}
	}

	tok.kind = TK_NUM
	tok.val = int64(val)
	tok.ty = ty
	return true
}

// The definition of the numeric literal at the preprocessing stage
// is more relaxed than the definition of that at the later stages.
// In order to handle that, a numeric literal is tokenized as a
// "pp-number" token first and then converted to a regular number
// token after preprocessing.
//
// This function converts a pp-number token to a regular number token.
func convert_pp_number(tok *Token) {
	// Try to parse as an integer constant.
	if convert_pp_int(tok) {
		return
	}

	// If it's not an integer, it must be a floating point constant.
	toklen := len(tok.lexeme)
	s := tok.lexeme
	p := 0
	strtod := func() (float64, int) {
		after_last := toklen
		for i := p; i < toklen; i++ {
			if is_c_float_suffix(s[i]) {
				after_last = i
				break
			}
		}

		//no digits at all
		if after_last == p {
			return 0.0, after_last
		}

		tmp := s[p:after_last]
		val, err := strconv.ParseFloat(tmp, 64)
		if err != nil {
			return 0.0, after_last
		}

		return val, after_last

	}

	suf := func(sufstr string) bool {
		if p >= toklen {
			return false
		}

		return strings.Index(s[p:], sufstr) == 0
	}

	var val float64
	val, p = strtod()

	var ty *Type
	if suf("f") || suf("F") {
		ty = ty_float
		p++
	} else if suf("l") || suf("L") {
		ty = ty_double
		p++
	} else {
		ty = ty_double
	}

	if toklen != p {
		error_tok(tok, "invalid numeric constant, lexeme: '%s'\n", tok.lexeme)
	}

	tok.kind = TK_NUM
	tok.fval = val
	tok.ty = ty

}

func convert_pp_tokens(tok *Token) {
	for t := tok; t.kind != TK_EOF; t = t.next {
		if is_keyword(t) {
			t.kind = TK_KEYWORD
		} else if t.kind == TK_PP_NUM {
			convert_pp_number(t)
		}
	}
}

// Initialize line info for all tokens.
func add_line_numbers(tok *Token) {
	n := 1

	for i, r := range current_file.contents {
		if i == tok.loc {
			tok.line_no = n
			tok = tok.next
		}

		if r == '\n' {
			n++
		}
	}
}

func read_pp_number(s string, start int) (*Token, int) {
	s_has_byte := func(str string, b byte) bool {
		return strings.IndexByte(str, b) != -1
	}

	isalnum := func(b byte) bool {
		return (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9')
	}

	len := len(s)
	i := 0
	for i < len {
		if i < len-1 && s_has_byte("eEpP", s[i]) && s_has_byte("+-", s[i+1]) {
			i += 2
		} else if isalnum(s[i]) || s[i] == '.' {
			i++
		} else {
			break
		}
	}

	tok := new_token(TK_PP_NUM, start, s[:i])
	return tok, i
}

// Tokenize a given source string and returns new tokens.
func tokenize(file *File) *Token {
	current_file = file
	head := Token{kind: TK_PUNCT, next: nil, val: 0, lexeme: ""}
	cur := &head

	at_bol = true
	has_space = false

	i := 0
	for i < len(current_file.contents) {
		// Skip line comments.
		if startswith(i, "//") {
			i += 2
			for current_file.contents[i] != '\n' {
				i++
			}
			has_space = true
			continue
		}

		// Skip block comments.
		if startswith(i, "/*") {
			consumed, found := find2(i+2, '*', '/')
			if !found {
				error_at(i, "unclosed block comment")
			}
			i += consumed + 2
			has_space = true
			continue
		}

		// Skip newline.
		if current_file.contents[i] == '\n' {
			i++
			at_bol = true
			has_space = false
			continue
		}

		// Skip whitespace characters.
		if unicode.IsSpace(rune(current_file.contents[i])) {
			i++
			has_space = true
			continue
		}

		// Numeric literal
		if unicode.IsDigit(rune(current_file.contents[i])) || (current_file.contents[i] == '.' && unicode.IsDigit(rune(current_file.contents[i+1]))) {
			span := min(len(current_file.contents), i+70)
			tok, consumed := read_pp_number(current_file.contents[i:span], i)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// String literal
		if current_file.contents[i] == '"' {
			consumed, tok := read_string_literal(i, i)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// UTF-8 string literal
		if startswith(i, "u8\"") {
			consumed, tok := read_string_literal(i, i+2)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// UTF-16 string literal
		if startswith(i, "u\"") {
			consumed, tok := read_utf16_string_literal(i, i+1)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// Wide string literal
		if startswith(i, "L\"") {
			consumed, tok := read_utf32_string_literal(i, i+1, ty_int)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// UTF-32 string literal
		if startswith(i, "U\"") {
			consumed, tok := read_utf32_string_literal(i, i+1, ty_uint)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// Character literal
		if current_file.contents[i] == '\'' {
			consumed, tok := read_char_literal(i, i, ty_int)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// UTF-16 character literal
		if startswith(i, "u'") {
			consumed, tok := read_char_literal(i, i+1, ty_ushort)
			cur.next = tok
			cur = cur.next
			cur.val &= 0xffff
			i += consumed
			continue
		}

		// Wide character literal
		if startswith(i, "L'") {
			consumed, tok := read_char_literal(i, i+1, ty_int)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// UTF-32 character literal
		if startswith(i, "U'") {
			consumed, tok := read_char_literal(i, i+1, ty_uint)
			cur.next = tok
			cur = cur.next
			i += consumed
			continue
		}

		// Identifier or keyword
		ident_len := read_ident(i)
		if ident_len != 0 {
			cur.next = new_token(TK_IDENT, i, current_file.contents[i:i+ident_len])
			cur = cur.next
			i += ident_len
			continue
		}

		// Punctuators
		punct_len := read_punct(i)
		if punct_len != 0 {
			cur.next = new_token(TK_PUNCT, i, current_file.contents[i:i+punct_len])
			cur = cur.next
			i += punct_len
			continue
		}

		error_at(i, "invalid token")
	}

	cur.next = new_token(TK_EOF, len(current_file.contents)-1, "")
	cur = cur.next

	add_line_numbers(head.next)

	//tok_print_tokens(head.next)
	return head.next
}

func read_file(path string) (string, error) {
	var b []byte
	var err error

	if path == "-" {
		reader := bufio.NewReader(os.Stdin)
		b, err = io.ReadAll(reader)
	} else {
		b, err = os.ReadFile(path)
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "read_file(path %s, bytes hex: %x): %v\n", path, path, err)
		return "", err
	}
	// Make sure that the last line is properly terminated with '\n'.
	nl := []byte{byte('\n')}
	if len(b) == 0 || !bytes.HasSuffix(b, nl) {
		b = append(b, byte('\n'))
	}
	return string(b), nil
}

func get_input_files() []*File {
	return input_files
}

func new_file(name string, file_no int, contents string) *File {
	file := File{}
	file.name = name
	file.display_name = name
	file.file_no = file_no
	file.contents = contents
	return &file
}

func read_universal_char(b []byte, len int) uint32 {
	var c uint32 = 0

	for i := 0; i < len; i++ {
		if !is_hex_digit(b[i]) {
			return 0
		}
		c = (c << 4) | uint32(from_hex(b[i]))
	}
	return c
}

// Replace \u or \U escape sequences with corresponding UTF-8 bytes.
func convert_universal_chars(s string) string {
	var bld strings.Builder
	i := 0

	for i < len(s) {
		if strings.HasPrefix(s[i:], "\\u") {
			c := read_universal_char([]byte(s[i+2:i+6]), 4)
			if c != 0 {
				bld.WriteRune(rune(c))
				i += 6
			} else {
				bld.WriteByte(s[i])
				i++
			}
		} else if strings.HasPrefix(s[i:], "\\U") {
			c := read_universal_char([]byte(s[i+2:i+10]), 8)
			if c != 0 {
				bld.WriteRune(rune(c))
				i += 10
			} else {
				bld.WriteByte(s[i])
				i++
			}
		} else if s[i] == '\\' {
			bld.WriteByte('\\')
			i++
			bld.WriteByte(s[i])
			i++
		} else {
			bld.WriteByte(s[i])
			i++
		}
	}

	return bld.String()
}

// Replaces \r or \r\n with \n.
func canonicalize_newline(s string) string {
	var bld strings.Builder
	i := 0

	for i < len(s) {
		if s[i] == '\r' && s[i+1] == '\n' {
			i += 2
			bld.WriteByte('\n')
		} else if s[i] == '\r' {
			i++
			bld.WriteByte('\n')
		} else {
			bld.WriteByte(s[i])
			i++
		}
	}

	return bld.String()
}

// Removes backslashes followed by a newline.
func remove_backslash_newline(s string) string {
	var bld strings.Builder
	i := 0

	// We want to keep the number of newline characters so that
	// the logical line number matches the physical one.
	// This counter maintain the number of newlines we have removed.
	n := 0

	for i < len(s) {
		if s[i] == '\\' && s[i+1] == '\n' {
			i += 2
			n++
		} else if s[i] == '\n' {
			bld.WriteByte(s[i])
			i++
			for n > 0 {
				bld.WriteByte('\n')
				n--
			}
		} else {
			bld.WriteByte(s[i])
			i++
		}
	}

	for n > 0 {
		bld.WriteByte('\n')
		n--
	}
	return bld.String()
}

var file_no int

func tokenize_file(path string) (*Token, error) {
	s, err := read_file(path)
	if err != nil {
		return nil, err
	}

	// UTF-8 texts may start with a 3-byte "BOM" marker sequence.
	// If exists, just skip them because they are useless bytes.
	// (It is actually not recommended to add BOM markers to UTF-8
	// texts, but it's not uncommon particularly on Windows.)
	bom := []byte{0xef, 0xbb, 0xbf}
	if bytes.HasPrefix([]byte(s), bom) {
		s = s[len(bom):]
	}

	s = canonicalize_newline(s)
	s = remove_backslash_newline(s)
	s = convert_universal_chars(s)

	// Save the filename for assembler .file directive.
	file := new_file(path, file_no+1, s)

	// Save the filename for assembler .file directive.
	input_files = append(input_files, file)
	file_no++

	return tokenize(file), nil
}

//
// Own additions
//

func find2(start int, needle1 byte, needle2 byte) (int, bool) {
	consumed := 0
	i := start
	for i < len(current_file.contents)-1 {
		if current_file.contents[i] == needle1 && current_file.contents[i+1] == needle2 {
			return consumed + 2, true
		}
		i++
		consumed++
	}
	return 0, false
}

// isPunctASCII mimics C's ispunct() for ASCII characters
func isPunctASCII(r byte) bool {
	return (r >= 33 && r <= 47) || // ! to /
		(r >= 58 && r <= 64) || // : to @
		(r >= 91 && r <= 96) || // [ to `
		(r >= 123 && r <= 126) // { to ~
}

func IsAlnum(r rune) bool {
	return unicode.IsLetter(r) || unicode.IsDigit(r)
}

func print_tok(t *Token, info string) {
	fmt.Printf("Token (%s): ", info)
	switch t.kind {
	case TK_IDENT:
		fmt.Printf("TK_IDENT (line: %d, loc: %d): lexeme: '%s'\n", t.line_no, t.loc, t.lexeme)
	case TK_PUNCT:
		fmt.Printf("TK_PUNCT (line: %d, loc: %d): lexeme: '%s'\n", t.line_no, t.loc, t.lexeme)
	case TK_KEYWORD:
		fmt.Printf("TK_KEYWORD (line: %d, loc: %d): lexeme: '%s'\n", t.line_no, t.loc, t.lexeme)
	case TK_STR:
		fmt.Printf("TK_STR (line: %d, loc: %d): lexeme: '%q'\n", t.line_no, t.loc, t.lexeme)
	case TK_NUM:
		fmt.Printf("TK_NUM (line: %d, loc: %d): val: %d, fval:%f\n", t.line_no, t.loc, t.val, t.fval)
	case TK_PP_NUM:
		fmt.Printf("TK_PP_NUM (line: %d, loc: %d): lexeme: '%s'\n", t.line_no, t.loc, t.lexeme)
	case TK_EOF:
		fmt.Printf("TK_EOF (line: %d, loc: %d)\n", t.line_no, t.loc)

	}
}

func tok_print_tokens(tok *Token) {
	fmt.Printf("\n--- Tokens list ---\n")
	for t := tok; t != nil; t = t.next {
		print_tok(t, "")
	}
	fmt.Printf("--------------------------------\n\n")
}
