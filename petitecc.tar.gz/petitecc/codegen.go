package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"runtime"
)

//
// Code generator
//

const GP_MAX = 6
const FP_MAX = 8

var depth int
var argreg8 = []string{"%dil", "%sil", "%dl", "%cl", "%r8b", "%r9b"}
var argreg16 = []string{"%di", "%si", "%dx", "%cx", "%r8w", "%r9w"}
var argreg32 = []string{"%edi", "%esi", "%edx", "%ecx", "%r8d", "%r9d"}
var argreg64 = []string{"%rdi", "%rsi", "%rdx", "%rcx", "%r8", "%r9"}
var cg_current_fn *Obj
var cg_output_file *os.File
var cg_opt_fpic bool

func println(format string, args ...interface{}) {
	fmt.Fprintf(cg_output_file, format, args...)
	fmt.Fprintln(cg_output_file)
}

var ic int = 1

func count() int {
	ret := ic
	ic++
	return ret
}

func push() {
	println("  push %%rax")
	depth++
}

func pop(arg string) {
	println("  pop %s", arg)
	depth--
}

func pushf() {
	println("  sub $8, %%rsp")
	println("  movsd %%xmm0, (%%rsp)")
	depth++
}

func popf(reg int) {
	println("  movsd (%%rsp), %%xmm%d", reg)
	println("  add $8, %%rsp")
	depth--
}

// Round up `n` to the nearest multiple of `align`. For instance,
// align_to(5, 8) returns 8 and align_to(11, 8) returns 16.
func align_to(n int, align int) int {
	return (n + align - 1) / align * align
}

func reg_dx(sz int) string {
	switch sz {
	case 1:
		return "%dl"
	case 2:
		return "%dx"
	case 4:
		return "%edx"
	case 8:
		return "%rdx"
	}
	unreachable()
	return "" //Won't be reached
}

func reg_ax(sz int) string {
	switch sz {
	case 1:
		return "%al"
	case 2:
		return "%ax"
	case 4:
		return "%eax"
	case 8:
		return "%rax"
	}
	unreachable()
	return "" //Won't be reached
}

// Compute the absolute address of a given node.
// It's an error if a given node does not reside in memory.
func gen_addr(node *Node) {
	switch node.kind {
	case ND_VAR:
		// Variable-length array, which is always local.
		if node.varr.ty.kind == TY_VLA {
			println("  mov %d(%%rbp), %%rax", node.varr.offset)
			return
		}

		// Local variable
		if node.varr.is_local {
			println("  lea %d(%%rbp), %%rax", node.varr.offset)
			return
		}

		if cg_opt_fpic {
			// Thread-local variable
			if node.varr.is_tls {
				println("  data16 lea %s@tlsgd(%%rip), %%rdi", node.varr.name)
				println("  .value 0x6666")
				println("  rex64")
				println("  call __tls_get_addr@PLT")
				return
			}

			// Function or global variable
			println("  mov %s@GOTPCREL(%%rip), %%rax", node.varr.name)
			return
		}

		// Thread-local variable
		if node.varr.is_tls {
			println("  mov %%fs:0, %%rax")
			println("  add $%s@tpoff, %%rax", node.varr.name)
			return
		}

		// Here, we generate an absolute address of a function or a global
		// variable. Even though they exist at a certain address at runtime,
		// their addresses are not known at link-time for the following
		// two reasons.
		//
		//  - Address randomization: Executables are loaded to memory as a
		//    whole but it is not known what address they are loaded to.
		//    Therefore, at link-time, relative address in the same
		//    exectuable (i.e. the distance between two functions in the
		//    same executable) is known, but the absolute address is not
		//    known.
		//
		//  - Dynamic linking: Dynamic shared objects (DSOs) or .so files
		//    are loaded to memory alongside an executable at runtime and
		//    linked by the runtime loader in memory. We know nothing
		//    about addresses of global stuff that may be defined by DSOs
		//    until the runtime relocation is complete.
		//
		// In order to deal with the former case, we use RIP-relative
		// addressing, denoted by `(%rip)`. For the latter, we obtain an
		// address of a stuff that may be in a shared object file from the
		// Global Offset Table using `@GOTPCREL(%rip)` notation.

		// Function
		if node.ty.kind == TY_FUNC {
			if node.varr.is_definition {
				println("  lea %s(%%rip), %%rax", node.varr.name)
			} else {
				println("  mov %s@GOTPCREL(%%rip), %%rax", node.varr.name)
			}
			return
		}

		// Global variable
		println("  lea %s(%%rip), %%rax", node.varr.name)
		return
	case ND_DEREF:
		gen_expr(node.lhs)
		return
	case ND_COMMA:
		gen_expr(node.lhs)
		gen_addr(node.rhs)
		return
	case ND_MEMBER:
		gen_addr(node.lhs)
		println("  add $%d, %%rax", node.member.offset)
		return
	case ND_FUNCALL:
		if node.ret_buffer != nil {
			gen_expr(node)
			return
		}
	case ND_ASSIGN, ND_COND:
		if node.ty.kind == TY_STRUCT || node.ty.kind == TY_UNION {
			gen_expr(node)
			return
		}
	case ND_VLA_PTR:
		println("  lea %d(%%rbp), %%rax", node.varr.offset)
		return
	}

	error_tok(node.tok, "not an lvalue")
}

// Load a value from where %rax is pointing to.
func load(ty *Type) {
	switch ty.kind {
	case TY_ARRAY, TY_STRUCT, TY_UNION, TY_FUNC, TY_VLA:
		// If it is an array, do not attempt to load a value to the
		// register because in general we can't load an entire array to a
		// register. As a result, the result of an evaluation of an array
		// becomes not the array itself but the address of the array.
		// This is where "array is automatically converted to a pointer to
		// the first element of the array in C" occurs.
		return
	case TY_FLOAT:
		println("  movss (%%rax), %%xmm0")
		return
	case TY_DOUBLE:
		println("  movsd (%%rax), %%xmm0")
		return
	}

	var insn string
	if ty.is_unsigned {
		insn = "movz"
	} else {
		insn = "movs"
	}

	// When we load a char or a short value to a register, we always
	// extend them to the size of int, so we can assume the lower half of
	// a register always contains a valid value. The upper half of a
	// register for char, short and int may contain garbage. When we load
	// a long value to a register, it simply occupies the entire register.
	if ty.size == 1 {
		println("  %sbl (%%rax), %%eax", insn)
	} else if ty.size == 2 {
		println("  %swl (%%rax), %%eax", insn)
	} else if ty.size == 4 {
		println("  movsxd (%%rax), %%rax")
	} else {
		println("  mov (%%rax), %%rax")
	}

}

// Store %rax to an address that the stack top is pointing to.
func store(ty *Type) {
	pop("%rdi")

	switch ty.kind {
	case TY_STRUCT, TY_UNION:
		for i := 0; i < ty.size; i++ {
			println("  mov %d(%%rax), %%r8b", i)
			println("  mov %%r8b, %d(%%rdi)", i)
		}
		return
	case TY_FLOAT:
		println("  movss %%xmm0, (%%rdi)")
		return
	case TY_DOUBLE:
		println("  movsd %%xmm0, (%%rdi)")
		return
	}

	if ty.size == 1 {
		println("  mov %%al, (%%rdi)")
	} else if ty.size == 2 {
		println("  mov %%ax, (%%rdi)")
	} else if ty.size == 4 {
		println("  mov %%eax, (%%rdi)")
	} else {
		println("  mov %%rax, (%%rdi)")
	}
}

func cmp_zero(ty *Type) {
	switch ty.kind {
	case TY_FLOAT:
		println("  xorps %%xmm1, %%xmm1")
		println("  ucomiss %%xmm1, %%xmm0")
		return
	case TY_DOUBLE:
		println("  xorpd %%xmm1, %%xmm1")
		println("  ucomisd %%xmm1, %%xmm0")
		return
	}

	if is_integer(ty) && ty.size <= 4 {
		println("  cmp $0, %%eax")
	} else {
		println("  cmp $0, %%rax")
	}
}

const (
	I8 = iota
	I16
	I32
	I64
	U8
	U16
	U32
	U64
	F32
	F64
)

func getTypeId(ty *Type) int {
	ret := 0

	uadd := 0
	if ty.is_unsigned {
		uadd = 4
	}

	switch ty.kind {
	case TY_CHAR:
		ret = I8
	case TY_SHORT:
		ret = I16
	case TY_INT:
		ret = I32
	case TY_FLOAT:
		ret = F32
	case TY_DOUBLE:
		ret = F64
	default:
		ret = I64
	}
	return ret + uadd
}

// The table for type casts
var i32i8 string = "movsbl %al, %eax"
var i32u8 string = "movzbl %al, %eax"
var i32i16 string = "movswl %ax, %eax"
var i32u16 string = "movzwl %ax, %eax"
var i32f32 string = "cvtsi2ssl %eax, %xmm0"
var i32i64 string = "movsxd %eax, %rax"
var i32f64 string = "cvtsi2sdl %eax, %xmm0"

var u32f32 string = "mov %eax, %eax; cvtsi2ssq %rax, %xmm0"
var u32i64 string = "mov %eax, %eax"
var u32f64 string = "mov %eax, %eax; cvtsi2sdq %rax, %xmm0"

var i64f32 string = "cvtsi2ssq %rax, %xmm0"
var i64f64 string = "cvtsi2sdq %rax, %xmm0"

var u64f32 string = "cvtsi2ssq %rax, %xmm0"
var u64f64 string = "test %rax,%rax; js 1f; pxor %xmm0,%xmm0; cvtsi2sd %rax,%xmm0; jmp 2f; " +
	"1: mov %rax,%rdi; and $1,%eax; pxor %xmm0,%xmm0; shr %rdi; " +
	"or %rax,%rdi; cvtsi2sd %rdi,%xmm0; addsd %xmm0,%xmm0; 2:"

var f32i8 string = "cvttss2sil %xmm0, %eax; movsbl %al, %eax"
var f32u8 string = "cvttss2sil %xmm0, %eax; movzbl %al, %eax"
var f32i16 string = "cvttss2sil %xmm0, %eax; movswl %ax, %eax"
var f32u16 string = "cvttss2sil %xmm0, %eax; movzwl %ax, %eax"
var f32i32 string = "cvttss2sil %xmm0, %eax"
var f32u32 string = "cvttss2siq %xmm0, %rax"
var f32i64 string = "cvttss2siq %xmm0, %rax"
var f32u64 string = "cvttss2siq %xmm0, %rax"
var f32f64 string = "cvtss2sd %xmm0, %xmm0"

var f64i8 string = "cvttsd2sil %xmm0, %eax; movsbl %al, %eax"
var f64u8 string = "cvttsd2sil %xmm0, %eax; movzbl %al, %eax"
var f64i16 string = "cvttsd2sil %xmm0, %eax; movswl %ax, %eax"
var f64u16 string = "cvttsd2sil %xmm0, %eax; movzwl %ax, %eax"
var f64i32 string = "cvttsd2sil %xmm0, %eax"
var f64u32 string = "cvttsd2siq %xmm0, %rax"
var f64f32 string = "cvtsd2ss %xmm0, %xmm0"
var f64i64 string = "cvttsd2siq %xmm0, %rax"
var f64u64 string = "cvttsd2siq %xmm0, %rax"

var cast_table = [10][10]string{
	// i8   i16     i32     i64     u8     u16     u32     u64     f32     f64
	{"", "", "", i32i64, i32u8, i32u16, "", i32i64, i32f32, i32f64},        // i8
	{i32i8, "", "", i32i64, i32u8, i32u16, "", i32i64, i32f32, i32f64},     // i16
	{i32i8, i32i16, "", i32i64, i32u8, i32u16, "", i32i64, i32f32, i32f64}, // i32
	{i32i8, i32i16, "", "", i32u8, i32u16, "", "", i64f32, i64f64},         // i64

	{i32i8, "", "", i32i64, "", "", "", i32i64, i32f32, i32f64},            // u8
	{i32i8, i32i16, "", i32i64, i32u8, "", "", i32i64, i32f32, i32f64},     // u16
	{i32i8, i32i16, "", u32i64, i32u8, i32u16, "", u32i64, u32f32, u32f64}, // u32
	{i32i8, i32i16, "", "", i32u8, i32u16, "", "", u64f32, u64f64},         // u64

	{f32i8, f32i16, f32i32, f32i64, f32u8, f32u16, f32u32, f32u64, "", f32f64}, // f32
	{f64i8, f64i16, f64i32, f64i64, f64u8, f64u16, f64u32, f64u64, f64f32, ""}, // f64
}

func gen_cast(from *Type, to *Type) {
	if to.kind == TY_VOID {
		return
	}

	if to.kind == TY_BOOL {
		cmp_zero(from)
		println("  setne %%al")
		println("  movzx %%al, %%eax")
		return
	}

	t1 := getTypeId(from)
	t2 := getTypeId(to)
	if cast_table[t1][t2] != "" {
		println("  %s", cast_table[t1][t2])
	}
}

func f32_as_u32(f32 float32) uint32 {
	var buf = []byte{0, 0, 0, 0}
	binary.LittleEndian.PutUint32(buf, math.Float32bits(f32))
	return binary.LittleEndian.Uint32(buf)
}

func f64_as_u64(f64 float64) uint64 {
	var buf = []byte{0, 0, 0, 0, 0, 0, 0, 0}
	binary.LittleEndian.PutUint64(buf, math.Float64bits(f64))
	return binary.LittleEndian.Uint64(buf)
}

// Structs or unions equal or smaller than 16 bytes are passed
// using up to two registers.
//
// If the first 8 bytes contains only floating-point type members,
// they are passed in an XMM register. Otherwise, they are passed
// in a general-purpose register.
//
// If a struct/union is larger than 8 bytes, the same rule is
// applied to the the next 8 byte chunk.
//
// This function returns true if `ty` has only floating-point
// members in its byte range [lo, hi).
func has_flonum(ty *Type, lo int, hi int, offset int) bool {
	if ty.kind == TY_STRUCT || ty.kind == TY_UNION {
		for mem := ty.members; mem != nil; mem = mem.next {
			if !has_flonum(mem.ty, lo, hi, offset+mem.offset) {
				return false
			}
		}
		return true
	}

	if ty.kind == TY_ARRAY {
		for i := 0; i < ty.array_len; i++ {
			if !has_flonum(ty.base, lo, hi, offset+ty.base.size*i) {
				return false
			}
		}
		return true
	}

	return offset < lo || hi <= offset || is_flonum(ty)
}

func has_flonum1(ty *Type) bool {
	return has_flonum(ty, 0, 8, 0)
}

func has_flonum2(ty *Type) bool {
	return has_flonum(ty, 8, 16, 0)
}

func push_struct(ty *Type) {
	sz := align_to(ty.size, 8)
	println("  sub $%d, %%rsp", sz)
	depth += sz / 8

	for i := 0; i < ty.size; i++ {
		println("  mov %d(%%rax), %%r10b", i)
		println("  mov %%r10b, %d(%%rsp)", i)
	}
}

func push_args2(args *Node, first_pass bool) {
	if nil == args {
		return
	}

	push_args2(args.next, first_pass)

	if (first_pass && !args.pass_by_stack) || (!first_pass && args.pass_by_stack) {
		return
	}

	gen_expr(args)

	switch args.ty.kind {
	case TY_STRUCT, TY_UNION:
		push_struct(args.ty)
	case TY_FLOAT, TY_DOUBLE:
		pushf()
	default:
		push()
	}
}

func bool2int(b bool) (int, int) {
	if b {
		return 1, 0
	}
	return 0, 1
}

// Load function call arguments. Arguments are already evaluated and
// stored to the stack as local variables. What we need to do in this
// function is to load them to registers or push them to the stack as
// specified by the x86-64 psABI. Here is what the spec says:
//
//   - Up to 6 arguments of integral type are passed using RDI, RSI,
//     RDX, RCX, R8 and R9.
//
//   - Up to 8 arguments of floating-point type are passed using XMM0 to
//     XMM7.
//
//   - If all registers of an appropriate type are already used, push an
//     argument to the stack in the right-to-left order.
//
//   - Each argument passed on the stack takes 8 bytes, and the end of
//     the argument area must be aligned to a 16 byte boundary.
//
//   - If a function is variadic, set the number of floating-point type
//     arguments to RAX.
func push_args(node *Node) int {
	stack, gp, fp := 0, 0, 0

	// If the return type is a large struct/union, the caller passes
	// a pointer to a buffer as if it were the first argument.
	if node.ret_buffer != nil && node.ty.size > 16 {
		gp++
	}

	// Load as many arguments to the registers as possible.
	for arg := node.args; arg != nil; arg = arg.next {
		ty := arg.ty

		switch ty.kind {
		case TY_STRUCT, TY_UNION:
			if ty.size > 16 {
				arg.pass_by_stack = true
				stack += align_to(ty.size, 8) / 8
			} else {
				fp1, notfp1 := bool2int(has_flonum1(ty))
				fp2, notfp2 := bool2int(has_flonum2(ty))

				if fp+fp1+fp2 < FP_MAX && gp+notfp1+notfp2 < GP_MAX {
					fp = fp + fp1 + fp2
					gp = gp + notfp1 + notfp2
				} else {
					arg.pass_by_stack = true
					stack += align_to(ty.size, 8) / 8
				}
			}
		case TY_FLOAT, TY_DOUBLE:
			if fp >= FP_MAX {
				arg.pass_by_stack = true
				stack++
			}
			fp++
		default:
			if gp >= GP_MAX {
				arg.pass_by_stack = true
				stack++
			}
			gp++
		}
	}

	if (depth+stack)%2 == 1 {
		println("  sub $8, %%rsp")
		depth++
		stack++
	}

	push_args2(node.args, true)
	push_args2(node.args, false)

	// If the return type is a large struct/union, the caller passes
	// a pointer to a buffer as if it were the first argument.
	if node.ret_buffer != nil && node.ty.size > 16 {
		println("  lea %d(%%rbp), %%rax", node.ret_buffer.offset)
		push()
	}

	return stack
}

func copy_ret_buffer(varr *Obj) {
	ty := varr.ty
	gp, fp := 0, 0

	if has_flonum1(ty) {
		myassert(ty.size == 4 || 8 <= ty.size)
		if ty.size == 4 {
			println("  movss %%xmm0, %d(%%rbp)", varr.offset)
		} else {
			println("  movsd %%xmm0, %d(%%rbp)", varr.offset)
		}
		fp++
	} else {
		for i := 0; i < min(8, ty.size); i++ {
			println("  mov %%al, %d(%%rbp)", varr.offset+i)
			println("  shr $8, %%rax")
		}
		gp++
	}

	if ty.size > 8 {
		if has_flonum2(ty) {
			myassert(ty.size == 12 || ty.size == 16)
			if ty.size == 12 {
				println("  movss %%xmm%d, %d(%%rbp)", fp, varr.offset+8)
			} else {
				println("  movsd %%xmm%d, %d(%%rbp)", fp, varr.offset+8)
			}
		} else {
			var reg1, reg2 string
			if gp == 0 {
				reg1 = "%al"
			} else {
				reg1 = "%dl"
			}
			if gp == 0 {
				reg2 = "%rax"
			} else {
				reg2 = "%rdx"
			}
			for i := 8; i < min(16, ty.size); i++ {
				println("  mov %s, %d(%%rbp)", reg1, varr.offset+i)
				println("  shr $8, %s", reg2)
			}
		}
	}
}

func copy_struct_reg() {
	ty := cg_current_fn.ty.return_ty
	gp, fp := 0, 0

	println("  mov %%rax, %%rdi")

	if has_flonum(ty, 0, 8, 0) {
		myassert(ty.size == 4 || 8 <= ty.size)
		if ty.size == 4 {
			println("  movss (%%rdi), %%xmm0")
		} else {
			println("  movsd (%%rdi), %%xmm0")
		}
		fp++
	} else {
		println("  mov $0, %%rax")
		for i := min(8, ty.size) - 1; i >= 0; i-- {
			println("  shl $8, %%rax")
			println("  mov %d(%%rdi), %%al", i)
		}
		gp++
	}

	if ty.size > 8 {
		if has_flonum(ty, 8, 16, 0) {
			myassert(ty.size == 12 || ty.size == 16)
			if ty.size == 4 {
				println("  movss 8(%%rdi), %%xmm%d", fp)
			} else {
				println("  movsd 8(%%rdi), %%xmm%d", fp)
			}
		} else {
			var reg1, reg2 string
			if gp == 0 {
				reg1 = "%al"
			} else {
				reg1 = "%dl"
			}
			if gp == 0 {
				reg2 = "%rax"
			} else {
				reg2 = "%rdx"
			}
			println("  mov $0, %s", reg2)
			for i := min(16, ty.size) - 1; i >= 8; i-- {
				println("  shl $8, %s", reg2)
				println("  mov %d(%%rdi), %s", i, reg1)
			}
		}
	}
}

func copy_struct_mem() {
	ty := cg_current_fn.ty.return_ty
	varr := cg_current_fn.params

	println("  mov %d(%%rbp), %%rdi", varr.offset)

	for i := 0; i < ty.size; i++ {
		println("  mov %d(%%rax), %%dl", i)
		println("  mov %%dl, %d(%%rdi)", i)
	}
}

func cg_builtin_alloca() {
	// Align size to 16 bytes.
	println("  add $15, %%rdi")
	println("  and $0xfffffff0, %%edi")

	// Shift the temporary area by %rdi.
	println("  mov %d(%%rbp), %%rcx", cg_current_fn.alloca_bottom.offset)
	println("  sub %%rsp, %%rcx")
	println("  mov %%rsp, %%rax")
	println("  sub %%rdi, %%rsp")
	println("  mov %%rsp, %%rdx")
	println("1:")
	println("  cmp $0, %%rcx")
	println("  je 2f")
	println("  mov (%%rax), %%r8b")
	println("  mov %%r8b, (%%rdx)")
	println("  inc %%rdx")
	println("  inc %%rax")
	println("  dec %%rcx")
	println("  jmp 1b")
	println("2:")

	// Move alloca_bottom pointer.
	println("  mov %d(%%rbp), %%rax", cg_current_fn.alloca_bottom.offset)
	println("  sub %%rdi, %%rax")
	println("  mov %%rax, %d(%%rbp)", cg_current_fn.alloca_bottom.offset)
}

// Generate code for a given node.
func gen_expr(node *Node) {
	println("  .loc %d %d", node.tok.file.file_no, node.tok.line_no)

	switch node.kind {
	case ND_NULL_EXPR:
		return
	case ND_NUM:
		var f32 float32
		var f64 float64

		switch node.ty.kind {
		case TY_FLOAT:
			f32 = float32(node.fval)
			println("  mov $%d, %%eax  # float %f", f32_as_u32(f32), f32)
			println("  movq %%rax, %%xmm0")
			return
		case TY_DOUBLE:
			f64 = node.fval
			println("  mov $%d, %%rax  # double %f", f64_as_u64(f64), f64)
			println("  movq %%rax, %%xmm0")
			return
		}

		println("  mov $%d, %%rax", node.val)
		return
	case ND_NEG:
		gen_expr(node.lhs)

		switch node.ty.kind {
		case TY_FLOAT:
			println("  mov $1, %%rax")
			println("  shl $31, %%rax")
			println("  movq %%rax, %%xmm1")
			println("  xorps %%xmm1, %%xmm0")
			return
		case TY_DOUBLE:
			println("  mov $1, %%rax")
			println("  shl $63, %%rax")
			println("  movq %%rax, %%xmm1")
			println("  xorpd %%xmm1, %%xmm0")
			return
		}
		println("  neg %%rax")
		return
	case ND_VAR:
		gen_addr(node)
		load(node.ty)
		return
	case ND_MEMBER:
		gen_addr(node)
		load(node.ty)

		mem := node.member
		if mem.is_bitfield {
			println("  shl $%d, %%rax", 64-mem.bit_width-mem.bit_offset)
			if mem.ty.is_unsigned {
				println("  shr $%d, %%rax", 64-mem.bit_width)
			} else {
				println("  sar $%d, %%rax", 64-mem.bit_width)
			}
		}
		return
	case ND_DEREF:
		gen_expr(node.lhs)
		load(node.ty)
		return
	case ND_ADDR:
		gen_addr(node.lhs)
		return
	case ND_ASSIGN:
		gen_addr(node.lhs)
		push()
		gen_expr(node.rhs)

		if node.lhs.kind == ND_MEMBER && node.lhs.member.is_bitfield {
			println("  mov %%rax, %%r8")

			// If the lhs is a bitfield, we need to read the current value
			// from memory and merge it with a new value.
			mem := node.lhs.member
			println("  mov %%rax, %%rdi")
			println("  and $%d, %%rdi", (1<<mem.bit_width)-1)
			println("  shl $%d, %%rdi", mem.bit_offset)

			println("  mov (%%rsp), %%rax")
			load(mem.ty)

			mask := ((1 << mem.bit_width) - 1) << mem.bit_offset
			println("  mov $%d, %%r9", ^mask)
			println("  and %%r9, %%rax")
			println("  or %%rdi, %%rax")
			store(node.ty)
			println("  mov %%r8, %%rax")
			return
		}

		store(node.ty)
		return
	case ND_STMT_EXPR:
		for n := node.body; n != nil; n = n.next {
			gen_stmt(n)
		}
		return
	case ND_COMMA:
		gen_expr(node.lhs)
		gen_expr(node.rhs)
		return
	case ND_CAST:
		gen_expr(node.lhs)
		gen_cast(node.lhs.ty, node.ty)
		return
	case ND_MEMZERO:
		// `rep stosb` is equivalent to `memset(%rdi, %al, %rcx)`.
		println("  mov $%d, %%rcx", node.varr.ty.size)
		println("  lea %d(%%rbp), %%rdi", node.varr.offset)
		println("  mov $0, %%al")
		println("  rep stosb")
		return
	case ND_COND:
		c := count()
		gen_expr(node.cond)
		cmp_zero(node.cond.ty)
		println("  je .L.else.%d", c)
		gen_expr(node.then)
		println("  jmp .L.end.%d", c)
		println(".L.else.%d:", c)
		gen_expr(node.els)
		println(".L.end.%d:", c)
		return
	case ND_NOT:
		gen_expr(node.lhs)
		cmp_zero(node.lhs.ty)
		println("  sete %%al")
		println("  movzx %%al, %%rax")
		return
	case ND_BITNOT:
		gen_expr(node.lhs)
		println("  not %%rax")
		return
	case ND_LOGAND:
		c := count()
		gen_expr(node.lhs)
		cmp_zero(node.lhs.ty)
		println("  je .L.false.%d", c)
		gen_expr(node.rhs)
		cmp_zero(node.rhs.ty)
		println("  je .L.false.%d", c)
		println("  mov $1, %%rax")
		println("  jmp .L.end.%d", c)
		println(".L.false.%d:", c)
		println("  mov $0, %%rax")
		println(".L.end.%d:", c)
		return
	case ND_LOGOR:
		c := count()
		gen_expr(node.lhs)
		cmp_zero(node.lhs.ty)
		println("  jne .L.true.%d", c)
		gen_expr(node.rhs)
		cmp_zero(node.rhs.ty)
		println("  jne .L.true.%d", c)
		println("  mov $0, %%rax")
		println("  jmp .L.end.%d", c)
		println(".L.true.%d:", c)
		println("  mov $1, %%rax")
		println(".L.end.%d:", c)
		return
	case ND_FUNCALL:
		if node.lhs.kind == ND_VAR && node.lhs.varr.name == "alloca" {
			gen_expr(node.args)
			println("  mov %%rax, %%rdi")
			cg_builtin_alloca()
			return
		}

		stack_args := push_args(node)
		gen_expr(node.lhs)

		gp, fp := 0, 0

		// If the return type is a large struct/union, the caller passes
		// a pointer to a buffer as if it were the first argument.
		if node.ret_buffer != nil && node.ty.size > 16 {
			pop(argreg64[gp])
			gp++
		}

		for arg := node.args; arg != nil; arg = arg.next {
			ty := arg.ty

			switch ty.kind {
			case TY_STRUCT, TY_UNION:
				if ty.size > 16 {
					continue
				}

				fp1, notfp1 := bool2int(has_flonum1(ty))
				fp2, notfp2 := bool2int(has_flonum2(ty))

				if fp+fp1+fp2 < FP_MAX && gp+notfp1+notfp2 < GP_MAX {
					if fp1 != 0 {
						popf(fp)
						fp++
					} else {
						pop(argreg64[gp])
						gp++
					}

					if ty.size > 8 {
						if fp2 != 0 {
							popf(fp)
							fp++
						} else {
							pop(argreg64[gp])
							gp++
						}
					}
				}
			case TY_FLOAT, TY_DOUBLE:
				if fp < FP_MAX {
					popf(fp)
					fp++
				}
			default:
				if gp < GP_MAX {
					pop(argreg64[gp])
					gp++
				}
			}
		}

		println("  mov %%rax, %%r10")
		println("  mov $%d, %%rax", fp)
		println("  call *%%r10")
		println("  add $%d, %%rsp", stack_args*8)

		depth -= stack_args

		// It looks like the most significant 48 or 56 bits in RAX may
		// contain garbage if a function return type is short or bool/char,
		// respectively. We clear the upper bits here.
		switch node.ty.kind {
		case TY_BOOL:
			println("  movzx %%al, %%eax")
			return
		case TY_CHAR:
			if node.ty.is_unsigned {
				println("  movzbl %%al, %%eax")

			} else {
				println("  movsbl %%al, %%eax")
			}
			return
		case TY_SHORT:
			if node.ty.is_unsigned {
				println("  movzwl %%ax, %%eax")

			} else {
				println("  movswl %%ax, %%eax")
			}
			return
		}

		// If the return type is a small struct, a value is returned
		// using up to two registers.
		if node.ret_buffer != nil && node.ty.size <= 16 {
			copy_ret_buffer(node.ret_buffer)
			println("  lea %d(%%rbp), %%rax", node.ret_buffer.offset)
		}
		return

	case ND_LABEL_VAL:
		println("  lea %s(%%rip), %%rax", node.unique_label)
		return

	case ND_CAS:
		gen_expr(node.cas_addr)
		push()
		gen_expr(node.cas_new)
		push()
		gen_expr(node.cas_old)
		println("  mov %%rax, %%r8")
		load(node.cas_old.ty.base)
		pop("%rdx") // new
		pop("%rdi") // addr

		sz := node.cas_addr.ty.base.size
		println("  lock cmpxchg %s, (%%rdi)", reg_dx(sz))
		println("  sete %%cl")
		println("  je 1f")
		println("  mov %s, (%%r8)", reg_ax(sz))
		println("1:")
		println("  movzbl %%cl, %%eax")
		return
	case ND_EXCH:
		gen_expr(node.lhs)
		push()
		gen_expr(node.rhs)
		pop("%rdi")

		sz := node.lhs.ty.base.size
		println("  xchg %s, (%%rdi)", reg_ax(sz))
		return
	}

	if is_flonum(node.lhs.ty) {
		gen_expr(node.rhs)
		pushf()
		gen_expr(node.lhs)
		popf(1)

		var sz string
		if node.lhs.ty.kind == TY_FLOAT {
			sz = "ss"
		} else {
			sz = "sd"
		}

		switch node.kind {
		case ND_ADD:
			println("  add%s %%xmm1, %%xmm0", sz)
			return
		case ND_SUB:
			println("  sub%s %%xmm1, %%xmm0", sz)
			return
		case ND_MUL:
			println("  mul%s %%xmm1, %%xmm0", sz)
			return
		case ND_DIV:
			println("  div%s %%xmm1, %%xmm0", sz)
			return
		case ND_EQ, ND_NE, ND_LT, ND_LE:
			println("  ucomi%s %%xmm0, %%xmm1", sz)

			if node.kind == ND_EQ {
				println("  sete %%al")
				println("  setnp %%dl")
				println("  and %%dl, %%al")
			} else if node.kind == ND_NE {
				println("  setne %%al")
				println("  setp %%dl")
				println("  or %%dl, %%al")
			} else if node.kind == ND_LT {
				println("  seta %%al")
			} else {
				println("  setae %%al")
			}

			println("  and $1, %%al")
			println("  movzb %%al, %%rax")
			return
		}

		error_tok(node.tok, "invalid expression")
	}

	gen_expr(node.rhs)
	push()
	gen_expr(node.lhs)
	pop("%rdi")

	var ax, di, dx string

	if node.lhs.ty.kind == TY_LONG || node.lhs.ty.base != nil {
		ax = "%rax"
		di = "%rdi"
		dx = "%rdx"
	} else {
		ax = "%eax"
		di = "%edi"
		dx = "%edx"
	}

	kind := node.kind
	switch kind {
	case ND_ADD:
		println("  add %s, %s", di, ax)
		return
	case ND_SUB:
		println("  sub %s, %s", di, ax)
		return
	case ND_MUL:
		println("  imul %s, %s", di, ax)
		return
	case ND_DIV, ND_MOD:
		if node.ty.is_unsigned {
			println("  mov $0, %s", dx)
			println("  div %s", di)
		} else {
			if node.lhs.ty.size == 8 {
				println("  cqo")
			} else {
				println("  cdq")
			}
			println("  idiv %s", di)
		}

		if node.kind == ND_MOD {
			println("  mov %%rdx, %%rax")
		}
		return
	case ND_BITAND:
		println("  and %s, %s", di, ax)
		return
	case ND_BITOR:
		println("  or %s, %s", di, ax)
		return
	case ND_BITXOR:
		println("  xor %s, %s", di, ax)
		return
	case ND_EQ, ND_NE, ND_LT, ND_LE:
		println("  cmp %s, %s", di, ax)

		if kind == ND_EQ {
			println("  sete %%al")
		} else if node.kind == ND_NE {
			println("  setne %%al")
		} else if node.kind == ND_LT {
			if node.lhs.ty.is_unsigned {
				println("  setb %%al")
			} else {
				println("  setl %%al")
			}
		} else if node.kind == ND_LE {
			if node.lhs.ty.is_unsigned {
				println("  setbe %%al")
			} else {
				println("  setle %%al")
			}
		}

		println("  movzb %%al, %%rax")
		return
	case ND_SHL:
		println("  mov %%rdi, %%rcx")
		println("  shl %%cl, %s", ax)
		return
	case ND_SHR:
		println("  mov %%rdi, %%rcx")
		if node.lhs.ty.is_unsigned {
			println("  shr %%cl, %s", ax)
		} else {
			println("  sar %%cl, %s", ax)
		}
		return
	}

	error_tok(node.tok, "invalid expression")
}

func gen_stmt(node *Node) {
	println("  .loc %d %d", node.tok.file.file_no, node.tok.line_no)

	switch node.kind {
	case ND_IF:
		c := count()
		gen_expr(node.cond)
		cmp_zero(node.cond.ty)
		println("  je  .L.else.%d", c)
		gen_stmt(node.then)
		println("  jmp .L.end.%d", c)
		println(".L.else.%d:", c)
		if node.els != nil {
			gen_stmt(node.els)
		}
		println(".L.end.%d:", c)
		return
	case ND_FOR:
		c := count()
		if node.init != nil {
			gen_stmt(node.init)
		}
		println(".L.begin.%d:", c)
		if node.cond != nil {
			gen_expr(node.cond)
			cmp_zero(node.cond.ty)
			println("  je %s", node.brk_label)
		}
		gen_stmt(node.then)
		println("%s:", node.cont_label)
		if node.inc != nil {
			gen_expr(node.inc)
		}
		println("  jmp .L.begin.%d", c)
		println("%s:", node.brk_label)
		return
	case ND_DO:
		c := count()
		println(".L.begin.%d:", c)
		gen_stmt(node.then)
		println("%s:", node.cont_label)
		gen_expr(node.cond)
		cmp_zero(node.cond.ty)
		println("  jne .L.begin.%d", c)
		println("%s:", node.brk_label)
		return
	case ND_SWITCH:
		gen_expr(node.cond)

		for n := node.case_next; n != nil; n = n.case_next {
			var ax, di string
			if node.cond.ty.size == 8 {
				ax = "%rax"
				di = "%rdi"
			} else {
				ax = "%eax"
				di = "%edi"
			}

			if n.begin == n.end {
				println("  cmp $%d, %s", n.begin, ax)
				println("  je %s", n.label)
				continue
			}

			// [GNU] Case ranges
			println("  mov %s, %s", ax, di)
			println("  sub $%d, %s", n.begin, di)
			println("  cmp $%d, %s", n.end-n.begin, di)
			println("  jbe %s", n.label)
		}

		if node.default_case != nil {
			println("  jmp %s", node.default_case.label)
		}

		println("  jmp %s", node.brk_label)
		gen_stmt(node.then)
		println("%s:", node.brk_label)
		return
	case ND_CASE:
		println("%s:", node.label)
		gen_stmt(node.lhs)
		return
	case ND_BLOCK:
		for n := node.body; n != nil; n = n.next {
			gen_stmt(n)
		}
		return
	case ND_GOTO:
		println("  jmp %s", node.unique_label)
		return
	case ND_GOTO_EXPR:
		gen_expr(node.lhs)
		println("  jmp *%%rax")
		return
	case ND_LABEL:
		println("%s:", node.unique_label)
		gen_stmt(node.lhs)
		return
	case ND_RETURN:
		if node.lhs != nil {
			gen_expr(node.lhs)

			ty := node.lhs.ty
			if ty.kind == TY_STRUCT || ty.kind == TY_UNION {
				if ty.size <= 16 {
					copy_struct_reg()
				} else {
					copy_struct_mem()
				}
			}
		}

		println("  jmp .L.return.%s", cg_current_fn.name)
		return
	case ND_EXPR_STMT:
		gen_expr(node.lhs)
		return
	case ND_ASM:
		println("  %s", node.asm_str)
		return
	}

	error_tok(node.tok, "invalid statement")
}

// Assign offsets to local variables.
func assign_lvar_offsets(prog *Obj) {
	for fn := prog; fn != nil; fn = fn.next {
		if !fn.is_function {
			continue
		}

		// If a function has many parameters, some parameters are
		// inevitably passed by stack rather than by register.
		// The first passed-by-stack parameter resides at RBP+16.
		top := 16
		bottom := 0

		gp, fp := 0, 0

		// Assign offsets to pass-by-stack parameters.
		for varr := fn.params; varr != nil; varr = varr.next {
			ty := varr.ty

			switch ty.kind {
			case TY_STRUCT, TY_UNION:
				if ty.size <= 16 {
					fp1, notfp1 := bool2int(has_flonum(ty, 0, 8, 0))
					fp2, notfp2 := bool2int(has_flonum(ty, 8, 16, 8))
					if fp+fp1+fp2 < FP_MAX && gp+notfp1+notfp2 < GP_MAX {
						fp = fp + fp1 + fp2
						gp = gp + notfp1 + notfp2
						continue
					}
				}
			case TY_FLOAT, TY_DOUBLE:
				if fp < FP_MAX {
					fp++
					continue
				}
			default:
				if gp < GP_MAX {
					gp++
					continue
				}
			}

			top = align_to(top, 8)
			varr.offset = top
			top += varr.ty.size
		}

		// Assign offsets to pass-by-register parameters and local variables.
		for varr := fn.locals; varr != nil; varr = varr.next {
			if varr.offset != 0 {
				continue
			}

			// AMD64 System V ABI has a special alignment rule for an array of
			// length at least 16 bytes. We need to align such array to at least
			// 16-byte boundaries. See p.14 of
			// https://github.com/hjl-tools/x86-psABI/wiki/x86-64-psABI-draft.pdf.
			var align int
			if varr.ty.kind == TY_ARRAY && varr.ty.size >= 16 {
				align = max(16, varr.align)
			} else {
				align = varr.align
			}

			bottom += varr.ty.size
			bottom = align_to(bottom, align)
			varr.offset = -bottom
		}

		fn.stack_size = align_to(bottom, 16)
	}
}

func emit_data(prog *Obj, opt_fcommon bool) {
	for varr := prog; varr != nil; varr = varr.next {
		if varr.is_function || !varr.is_definition {
			continue
		}

		if varr.is_static {
			println("  .local %s", varr.name)
		} else {
			println("  .globl %s", varr.name)
		}

		var align int
		if varr.ty.kind == TY_ARRAY && varr.ty.size >= 16 {
			align = max(16, varr.align)
		} else {
			align = varr.align
		}

		// Common symbol
		if opt_fcommon && varr.is_tentative {
			println("  .comm %s, %d, %d", varr.name, varr.ty.size, align)
			continue
		}

		// .data or .tdata
		if varr.init_data != nil {
			if varr.is_tls {
				println("  .section .tdata,\"awT\",@progbits")
			} else {
				println("  .data")
			}

			println("  .type %s, @object", varr.name)
			println("  .size %s, %d", varr.name, varr.ty.size)
			println("  .align %d", align)
			println("%s:", varr.name)

			rel := varr.rel
			pos := 0
			for pos < varr.ty.size {
				if rel != nil && rel.offset == pos {
					println("  .quad %s%+d", *rel.label, rel.addend)
					rel = rel.next
					pos += 8
				} else {
					println("  .byte %d", varr.init_data[pos])
					pos++
				}
			}
			continue
		}

		// .bss or .tbss
		if varr.is_tls {
			println("  .section .tbss,\"awT\",@nobits")
		} else {
			println("  .bss")
		}

		println("  .align %d", align)
		println("%s:", varr.name)
		println("  .zero %d", varr.ty.size)
	}
}

func store_fp(r int, offset int, sz int) {
	switch sz {
	case 4:
		println("  movss %%xmm%d, %d(%%rbp)", r, offset)
		return
	case 8:
		println("  movsd %%xmm%d, %d(%%rbp)", r, offset)
		return
	}
	unreachable()
}

func store_gp(r int, offset int, sz int) {
	switch sz {
	case 1:
		println("  mov %s, %d(%%rbp)", argreg8[r], offset)
		return
	case 2:
		println("  mov %s, %d(%%rbp)", argreg16[r], offset)
		return
	case 4:
		println("  mov %s, %d(%%rbp)", argreg32[r], offset)
		return
	case 8:
		println("  mov %s, %d(%%rbp)", argreg64[r], offset)
		return
	default:
		for i := 0; i < sz; i++ {
			println("  mov %s, %d(%%rbp)", argreg8[r], offset+i)
			println("  shr $8, %s", argreg64[r])
		}
		return
	}
}

func emit_text(prog *Obj) {
	for fn := prog; fn != nil; fn = fn.next {
		if !fn.is_function || !fn.is_definition {
			continue
		}

		// No code is emitted for "static inline" functions
		// if no one is referencing them.
		if !fn.is_live {
			continue
		}

		if fn.is_static {
			println("  .local %s", fn.name)
		} else {
			println("  .globl %s", fn.name)
		}
		println("  .text")
		println("  .type %s, @function", fn.name)
		println("%s:", fn.name)
		cg_current_fn = fn

		// Prologue
		println("  push %%rbp")
		println("  mov %%rsp, %%rbp")
		println("  sub $%d, %%rsp", fn.stack_size)
		println("  mov %%rsp, %d(%%rbp)", fn.alloca_bottom.offset)

		// Save arg registers if function is variadic
		if fn.va_area != nil {
			gp := 0
			fp := 0
			for varr := fn.params; varr != nil; varr = varr.next {
				if is_flonum(varr.ty) {
					fp++
				} else {
					gp++
				}
			}

			off := fn.va_area.offset

			// va_elem
			println("  movl $%d, %d(%%rbp)", gp*8, off)      // gp_offset
			println("  movl $%d, %d(%%rbp)", fp*8+48, off+4) // fp_offset
			println("  movq %%rbp, %d(%%rbp)", off+8)        // overflow_arg_area
			println("  addq $16, %d(%%rbp)", off+8)
			println("  movq %%rbp, %d(%%rbp)", off+16) // reg_save_area
			println("  addq $%d, %d(%%rbp)", off+24, off+16)

			// __reg_save_area__
			println("  movq %%rdi, %d(%%rbp)", off+24)
			println("  movq %%rsi, %d(%%rbp)", off+32)
			println("  movq %%rdx, %d(%%rbp)", off+40)
			println("  movq %%rcx, %d(%%rbp)", off+48)
			println("  movq %%r8, %d(%%rbp)", off+56)
			println("  movq %%r9, %d(%%rbp)", off+64)
			println("  movsd %%xmm0, %d(%%rbp)", off+72)
			println("  movsd %%xmm1, %d(%%rbp)", off+80)
			println("  movsd %%xmm2, %d(%%rbp)", off+88)
			println("  movsd %%xmm3, %d(%%rbp)", off+96)
			println("  movsd %%xmm4, %d(%%rbp)", off+104)
			println("  movsd %%xmm5, %d(%%rbp)", off+112)
			println("  movsd %%xmm6, %d(%%rbp)", off+120)
			println("  movsd %%xmm7, %d(%%rbp)", off+128)
		}

		// Save passed-by-register arguments to the stack
		gp := 0
		fp := 0
		for varr := fn.params; varr != nil; varr = varr.next {
			if varr.offset > 0 {
				continue
			}

			ty := varr.ty

			switch ty.kind {
			case TY_STRUCT, TY_UNION:
				myassert(ty.size <= 16)
				if has_flonum(ty, 0, 8, 0) {
					store_fp(fp, varr.offset, min(8, ty.size))
					fp++
				} else {
					store_gp(gp, varr.offset, min(8, ty.size))
					gp++
				}

				if ty.size > 8 {
					if has_flonum(ty, 8, 16, 0) {
						store_fp(fp, varr.offset+8, ty.size-8)
						fp++
					} else {
						store_gp(gp, varr.offset+8, ty.size-8)
						gp++
					}
				}
			case TY_FLOAT, TY_DOUBLE:
				store_fp(fp, varr.offset, ty.size)
				fp++
			default:
				store_gp(gp, varr.offset, ty.size)
				gp++
			}
		}

		// Emit code
		gen_stmt(fn.body)
		myassert(depth == 0)

		// [https://www.sigbus.info/n1570#5.1.2.2.3p1] The C spec defines
		// a special rule for the main function. Reaching the end of the
		// main function is equivalent to returning 0, even though the
		// behavior is undefined for the other functions.
		if fn.name == "main" {
			println("  mov $0, %%rax")
		}

		// Epilogue
		println(".L.return.%s:", fn.name)
		println("  mov %%rbp, %%rsp")
		println("  pop %%rbp")
		println("  ret")
	}
	println("")
	println("  .section .note.GNU-stack,\"\",@progbits")
}

func codegen(prog *Obj, out *os.File, opt_fcommon bool, opt_fpic bool) {
	cg_output_file = out
	cg_opt_fpic = opt_fpic

	files := get_input_files()
	for _, f := range files {
		println("  .file %d \"%s\"", f.file_no, f.name)
	}

	assign_lvar_offsets(prog)
	emit_data(prog, opt_fcommon)
	emit_text(prog)
}

//
// Own additions
//

func myassert(condition bool) {
	if !condition {
		if _, file, line, ok := runtime.Caller(1); ok {
			panic(fmt.Sprintf("Assert failed in file: %s, line: %d\n", file, line))
		}
		panic("Assert failed, runtime info not available")
	}
}
