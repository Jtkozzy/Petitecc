package main

// This file implements the C preprocessor.
//
// The preprocessor takes a list of tokens as an input and returns a
// new list of tokens as an output.
//
// The preprocessing language is designed in such a way that that's
// guaranteed to stop even if there is a recursive macro.
// Informally speaking, a macro is applied only once for each token.
// That is, if a macro token T appears in a result of direct or
// indirect macro expansion of T, T won't be expanded any further.
// For example, if T is defined as U, and U is defined as T, then
// token T is expanded to U and then to T and the macro expansion
// stops at that point.
//
// To achieve the above behavior, we attach for each token a set of
// macro names from which the token is expanded. The set is called
// "hideset". Hideset is initially empty, and every time we expand a
// macro, the macro name is added to the resulting tokens' hidesets.
//
// The above macro expansion algorithm is explained in this document
// written by Dave Prossor, which is used as a basis for the
// standard's wording:
// https://github.com/rui314/chibicc/wiki/cpp.algo.pdf

import (
	"bytes"
	"fmt"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
	"unicode/utf8"
)

type MacroParam struct {
	next *MacroParam
	name string
}

type MacroArg struct {
	next       *MacroArg
	name       string
	is_va_args bool
	tok        *Token
}

type macro_handler_fn func(*Token) *Token

type Macro struct {
	name         string
	is_objlike   bool // Object-like or function-like
	params       *MacroParam
	va_args_name string
	body         *Token
	handler      macro_handler_fn
}

// `#if` can be nested, so we use a stack to manage nested `#if`s.
const (
	IN_THEN = iota
	IN_ELIF
	IN_ELSE
)

type CondIncl struct {
	next     *CondIncl
	ctx      int //IN_THEN, IN_ELIF or IN_ELSE
	tok      *Token
	included bool
}

type Hideset struct {
	next *Hideset
	name string
}

var macros map[string]*Macro = make(map[string]*Macro)
var cond_incl *CondIncl
var pragma_once map[string]bool = make(map[string]bool)
var include_next_idx int

func is_hash(tok *Token) bool {
	return tok.at_bol && equal(tok, "#")
}

// Some preprocessor directives such as #include allow extraneous
// tokens before newline. This function skips such tokens.
func skip_line(tok *Token) *Token {
	if tok.at_bol {
		return tok
	}
	warn_tok(tok, "extra token")
	for tok.at_bol {
		tok = tok.next
	}
	return tok
}

func copy_token(tok *Token) *Token {
	t := &Token{}
	*t = *tok
	t.next = nil
	return t
}

func new_eof(tok *Token) *Token {
	t := copy_token(tok)
	t.kind = TK_EOF
	return t
}

func new_hideset(name string) *Hideset {
	hs := &Hideset{}
	hs.name = name
	return hs
}

func hideset_union(hs1 *Hideset, hs2 *Hideset) *Hideset {
	head := Hideset{}
	cur := &head

	for hs1 != nil {
		cur.next = new_hideset(hs1.name)
		cur = cur.next
		hs1 = hs1.next
	}
	cur.next = hs2
	return head.next
}

func hideset_contains(hs *Hideset, s string) bool {
	for hs != nil {
		if hs.name == s {
			return true
		}
		hs = hs.next
	}
	return false
}

func hideset_intersection(hs1 *Hideset, hs2 *Hideset) *Hideset {
	head := Hideset{}
	cur := &head

	for hs1 != nil {
		if hideset_contains(hs2, hs1.name) {
			cur.next = new_hideset(hs1.name)
			cur = cur.next
		}
		hs1 = hs1.next
	}
	return head.next
}

func add_hideset(tok *Token, hs *Hideset) *Token {
	head := Token{}
	cur := &head

	for tok != nil {
		t := copy_token(tok)
		t.hideset = hideset_union(t.hideset, hs)
		cur.next = t
		cur = cur.next
		tok = tok.next
	}
	return head.next
}

// Append tok2 to the end of tok1.
func tokappend(tok1 *Token, tok2 *Token) *Token {
	if tok1.kind == TK_EOF {
		return tok2
	}

	head := Token{}
	cur := &head

	for tok1.kind != TK_EOF {
		cur.next = copy_token(tok1)
		cur = cur.next
		tok1 = tok1.next
	}
	cur.next = tok2
	return head.next
}

func strip_zero(tok *Token) string {
	return strings.TrimSuffix(tok.lexeme, string(byte(0)))
}

func skip_cond_incl2(tok *Token) *Token {
	for tok.kind != TK_EOF {
		if is_hash(tok) &&
			(equal(tok.next, "if") || equal(tok.next, "ifdef") ||
				equal(tok.next, "ifndef")) {
			tok = skip_cond_incl2(tok.next.next)
			continue
		}
		if is_hash(tok) && equal(tok.next, "endif") {
			return tok.next.next
		}
		tok = tok.next
	}
	return tok
}

// Skip until next `#else`, `#elif` or `#endif`.
// Nested `#if` and `#endif` are skipped.
func skip_cond_incl(tok *Token) *Token {
	for tok.kind != TK_EOF {
		if is_hash(tok) &&
			(equal(tok.next, "if") || equal(tok.next, "ifdef") ||
				equal(tok.next, "ifndef")) {
			tok = skip_cond_incl2(tok.next.next)
			continue
		}

		if is_hash(tok) &&
			(equal(tok.next, "elif") || equal(tok.next, "else") || equal(tok.next, "endif")) {
			break
		}
		tok = tok.next
	}
	return tok
}

// Double-quote a given string and returns it.
func quote_string(str string) string {
	return strconv.Quote(str)
}

func new_str_token(str string, tmpl *Token) *Token {
	buf := quote_string(str)
	return tokenize(new_file(tmpl.file.name, tmpl.file.file_no, buf))
}

// Copy all tokens until the next newline, terminate them with
// an EOF token and then returns them. This function is used to
// create a new list of tokens for `#if` arguments.
func copy_line(rest **Token, tok *Token) *Token {
	head := Token{}
	cur := &head

	for !tok.at_bol {
		cur.next = copy_token(tok)
		cur = cur.next
		tok = tok.next
	}

	cur.next = new_eof(tok)
	*rest = tok
	return head.next
}

func new_num_token(val int, tmpl *Token) *Token {
	buf := fmt.Sprintf(" %d \n", val)
	return tokenize(new_file(tmpl.file.name, tmpl.file.file_no, buf))
}

func read_const_expr(rest **Token, tok *Token) *Token {
	tok = copy_line(rest, tok)

	head := Token{}
	cur := &head

	for tok.kind != TK_EOF {
		// "defined(foo)" or "defined foo" becomes "1" if macro "foo"
		// is defined. Otherwise "0".
		if equal(tok, "defined") {
			start := tok
			has_paren := consume(&tok, tok.next, "(")

			if tok.kind != TK_IDENT {
				error_tok(start, "macro name must be an identifier")
			}
			m := find_macro(tok)
			tok = tok.next

			if has_paren {
				tok = skip(tok, ")")
			}

			num := 0
			if m != nil {
				num = 1
			}
			cur.next = new_num_token(num, start)
			cur = cur.next
			continue
		}

		cur.next = tok
		cur = cur.next
		tok = tok.next
	}

	cur.next = tok
	return head.next
}

// Read and evaluate a constant expression.
func eval_const_expr(rest **Token, tok *Token) int64 {
	start := tok
	expr := read_const_expr(rest, tok.next)
	expr = preprocess2(expr)

	if expr.kind == TK_EOF {
		error_tok(start, "no expression")
	}

	// [https://www.sigbus.info/n1570#6.10.1p4] The standard requires
	// we replace remaining non-macro identifiers with "0" before
	// evaluating a constant expression. For example, `#if foo` is
	// equivalent to `#if 0` if foo is not defined.
	for t := expr; t.kind != TK_EOF; t = t.next {
		if t.kind == TK_IDENT {
			next := t.next
			*t = *new_num_token(0, t)
			t.next = next
		}
	}

	// Convert pp-numbers to regular numbers
	convert_pp_tokens(expr)

	var rest2 *Token
	val := const_expr(&rest2, expr)
	if rest2.kind != TK_EOF {
		error_tok(rest2, "extra token")
	}
	return val
}

func push_cond_incl(tok *Token, included bool) *CondIncl {
	ci := &CondIncl{}
	ci.next = cond_incl
	ci.ctx = IN_THEN
	ci.tok = tok
	ci.included = included
	cond_incl = ci
	return ci
}

func find_macro(tok *Token) *Macro {
	if tok.kind != TK_IDENT {
		return nil
	}
	return macros[tok.lexeme]
}

func add_macro(name string, is_objlike bool, body *Token) *Macro {
	m := &Macro{}
	m.name = name
	m.is_objlike = is_objlike
	m.body = body
	macros[name] = m
	return m
}

func read_macro_params(rest **Token, tok *Token, va_args_name *string) *MacroParam {
	head := MacroParam{}
	cur := &head

	for !equal(tok, ")") {
		if cur != &head {
			tok = skip(tok, ",")
		}

		if equal(tok, "...") {
			*va_args_name = "__VA_ARGS__"
			*rest = skip(tok.next, ")")
			return head.next
		}

		if tok.kind != TK_IDENT {
			error_tok(tok, "expected an identifier")
		}

		if equal(tok.next, "...") {
			*va_args_name = tok.lexeme
			*rest = skip(tok.next.next, ")")
			return head.next
		}

		m := &MacroParam{}
		m.name = tok.lexeme
		cur.next = m
		cur = cur.next
		tok = tok.next
	}

	*rest = tok.next
	return head.next
}

func read_macro_definition(rest **Token, tok *Token) {
	if tok.kind != TK_IDENT {
		error_tok(tok, "macro name must be an identifier")
	}
	name := tok.lexeme
	tok = tok.next

	if !tok.has_space && equal(tok, "(") {
		// Function-like macro
		va_args_name := ""
		params := read_macro_params(&tok, tok.next, &va_args_name)

		m := add_macro(name, false, copy_line(rest, tok))
		m.params = params
		m.va_args_name = va_args_name
	} else {
		// Object-like macro
		add_macro(name, true, copy_line(rest, tok))
	}
}

func read_macro_arg_one(rest **Token, tok *Token, read_rest bool) *MacroArg {
	head := Token{}
	cur := &head
	level := 0

	for {
		if level == 0 && equal(tok, ")") {
			break
		}
		if level == 0 && !read_rest && equal(tok, ",") {
			break
		}

		if tok.kind == TK_EOF {
			error_tok(tok, "premature end of input")
		}

		if equal(tok, "(") {
			level++
		} else if equal(tok, ")") {
			level--
		}

		cur.next = copy_token(tok)
		cur = cur.next
		tok = tok.next
	}

	cur.next = new_eof(tok)

	arg := &MacroArg{}
	arg.tok = head.next
	*rest = tok
	return arg
}

func read_macro_args(rest **Token, tok *Token, params *MacroParam, va_args_name string) *MacroArg {
	start := tok
	tok = tok.next.next

	head := MacroArg{}
	cur := &head

	pp := params
	for pp != nil {
		if cur != &head {
			tok = skip(tok, ",")
		}
		cur.next = read_macro_arg_one(&tok, tok, false)
		cur = cur.next
		cur.name = pp.name
		pp = pp.next
	}

	if "" != va_args_name {
		var arg *MacroArg
		if equal(tok, ")") {
			arg = &MacroArg{}
			arg.tok = new_eof(tok)
		} else {
			if pp != params {
				tok = skip(tok, ",")
			}
			arg = read_macro_arg_one(&tok, tok, true)
		}
		arg.name = va_args_name
		arg.is_va_args = true
		cur.next = arg
		cur = cur.next
	} else if pp != nil {
		error_tok(start, "too many arguments")
	}

	skip(tok, ")")
	*rest = tok
	return head.next
}

func find_arg(args *MacroArg, tok *Token) *MacroArg {
	for ap := args; ap != nil; ap = ap.next {
		if tok.lexeme == ap.name {
			return ap
		}
	}
	return nil
}

// Concatenates all tokens in `tok` and returns a new string.
func join_tokens(tok *Token, end *Token) string {
	var bld strings.Builder

	// Copy token texts.
	for t := tok; t != end && t.kind != TK_EOF; t = t.next {
		if t != tok && t.has_space {
			bld.WriteByte(' ')
		}

		if t.kind == TK_STR {
			for i := 0; i < len(t.raw); i++ {
				bld.WriteByte(t.raw[i])
			}
		} else {
			bld.WriteString(t.lexeme)
		}
	}
	return bld.String()
}

// func get_bytes_of_string(s string) string {
// 	var bld strings.Builder
// 	for i := 0; i < len(s); i++ {
// 		by := s[i]
// 		if by != 0 {
// 			bld.WriteString(fmt.Sprintf(" %d (%c)", by, by))
// 		}
// 	}
// 	return bld.String()
// }

// Concatenates all tokens in `arg` and returns a new string token.
// This function is used for the stringizing operator (#).
func stringize(hash *Token, arg *Token) *Token {
	// Create a new string token. We need to set some value to its
	// source location for error reporting function, so we use a macro
	// name token as a template.
	s := join_tokens(arg, nil)
	//logfile.Write([]byte(fmt.Sprintf("Stringize #1: %s\n", get_bytes_of_string(s))))
	t := new_str_token(s, hash)
	//logfile.Write([]byte(fmt.Sprintf("Stringize #2: %s\n", get_bytes_of_string(t.lexeme))))
	return t
}

// Concatenate two tokens to create a new token.
func paste(lhs *Token, rhs *Token) *Token {
	// Paste the two tokens.
	buf := fmt.Sprintf(" %s%s ", lhs.lexeme, rhs.lexeme)

	// Tokenize the resulting string.
	tok := tokenize(new_file(lhs.file.name, lhs.file.file_no, buf))
	if tok.next.kind != TK_EOF {
		error_tok(lhs, "pasting forms '%s', an invalid token", buf)
	}
	return tok
}

func has_varargs(args *MacroArg) bool {
	for ap := args; ap != nil; ap = ap.next {
		if ap.name == "__VA_ARGS__" {
			return ap.tok.kind != TK_EOF
		}
	}
	return false
}

// Replace func-like macro parameters with given arguments.
func subst(tok *Token, args *MacroArg) *Token {
	head := Token{}
	cur := &head

	for tok.kind != TK_EOF {
		// "#" followed by a parameter is replaced with stringized actuals.
		if equal(tok, "#") {
			arg := find_arg(args, tok.next)
			if nil == arg {
				error_tok(tok.next, "'#' is not followed by a macro parameter")
			}
			cur.next = stringize(tok, arg.tok)
			cur = cur.next
			tok = tok.next.next
			continue
		}

		// [GNU] If __VA_ARG__ is empty, `,##__VA_ARGS__` is expanded
		// to the empty token list. Otherwise, its expaned to `,` and
		// __VA_ARGS__.
		if equal(tok, ",") && equal(tok.next, "##") {
			arg := find_arg(args, tok.next.next)
			if arg != nil && arg.is_va_args {
				if arg.tok.kind == TK_EOF {
					tok = tok.next.next.next
				} else {
					cur.next = copy_token(tok)
					cur = cur.next
					tok = tok.next.next
				}
				continue
			}
		}

		if equal(tok, "##") {
			if cur == &head {
				error_tok(tok, "'##' cannot appear at start of macro expansion")
			}

			if tok.next.kind == TK_EOF {
				error_tok(tok, "'##' cannot appear at end of macro expansion")
			}

			arg := find_arg(args, tok.next)
			if arg != nil {
				if arg.tok.kind != TK_EOF {
					*cur = *paste(cur, arg.tok)
					for t := arg.tok.next; t.kind != TK_EOF; t = t.next {
						cur.next = copy_token(t)
						cur = cur.next
					}
				}
				tok = tok.next.next
				continue
			}

			*cur = *paste(cur, tok.next)
			tok = tok.next.next
			continue
		}

		arg := find_arg(args, tok)

		if arg != nil && equal(tok.next, "##") {
			rhs := tok.next.next

			if arg.tok.kind == TK_EOF {
				arg2 := find_arg(args, rhs)
				if arg2 != nil {
					for t := arg2.tok; t.kind != TK_EOF; t = t.next {
						cur.next = copy_token(t)
						cur = cur.next
					}
				} else {
					cur.next = copy_token(rhs)
					cur = cur.next
				}
				tok = rhs.next
				continue
			}

			for t := arg.tok; t.kind != TK_EOF; t = t.next {
				cur.next = copy_token(t)
				cur = cur.next
			}
			tok = tok.next
			continue
		}

		// If __VA_ARG__ is empty, __VA_OPT__(x) is expanded to the
		// empty token list. Otherwise, __VA_OPT__(x) is expanded to x.
		if equal(tok, "__VA_OPT__") && equal(tok.next, "(") {
			arg := read_macro_arg_one(&tok, tok.next.next, true)
			if has_varargs(args) {
				for t := arg.tok; t.kind != TK_EOF; t = t.next {
					cur.next = t
					cur = cur.next
				}
			}
			tok = skip(tok, ")")
			continue
		}

		// Handle a macro token. Macro arguments are completely macro-expanded
		// before they are substituted into a macro body.
		if arg != nil {
			t := preprocess2(arg.tok)
			t.at_bol = tok.at_bol
			t.has_space = tok.has_space
			for t.kind != TK_EOF {
				cur.next = copy_token(t)
				cur = cur.next
				t = t.next
			}
			tok = tok.next
			continue
		}

		// Handle a non-macro token.
		cur.next = copy_token(tok)
		cur = cur.next
		tok = tok.next
		continue
	}

	cur.next = tok
	return head.next
}

// If tok is a macro, expand it and return true.
// Otherwise, do nothing and return false.
func expand_macro(rest **Token, tok *Token) bool {
	if hideset_contains(tok.hideset, tok.lexeme) {
		return false
	}

	m := find_macro(tok)
	if nil == m {
		return false
	}

	// Built-in dynamic macro application such as __LINE__
	if m.handler != nil {
		*rest = m.handler(tok)
		(*rest).next = tok.next
		return true
	}

	// Object-like macro application
	if m.is_objlike {
		hs := hideset_union(tok.hideset, new_hideset(m.name))
		body := add_hideset(m.body, hs)
		for t := body; t.kind != TK_EOF; t = t.next {
			t.origin = tok
		}
		*rest = tokappend(body, tok.next)
		(*rest).at_bol = tok.at_bol
		(*rest).has_space = tok.has_space
		return true
	}

	// If a funclike macro token is not followed by an argument list,
	// treat it as a normal identifier.
	if !equal(tok.next, "(") {
		return false
	}

	// Function-like macro application
	macro_token := tok
	args := read_macro_args(&tok, tok, m.params, m.va_args_name)
	rparen := tok

	// Tokens that consist a func-like macro invocation may have different
	// hidesets, and if that's the case, it's not clear what the hideset
	// for the new tokens should be. We take the interesection of the
	// macro token and the closing parenthesis and use it as a new hideset
	// as explained in the Dave Prossor's algorithm.
	hs := hideset_intersection(macro_token.hideset, rparen.hideset)
	hs = hideset_union(hs, new_hideset(m.name))

	body := subst(m.body, args)
	body = add_hideset(body, hs)
	for t := body; t.kind != TK_EOF; t = t.next {
		t.origin = macro_token
	}
	*rest = tokappend(body, tok.next)
	(*rest).at_bol = macro_token.at_bol
	(*rest).has_space = macro_token.has_space
	return true
}

var cache map[string]string = make(map[string]string)

func search_include_paths(filename string) string {
	if filename[0] == '/' {
		return filename
	}

	cached := cache[filename]
	if cached != "" {
		return cached
	}

	// Search a file from the include paths.
	for i := 0; i < len(include_paths); i++ {
		path := fmt.Sprintf("%s/%s", include_paths[i], filename)
		if !file_exists(path) {
			continue
		}
		cache[filename] = path
		include_next_idx = i + 1
		return path
	}
	return ""
}

func search_include_next(filename string) string {
	for include_next_idx < len(include_paths) {
		path := fmt.Sprintf("%s/%s", include_paths[include_next_idx], filename)
		if file_exists(path) {
			return path
		}
		include_next_idx++
	}
	return ""
}

// Read an #include argument.
func read_include_filename(rest **Token, tok *Token, is_dquote *bool) string {
	// Pattern 1: #include "foo.h"
	if tok.kind == TK_STR {
		// A double-quoted filename for #include is a special kind of
		// token, and we don't want to interpret any escape sequences in it.
		// For example, "\f" in "C:\foo" is not a formfeed character but
		// just two non-control characters, backslash and f.
		// So we don't want to use token->str.
		*is_dquote = true
		*rest = skip_line(tok.next)
		return strip_zero(tok)
	}

	// Pattern 2: #include <foo.h>
	if equal(tok, "<") {
		// Reconstruct a filename from a sequence of tokens between
		// "<" and ">".
		start := tok

		// Find closing ">".
		for !equal(tok, ">") {
			if tok.at_bol || tok.kind == TK_EOF {
				error_tok(tok, "expected '>'")
			}
			tok = tok.next
		}

		*is_dquote = false
		*rest = skip_line(tok.next)
		return join_tokens(start.next, tok)
	}

	// Pattern 3: #include FOO
	// In this case FOO must be macro-expanded to either
	// a single string token or a sequence of "<" ... ">".
	if tok.kind == TK_IDENT {
		tok2 := preprocess2(copy_line(rest, tok))
		return read_include_filename(&tok2, tok2, is_dquote)
	}

	error_tok(tok, "expected a filename")
	return "" //Won't be reached
}

// Detect the following "include guard" pattern.
//
//	#ifndef FOO_H
//	#define FOO_H
//	...
//	#endif
func detect_include_guard(tok *Token) string {
	// Detect the first two lines.
	if !is_hash(tok) || !equal(tok.next, "ifndef") {
		return ""
	}
	tok = tok.next.next

	if tok.kind != TK_IDENT {
		return ""
	}

	macro := tok.lexeme
	tok = tok.next

	if !is_hash(tok) || !equal(tok.next, "define") || !equal(tok.next.next, macro) {
		return ""
	}

	// Read until the end of the file.
	for tok.kind != TK_EOF {
		if !is_hash(tok) {
			tok = tok.next
			continue
		}

		if equal(tok.next, "endif") && tok.next.next.kind == TK_EOF {
			return macro
		}

		if equal(tok, "if") || equal(tok, "ifdef") || equal(tok, "ifndef") {
			tok = skip_cond_incl(tok.next)
		} else {
			tok = tok.next
		}
	}
	return ""
}

var include_guards map[string]string = make(map[string]string)

func include_file(tok *Token, path string, filename_tok *Token) *Token {
	// Check for "#pragma once"
	if pragma_once[path] {
		return tok
	}

	// If we read the same file before, and if the file was guarded
	// by the usual #ifndef ... #endif pattern, we may be able to
	// skip the file without opening it.
	guard_name := include_guards[path]
	if guard_name != "" && macros[guard_name] != nil {
		return tok
	}

	tok2, err := tokenize_file(path)
	if err != nil {
		error_tok(filename_tok, "cannot open file: %s, error: %v", path, err)
	}

	guard_name = detect_include_guard(tok2)
	if guard_name != "" {
		include_guards[path] = guard_name
	}

	return tokappend(tok2, tok)
}

// Read #line arguments
func read_line_marker(rest **Token, tok *Token) {
	start := tok
	tok = preprocess(copy_line(rest, tok))

	if tok.kind != TK_NUM || tok.ty.kind != TY_INT {
		error_tok(tok, "invalid line marker")
	}
	start.file.line_delta = int(tok.val) - start.line_no

	tok = tok.next
	if tok.kind == TK_EOF {
		return
	}

	if tok.kind != TK_STR {
		error_tok(tok, "filename expected")
	}
	start.file.display_name = tok.lexeme
}

// Visit all tokens in `tok` while evaluating preprocessing
// macros and directives.
func preprocess2(tok *Token) *Token {
	head := Token{}
	cur := &head

	for tok.kind != TK_EOF {
		// If it is a macro, expand it.
		if expand_macro(&tok, tok) {
			continue
		}

		// Pass through if it is not a "#".
		if !is_hash(tok) {
			tok.line_delta = tok.file.line_delta
			tok.filename = tok.file.display_name
			cur.next = tok
			cur = cur.next
			tok = tok.next
			continue
		}

		start := tok
		tok = tok.next

		if equal(tok, "include") {
			var is_dquote bool
			filename := read_include_filename(&tok, tok.next, &is_dquote)

			if filename[0] != '/' && is_dquote {
				path := fmt.Sprintf("%s/%s", filepath.Dir(start.file.name), filename)
				if file_exists(path) {
					tok = include_file(tok, path, start.next.next)
					continue
				}
			}

			path := search_include_paths(filename)
			var s string
			if path != "" {
				s = path
			} else {
				s = filename
			}
			tok = include_file(tok, s, start.next.next)
			continue
		}

		if equal(tok, "include_next") {
			var _ignore bool
			filename := read_include_filename(&tok, tok.next, &_ignore)
			path := search_include_next(filename)

			if path != "" {
				tok = include_file(tok, path, start.next.next)
			} else {
				tok = include_file(tok, filename, start.next.next)
			}
			continue
		}

		if equal(tok, "define") {
			read_macro_definition(&tok, tok.next)
			continue
		}

		if equal(tok, "undef") {
			tok = tok.next
			if tok.kind != TK_IDENT {
				error_tok(tok, "macro name must be an identifier")
			}
			undef_macro(tok.lexeme)
			tok = skip_line(tok.next)
			continue
		}

		if equal(tok, "if") {
			val := eval_const_expr(&tok, tok)
			push_cond_incl(start, val != 0)
			if 0 == val {
				tok = skip_cond_incl(tok)
			}
			continue
		}

		if equal(tok, "ifdef") {
			defined := (nil != find_macro(tok.next))
			push_cond_incl(tok, defined)
			tok = skip_line(tok.next.next)
			if !defined {
				tok = skip_cond_incl(tok)
			}
			continue
		}

		if equal(tok, "ifndef") {
			defined := (nil != find_macro(tok.next))
			push_cond_incl(tok, !defined)
			tok = skip_line(tok.next.next)
			if defined {
				tok = skip_cond_incl(tok)
			}
			continue
		}

		if equal(tok, "elif") {
			if nil == cond_incl || cond_incl.ctx == IN_ELSE {
				error_tok(start, "stray #elif")
			}
			cond_incl.ctx = IN_ELIF

			if !cond_incl.included && (0 != eval_const_expr(&tok, tok)) {
				cond_incl.included = true
			} else {
				tok = skip_cond_incl(tok)
			}
			continue
		}

		if equal(tok, "else") {
			if nil == cond_incl || cond_incl.ctx == IN_ELSE {
				error_tok(start, "stray #else")
			}
			cond_incl.ctx = IN_ELSE
			tok = skip_line(tok.next)

			if cond_incl.included {
				tok = skip_cond_incl(tok)
			}
			continue
		}

		if equal(tok, "endif") {
			if nil == cond_incl {
				error_tok(start, "stray #endif")
			}
			cond_incl = cond_incl.next
			tok = skip_line(tok.next)
			continue
		}

		if equal(tok, "line") {
			read_line_marker(&tok, tok.next)
			continue
		}

		if tok.kind == TK_PP_NUM {
			read_line_marker(&tok, tok)
			continue
		}

		if equal(tok, "pragma") && equal(tok.next, "once") {
			pragma_once[tok.file.name] = true
			tok = skip_line(tok.next.next)
			continue
		}

		if equal(tok, "pragma") {
			for {
				tok = tok.next
				if tok.at_bol {
					break
				}
			}
			continue
		}

		if equal(tok, "error") {
			error_tok(tok, "error")
		}

		// `#`-only line is legal. It's called a null directive.
		if tok.at_bol {
			continue
		}

		error_tok(tok, "invalid preprocessor directive")
	}

	cur.next = tok
	return head.next
}

func define_macro(name string, buf string) {
	tok := tokenize(new_file("<built-in>", 1, fmt.Sprintf("%s ", buf)))
	add_macro(name, true, tok)
}

func undef_macro(name string) {
	delete(macros, name)
}

func add_builtin(name string, fn macro_handler_fn) *Macro {
	m := add_macro(name, true, nil)
	m.handler = fn
	return m
}

func file_macro(tmpl *Token) *Token {
	for tmpl.origin != nil {
		tmpl = tmpl.origin
	}
	return new_str_token(tmpl.file.display_name, tmpl)
}

func line_macro(tmpl *Token) *Token {
	for tmpl.origin != nil {
		tmpl = tmpl.origin
	}
	i := tmpl.line_no + tmpl.file.line_delta
	return new_num_token(i, tmpl)
}

// __COUNTER__ is expanded to serial values starting from 0.
var ctr_mac_ctr = 0

func counter_macro(tmpl *Token) *Token {
	tok := new_num_token(ctr_mac_ctr, tmpl)
	ctr_mac_ctr++
	return tok
}

var now time.Time

// __TIMESTAMP__ is expanded to a string describing the last
// modification time of the current file. E.g.
// "Fri Jul 24 01:32:50 2020"
func timestamp_macro(tmpl *Token) *Token {
	return new_str_token(now.Format(time.ANSIC), tmpl)
}

func base_file_macro(tmpl *Token) *Token {
	return new_str_token(base_file, tmpl)
}

var months = [12]string{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}

// __DATE__ is expanded to the current date, e.g. "May 17 2020".
func format_date() string {
	year, mon, day := now.Date()
	return fmt.Sprintf("\"%s %2d %d\"", months[mon-1], day, year)
}

// __TIME__ is expanded to the current time, e.g. "13:34:03".
func format_time() string {
	return fmt.Sprintf("\"%02d:%02d:%02d\"", now.Hour(), now.Minute(), now.Second())
}

func init_macros() {
	// Define predefined macros
	define_macro("_LP64", "1")
	define_macro("__C99_MACRO_WITH_VA_ARGS", "1")
	define_macro("__ELF__", "1")
	define_macro("__LP64__", "1")
	define_macro("__SIZEOF_DOUBLE__", "8")
	define_macro("__SIZEOF_FLOAT__", "4")
	define_macro("__SIZEOF_INT__", "4")
	define_macro("__SIZEOF_LONG_DOUBLE__", "8")
	define_macro("__SIZEOF_LONG_LONG__", "8")
	define_macro("__SIZEOF_LONG__", "8")
	define_macro("__SIZEOF_POINTER__", "8")
	define_macro("__SIZEOF_PTRDIFF_T__", "8")
	define_macro("__SIZEOF_SHORT__", "2")
	define_macro("__SIZEOF_SIZE_T__", "8")
	define_macro("__SIZE_TYPE__", "unsigned long")
	define_macro("__STDC_HOSTED__", "1")
	define_macro("__STDC_NO_COMPLEX__", "1")
	define_macro("__STDC_UTF_16__", "1")
	define_macro("__STDC_UTF_32__", "1")
	define_macro("__STDC_VERSION__", "201112L")
	define_macro("__STDC__", "1")
	define_macro("__USER_LABEL_PREFIX__", "")
	define_macro("__alignof__", "_Alignof")
	define_macro("__amd64", "1")
	define_macro("__amd64__", "1")
	define_macro("__chibicc__", "1")
	define_macro("__const__", "const")
	define_macro("__gnu_linux__", "1")
	define_macro("__inline__", "inline")
	define_macro("__linux", "1")
	define_macro("__linux__", "1")
	define_macro("__signed__", "signed")
	define_macro("__typeof__", "typeof")
	define_macro("__unix", "1")
	define_macro("__unix__", "1")
	define_macro("__volatile__", "volatile")
	define_macro("__x86_64", "1")
	define_macro("__x86_64__", "1")
	define_macro("linux", "1")
	define_macro("unix", "1")

	add_builtin("__FILE__", file_macro)
	add_builtin("__LINE__", line_macro)
	add_builtin("__COUNTER__", counter_macro)
	now = time.Now().Local()
	add_builtin("__TIMESTAMP__", timestamp_macro)
	add_builtin("__BASE_FILE__", base_file_macro)

	define_macro("__DATE__", format_date())
	define_macro("__TIME__", format_time())
}

type StringKind int

const (
	STR_NONE = iota
	STR_UTF8
	STR_UTF16
	STR_UTF32
	STR_WIDE
)

func getStringKind(tok *Token) StringKind {
	if bytes.HasPrefix(tok.raw, []byte("u8")) {
		return STR_UTF8
	}

	switch tok.raw[0] {
	case '"':
		return STR_NONE
	case 'u':
		return STR_UTF16
	case 'U':
		return STR_UTF32
	case 'L':
		return STR_WIDE
	}
	unreachable()
	return STR_NONE //Won't be reached
}

func from_str_to_strXX(size int, s string, has_oct_hex_escape bool) ([]uint32, []uint16, int) {
	if utf8.Valid([]byte(s)) && !has_oct_hex_escape {
		//Nominal case: valid utf-8
		if size == 2 {
			var buf []uint16
			for _, r := range string(s) {
				buf = utf16.AppendRune(buf, r)
			}
			return nil, buf, len(buf)
		} else {
			var buf []uint32
			for _, r := range s {
				buf = append(buf, uint32(r))
			}
			return buf, nil, len(buf)
		}
	} else {
		//..the *other* case, some random stream of bytes :)
		if size == 2 {
			var buf []uint16
			for i := 0; i < len(s); i++ {
				buf = append(buf, uint16(s[i]))
			}
			return nil, buf, len(buf)
		} else {
			var buf []uint32
			for i := 0; i < len(s); i++ {
				buf = append(buf, uint32(s[i]))
			}
			return buf, nil, len(buf)
		}
	}
}

// Concatenate adjacent string literals into a single string literal
// as per the C spec.
func join_adjacent_string_literals(tok *Token) {
	// First pass: If regular string literals are adjacent to wide
	// string literals, regular string literals are converted to a wide
	// type before concatenation. In this pass, we do the conversion.
	tok1 := tok

	for tok1.kind != TK_EOF {
		if tok1.kind != TK_STR || tok1.next.kind != TK_STR {
			tok1 = tok1.next
			continue
		}

		kind := getStringKind(tok1)
		basety := tok1.ty.base

		for t := tok1.next; t.kind == TK_STR; t = t.next {
			k := getStringKind(t)
			if kind == STR_NONE {
				kind = k
				basety = t.ty.base
			} else if k != STR_NONE && kind != k {
				error_tok(t, "unsupported non-standard concatenation of string literals")
			}
		}

		if basety.size > 1 {
			for t := tok1; t.kind == TK_STR; t = t.next {
				if t.ty.base.size == 1 {
					var l int
					t.str32, t.str16, l = from_str_to_strXX(basety.size, t.lexeme, t.has_oct_or_hex_escape)
					t.ty = array_of(basety, l)
				}
			}
		}

		for tok1.kind == TK_STR {
			tok1 = tok1.next
		}
	}

	// Second pass: concatenate adjacent string literals
	tok1 = tok
	for tok1.kind != TK_EOF {
		if tok1.kind != TK_STR || tok1.next.kind != TK_STR {
			tok1 = tok1.next
			continue
		}

		tok2 := tok1.next
		for tok2.kind == TK_STR {
			tok2 = tok2.next
		}

		switch tok1.ty.base.size {
		case 1:
			var bld strings.Builder
			for t := tok1; t != tok2; t = t.next {
				bld.WriteString(strip_zero(t))
			}
			bld.WriteByte(0)
			s := bld.String()
			*tok1 = *copy_token(tok1)
			tok1.ty = array_of(tok1.ty.base, len(s))
			tok1.lexeme = s
		case 2:
			var bld []uint16
			for t := tok1; t != tok2; t = t.next {
				for i := 0; i < len(t.str16)-1; i++ {
					bld = append(bld, t.str16[i])
				}
			}
			bld = append(bld, uint16(0))
			*tok1 = *copy_token(tok1)
			tok1.ty = array_of(tok1.ty.base, len(bld))
			tok1.str16 = bld
		case 4:
			var bld []uint32
			for t := tok1; t != tok2; t = t.next {
				for i := 0; i < len(t.str32)-1; i++ {
					bld = append(bld, t.str32[i])
				}
			}
			bld = append(bld, uint32(0))
			*tok1 = *copy_token(tok1)
			tok1.ty = array_of(tok1.ty.base, len(bld))
			tok1.str32 = bld
		}

		tok1.next = tok2
		tok1 = tok2
	}
}

// Entry point function of the preprocessor.
func preprocess(tok *Token) *Token {
	init_macros()
	tok = preprocess2(tok)
	if cond_incl != nil {
		error_tok(cond_incl.tok, "unterminated conditional directive")
	}
	convert_pp_tokens(tok)
	join_adjacent_string_literals(tok)

	for t := tok; t != nil; t = t.next {
		t.line_no += t.line_delta
	}

	return tok
}
