#define foo 4
