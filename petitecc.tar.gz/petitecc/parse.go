package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"strings"
)

// This file contains a recursive descent parser for C.
//
// Most functions in this file are named after the symbols they are
// supposed to read from an input token list. For example, stmt() is
// responsible for reading a statement from a token list. The function
// then construct an AST node representing a statement.
//
// Each function conceptually returns two values, an AST node and
// remaining part of the input tokens. Since C doesn't support
// multiple return values, the remaining tokens are returned to the
// caller via a pointer argument.
// NOTE (Jari Korhonen): out of laziness, I use this on Go version too.
//
// Input tokens are represented by a linked list. Unlike many recursive
// descent parsers, we don't have the notion of the "input token stream".
// Most parsing functions don't change the global state of the parser.
// So it is very easy to lookahead arbitrary number of tokens in this
// parser.

//
// Parser
//

// Variable or function
type Obj struct {
	next     *Obj
	name     string // Variable name
	ty       *Type  // Type
	tok      *Token // representative token
	is_local bool   // local or global/function
	align    int    // alignment

	// Local variable
	offset int

	// Global variable or function
	is_function   bool
	is_definition bool
	is_static     bool

	// Global variable
	is_tentative bool
	is_tls       bool
	init_data    []byte
	rel          *Relocation

	// Function
	is_inline     bool
	params        *Obj
	body          *Node
	locals        *Obj
	va_area       *Obj
	alloca_bottom *Obj
	stack_size    int

	// Static inline function
	is_live bool
	is_root bool
	refs    []string
}

// Global variable can be initialized either by a constant expression
// or a pointer to another global variable. This struct represents the
// latter.
type Relocation struct {
	next   *Relocation
	offset int
	label  *string
	addend int64
}

type NodeKind int

// AST node
const (
	ND_NULL_EXPR = iota // Do nothing
	ND_ADD              // +
	ND_SUB              // -
	ND_MUL              // *
	ND_DIV              // /
	ND_NEG              // unary -
	ND_MOD              // %
	ND_BITAND           // &
	ND_BITOR            // |
	ND_BITXOR           // ^
	ND_SHL              // <<
	ND_SHR              // >>
	ND_EQ               // ==
	ND_NE               // !=
	ND_LT               // <
	ND_LE               // <=
	ND_ASSIGN           // =
	ND_COND             // ?:
	ND_COMMA            // ,
	ND_MEMBER           // . (struct member access)
	ND_ADDR             // unary &
	ND_DEREF            // unary *
	ND_NOT              // !
	ND_BITNOT           // ~
	ND_LOGAND           // &&
	ND_LOGOR            // ||
	ND_RETURN           // "return"
	ND_IF               // "if"
	ND_FOR              // "for" or "while"
	ND_DO               // "do"
	ND_SWITCH           // "switch"
	ND_CASE             // "case"
	ND_BLOCK            // { ... }
	ND_GOTO             // "goto"
	ND_GOTO_EXPR        // "goto" labels-as-values
	ND_LABEL            // Labeled statement
	ND_LABEL_VAL        // [GNU] Labels-as-values
	ND_FUNCALL          // Function call
	ND_EXPR_STMT        // Expression statement
	ND_STMT_EXPR        // Statement expression
	ND_VAR              // Variable
	ND_VLA_PTR          // VLA designator
	ND_NUM              // Integer
	ND_CAST             // Type cast
	ND_MEMZERO          // Zero-clear a stack variable
	ND_ASM              // "asm"
	ND_CAS              // Atomic compare-and-swap
	ND_EXCH             // Atomic exchange
)

// AST node type
type Node struct {
	kind NodeKind // Node kind
	next *Node    // Next node
	ty   *Type    // Type, e.g. int or pointer to int
	tok  *Token   // Representative token

	lhs *Node // Left-hand side
	rhs *Node // Right-hand side

	// "if" or "for" statement
	cond *Node
	then *Node
	els  *Node
	init *Node
	inc  *Node

	// "break" and "continue" labels
	brk_label  string
	cont_label string

	// Block or statement expression
	body *Node

	// Struct member access
	member *Member

	// Function call
	func_ty       *Type
	args          *Node
	pass_by_stack bool
	ret_buffer    *Obj

	// Goto or labeled statement, or labels-as-values
	label        string
	unique_label string
	goto_next    *Node

	// Switch
	case_next    *Node
	default_case *Node

	// Case
	begin int64
	end   int64

	// "asm" string literal
	asm_str string

	// Atomic compare-and-swap
	cas_addr *Node
	cas_old  *Node
	cas_new  *Node

	// Atomic op= operators
	atomic_addr *Obj
	atomic_expr *Node

	// Variable
	varr *Obj

	// Numeric literal
	val  int64
	fval float64
}

// Scope for local variables, global variables, typedefs
// or enum constants
type VarScope struct {
	varr     *Obj
	type_def *Type
	enum_ty  *Type
	enum_val int
}

// Represents a block scope.
type Scope struct {
	next *Scope

	// C has two block scopes; one is for variables/typedefs and
	// the other is for struct/union/enum tags.
	vars map[string]*VarScope
	tags map[string]*Type
}

// Variable attributes such as typedef or extern.
type VarAttr struct {
	is_typedef bool
	is_static  bool
	is_extern  bool
	is_inline  bool
	is_tls     bool
	align      int
}

// This struct represents a variable initializer. Since initializers
// can be nested (e.g. `int x[2][2] = {{1, 2}, {3, 4}}`), this struct
// is a tree data structure.
type Initializer struct {
	next        *Initializer
	ty          *Type
	tok         *Token
	is_flexible bool

	// If it's not an aggregate type and has an initializer,
	// `expr` has an initialization expression.
	expr *Node

	// If it's an initializer for an aggregate type (e.g. array or struct),
	// `children` has initializers for its children.
	children []*Initializer

	// Only one member can be initialized for a union.
	// `mem` is used to clarify which member is initialized.
	mem *Member
}

// For local variable initializer.
type InitDesg struct {
	next   *InitDesg
	idx    int
	member *Member
	varr   *Obj
}

// All local variable instances created during parsing are
// accumulated to this list.
var locals *Obj

// Likewise, global variables are accumulated to this list.
var globals *Obj

var scope *Scope = &Scope{next: nil, vars: make(map[string]*VarScope), tags: make(map[string]*Type)}

// Points to the function object the parser is currently parsing.
var parse_current_fn *Obj

// Lists of all goto statements and labels in the curent function.
var gotos *Node
var labels *Node

// Current "goto" and "continue" jump targets.
var brk_label string
var cont_label string

// Points to a node representing a switch if we are parsing
// a switch statement. Otherwise, nil.
var current_switch *Node

var builtin_alloca *Obj

func align_down(n int, align int) int {
	return align_to(n-align+1, align)
}

func enter_scope() {
	sc := Scope{next: nil, vars: make(map[string]*VarScope), tags: make(map[string]*Type)}
	sc.next = scope
	scope = &sc
}

func leave_scope() {
	scope = scope.next
}

// Find a local (or global) variable by name.
func find_var(tok *Token) *VarScope {
	for sc := scope; sc != nil; sc = sc.next {
		sc2 := sc.vars[tok.lexeme]
		if sc2 != nil {
			return sc2
		}
	}
	return nil
}

func find_tag(tok *Token) *Type {
	for sc := scope; sc != nil; sc = sc.next {
		ty := sc.tags[tok.lexeme]
		if ty != nil {
			return ty
		}
	}
	return nil
}

func new_node(kind NodeKind, tok *Token) *Node {
	return &Node{kind: kind, tok: tok, lhs: nil, rhs: nil, val: 0}
}

func new_binary(kind NodeKind, lhs *Node, rhs *Node, tok *Token) *Node {
	node := new_node(kind, tok)
	node.lhs = lhs
	node.rhs = rhs
	return node
}

func new_unary(kind NodeKind, expr *Node, tok *Token) *Node {
	node := new_node(kind, tok)
	node.lhs = expr
	return node
}

func new_num(val int64, tok *Token) *Node {
	node := new_node(ND_NUM, tok)
	node.val = val
	return node
}

func new_long(val int64, tok *Token) *Node {
	node := new_node(ND_NUM, tok)
	node.val = val
	node.ty = ty_long
	return node
}

func new_ulong(val int64, tok *Token) *Node {
	node := new_node(ND_NUM, tok)
	node.val = val
	node.ty = ty_ulong
	return node
}

func new_var_node(varr *Obj, tok *Token) *Node {
	node := new_node(ND_VAR, tok)
	node.varr = varr
	return node
}

func new_vla_ptr(varr *Obj, tok *Token) *Node {
	node := new_node(ND_VLA_PTR, tok)
	node.varr = varr
	return node
}

func new_cast(expr *Node, ty *Type) *Node {
	add_type(expr)

	node := Node{}
	node.kind = ND_CAST
	node.tok = expr.tok
	node.lhs = expr
	node.ty = copy_type(ty)
	return &node
}

func push_scope(name string) *VarScope {
	sc := &VarScope{}
	scope.vars[name] = sc
	return sc
}

func new_initializer(ty *Type, is_flexible bool) *Initializer {
	init := Initializer{}
	init.ty = ty

	if ty.kind == TY_ARRAY {
		if is_flexible && ty.size < 0 {
			init.is_flexible = true
			return &init
		}
		init.children = make([]*Initializer, ty.array_len)
		for i := 0; i < ty.array_len; i++ {
			init.children[i] = new_initializer(ty.base, false)
		}
		return &init
	}

	if ty.kind == TY_STRUCT || ty.kind == TY_UNION {
		// Count the number of struct members.
		len := 0
		for mem := ty.members; mem != nil; mem = mem.next {
			len++
		}

		init.children = make([]*Initializer, len)

		for mem := ty.members; mem != nil; mem = mem.next {
			if is_flexible && ty.is_flexible && nil == mem.next {
				child := Initializer{}
				child.ty = mem.ty
				child.is_flexible = true
				init.children[mem.idx] = &child
			} else {
				init.children[mem.idx] = new_initializer(mem.ty, false)
			}
		}
		return &init
	}

	return &init
}

func new_var(name string, ty *Type) *Obj {
	var varr Obj
	varr.name = name
	varr.ty = ty
	varr.align = ty.align
	push_scope(name).varr = &varr
	return &varr
}

func new_lvar(name string, ty *Type) *Obj {
	varr := new_var(name, ty)
	varr.is_local = true
	varr.next = locals
	locals = varr
	return varr
}

func new_gvar(name string, ty *Type) *Obj {
	varr := new_var(name, ty)
	varr.next = globals
	varr.is_static = true
	varr.is_definition = true
	globals = varr
	return varr
}

var id int

func new_unique_name() string {
	//Commit 35. Did not make strings.go & function format()
	// (although learnt about memstream's reading that code)
	ret := fmt.Sprintf(".L..%d", id)
	id++
	return ret
}

func new_anon_gvar(ty *Type) *Obj {
	return new_gvar(new_unique_name(), ty)
}

func new_str_literal(s string, ty *Type) *Obj {
	varr := new_anon_gvar(ty)
	varr.init_data = []byte(s)
	return varr
}

func new_str_literal_ex(tok *Token, ty *Type) *Obj {
	varr := new_anon_gvar(ty)
	if tok.str16 != nil {
		for _, w := range tok.str16 {
			varr.init_data = binary.LittleEndian.AppendUint16(varr.init_data, w)
		}
	} else if tok.str32 != nil {
		for _, dw := range tok.str32 {
			varr.init_data = binary.LittleEndian.AppendUint32(varr.init_data, dw)
		}
	} else {
		varr.init_data = []byte(tok.lexeme)
	}
	return varr
}

func get_ident(tok *Token) string {
	if tok.kind != TK_IDENT {
		error_tok(tok, "expected an identifier")
	}
	return tok.lexeme
}

func find_typedef(tok *Token) *Type {
	if tok.kind == TK_IDENT {
		sc := find_var(tok)
		if sc != nil {
			return sc.type_def
		}
	}
	return nil
}

func push_tag_scope(tok *Token, ty *Type) {
	scope.tags[tok.lexeme] = ty
}

/*
// declspec = ("void" | "_Bool" | "char" | "short" | "int" | "long"
//             | "typedef" | "static" | "extern" | "inline"
//             | "_Thread_local" | "__thread"
//             | "signed" | "unsigned"
//             | struct-decl | union-decl | typedef-name
//             | enum-specifier | typeof-specifier
//             | "const" | "volatile" | "auto" | "register" | "restrict"
//             | "__restrict" | "__restrict__" | "_Noreturn")+
//
// The order of typenames in a type-specifier doesn't matter. For
// example, `int long static` means the same as `static long int`.
// That can also be written as `static long` because you can omit
// `int` if `long` or `short` are specified. However, something like
// `char int` is not a valid type specifier. We have to accept only a
// limited combinations of the typenames.
//
// In this function, we count the number of occurrences of each typename
// while keeping the "current" type object that the typenames up
// until that point represent. When we reach a non-typename token,
// we returns the current type object.
*/
func declspec(rest **Token, tok *Token, attr *VarAttr) *Type {
	// We use a single integer as counters for all typenames.
	// For example, bits 0 and 1 represents how many times we saw the
	// keyword "void" so far. With this, we can use a switch statement
	// as you can see below.
	const (
		VOID     = 1 << 0
		BOOL     = 1 << 2
		CHAR     = 1 << 4
		SHORT    = 1 << 6
		INT      = 1 << 8
		LONG     = 1 << 10
		FLOAT    = 1 << 12
		DOUBLE   = 1 << 14
		OTHER    = 1 << 16
		SIGNED   = 1 << 17
		UNSIGNED = 1 << 18
	)

	ty := ty_int
	counter := 0
	is_atomic := false

	for is_typename(tok) {
		// Handle storage class specifiers.
		if equal(tok, "typedef") || equal(tok, "static") || equal(tok, "extern") || equal(tok, "inline") || equal(tok, "_Thread_local") || equal(tok, "__thread") {
			if nil == attr {
				error_tok(tok, "storage class specifier is not allowed in this context")
			}

			if equal(tok, "typedef") {
				attr.is_typedef = true
			} else if equal(tok, "static") {
				attr.is_static = true
			} else if equal(tok, "extern") {
				attr.is_extern = true
			} else if equal(tok, "inline") {
				attr.is_inline = true
			} else {
				attr.is_tls = true
			}

			if attr.is_typedef && (attr.is_static || attr.is_extern || attr.is_inline || attr.is_tls) {
				error_tok(tok, "typedef may not be used together with static, extern, inline, __thread or _Thread_local")
			}
			tok = tok.next
			continue
		}

		// These keywords are recognized but ignored.
		if consume(&tok, tok, "const") || consume(&tok, tok, "volatile") ||
			consume(&tok, tok, "auto") || consume(&tok, tok, "register") ||
			consume(&tok, tok, "restrict") || consume(&tok, tok, "__restrict") ||
			consume(&tok, tok, "__restrict__") || consume(&tok, tok, "_Noreturn") {
			continue
		}

		if equal(tok, "_Atomic") {
			tok = tok.next
			if equal(tok, "(") {
				ty = typename(&tok, tok.next)
				tok = skip(tok, ")")
			}
			is_atomic = true
			continue
		}

		if equal(tok, "_Alignas") {
			if nil == attr {
				error_tok(tok, "_Alignas is not allowed in this context")
			}
			tok = skip(tok.next, "(")

			if is_typename(tok) {
				attr.align = typename(&tok, tok).align
			} else {
				attr.align = int(const_expr(&tok, tok))
			}
			tok = skip(tok, ")")
			continue
		}

		// Handle user-defined types.
		ty2 := find_typedef(tok)
		if equal(tok, "struct") || equal(tok, "union") || equal(tok, "enum") || equal(tok, "typeof") || ty2 != nil {
			if counter > 0 {
				break
			}

			if equal(tok, "struct") {
				ty = struct_decl(&tok, tok.next)
			} else if equal(tok, "union") {
				ty = union_decl(&tok, tok.next)
			} else if equal(tok, "enum") {
				ty = enum_specifier(&tok, tok.next)
			} else if equal(tok, "typeof") {
				ty = typeof_specifier(&tok, tok.next)
			} else {
				ty = ty2
				tok = tok.next
			}
			counter += OTHER
			continue
		}

		// Handle built-in types.
		if equal(tok, "void") {
			counter += VOID
		} else if equal(tok, "_Bool") {
			counter += BOOL
		} else if equal(tok, "char") {
			counter += CHAR
		} else if equal(tok, "short") {
			counter += SHORT
		} else if equal(tok, "int") {
			counter += INT
		} else if equal(tok, "long") {
			counter += LONG
		} else if equal(tok, "float") {
			counter += FLOAT
		} else if equal(tok, "double") {
			counter += DOUBLE
		} else if equal(tok, "signed") {
			counter |= SIGNED
		} else if equal(tok, "unsigned") {
			counter |= UNSIGNED
		} else {
			unreachable()
		}

		switch counter {
		case VOID:
			ty = ty_void
		case BOOL:
			ty = ty_bool
		case CHAR, SIGNED + CHAR:
			ty = ty_char
		case UNSIGNED + CHAR:
			ty = ty_uchar
		case SHORT, SHORT + INT, SIGNED + SHORT, SIGNED + SHORT + INT:
			ty = ty_short
		case UNSIGNED + SHORT, UNSIGNED + SHORT + INT:
			ty = ty_ushort
		case INT, SIGNED, SIGNED + INT:
			ty = ty_int
		case UNSIGNED, UNSIGNED + INT:
			ty = ty_uint
		case LONG, LONG + INT, LONG + LONG, LONG + LONG + INT, SIGNED + LONG, SIGNED + LONG + INT, SIGNED + LONG + LONG, SIGNED + LONG + LONG + INT:
			ty = ty_long
		case UNSIGNED + LONG, UNSIGNED + LONG + INT, UNSIGNED + LONG + LONG, UNSIGNED + LONG + LONG + INT:
			ty = ty_ulong
		case FLOAT:
			ty = ty_float
		case DOUBLE, LONG + DOUBLE:
			ty = ty_double
		default:
			error_tok(tok, "invalid type")
		}

		tok = tok.next
	}

	if is_atomic {
		ty = copy_type(ty)
		ty.is_atomic = true
	}

	*rest = tok
	return ty
}

// func-params = ("void" | param ("," param)* ("," "...")?)? ")"
// param       = declspec declarator
func func_params(rest **Token, tok *Token, ty *Type) *Type {
	if equal(tok, "void") && equal(tok.next, ")") {
		*rest = tok.next.next
		return func_type(ty)
	}

	head := Type{}
	var cur *Type = &head
	is_variadic := false

	for !equal(tok, ")") {
		if cur != &head {
			tok = skip(tok, ",")
		}

		if equal(tok, "...") {
			is_variadic = true
			tok = tok.next
			skip(tok, ")")
			break
		}

		ty2 := declspec(&tok, tok, nil)
		ty2 = declarator(&tok, tok, ty2)

		name := ty2.name

		if ty2.kind == TY_ARRAY {
			// "array of T" is converted to "pointer to T" only in the parameter
			// context. For example, *argv[] is converted to **argv by this.
			ty2 = pointer_to(ty2.base)
			ty2.name = name
		} else if ty2.kind == TY_FUNC {
			// Likewise, a function is converted to a pointer to a function
			// only in the parameter context.
			ty2 = pointer_to(ty2)
			ty2.name = name
		}

		cur.next = copy_type(ty2)
		cur = cur.next
	}

	if cur == &head {
		is_variadic = true
	}

	ty = func_type(ty)
	ty.params = head.next
	ty.is_variadic = is_variadic
	*rest = tok.next
	return ty
}

// array-dimensions = ("static" | "restrict")* const-expr? "]" type-suffix
func array_dimensions(rest **Token, tok *Token, ty *Type) *Type {
	for equal(tok, "static") || equal(tok, "restrict") {
		tok = tok.next
	}

	if equal(tok, "]") {
		ty = type_suffix(rest, tok.next, ty)
		return array_of(ty, -1)
	}

	expr := conditional(&tok, tok)
	tok = skip(tok, "]")
	ty = type_suffix(rest, tok, ty)

	if ty.kind == TY_VLA || !is_const_expr(expr) {
		return vla_of(ty, expr)
	}

	return array_of(ty, int(eval(expr)))
}

/*
// type-suffix = "(" func-params
//	| "[" array-dimensions
//	| ε
*/
func type_suffix(rest **Token, tok *Token, ty *Type) *Type {
	if equal(tok, "(") {
		return func_params(rest, tok.next, ty)
	}

	if equal(tok, "[") {
		return array_dimensions(rest, tok.next, ty)
	}

	*rest = tok
	return ty
}

// pointers = ("*" ("const" | "volatile" | "restrict")*)*
func pointers(rest **Token, tok *Token, ty *Type) *Type {
	for consume(&tok, tok, "*") {
		ty = pointer_to(ty)
		for equal(tok, "const") || equal(tok, "volatile") || equal(tok, "restrict") || equal(tok, "__restrict") || equal(tok, "__restrict__") {
			tok = tok.next
		}
	}
	*rest = tok
	return ty
}

// declarator = pointers ("(" ident ")" | "(" declarator ")" | ident) type-suffix
func declarator(rest **Token, tok *Token, ty *Type) *Type {
	ty = pointers(&tok, tok, ty)

	if equal(tok, "(") {
		start := tok
		dummy := Type{}
		declarator(&tok, start.next, &dummy)
		tok = skip(tok, ")")
		ty = type_suffix(rest, tok, ty)
		return declarator(&tok, start.next, ty)
	}

	var name *Token = nil
	name_pos := tok

	if tok.kind == TK_IDENT {
		name = tok
		tok = tok.next
	}

	ty = type_suffix(rest, tok, ty)
	ty.name = name
	ty.name_pos = name_pos
	return ty
}

// abstract-declarator = pointers ("(" abstract-declarator ")")? type-suffix
func abstract_declarator(rest **Token, tok *Token, ty *Type) *Type {
	ty = pointers(&tok, tok, ty)

	if equal(tok, "(") {
		start := tok
		dummy := Type{}
		abstract_declarator(&tok, start.next, &dummy)
		tok = skip(tok, ")")
		ty = type_suffix(rest, tok, ty)
		return abstract_declarator(&tok, start.next, ty)
	}

	return type_suffix(rest, tok, ty)
}

// type-name = declspec abstract-declarator
func typename(rest **Token, tok *Token) *Type {
	ty := declspec(&tok, tok, nil)
	return abstract_declarator(rest, tok, ty)
}

func is_end(tok *Token) bool {
	return equal(tok, "}") || (equal(tok, ",") && equal(tok.next, "}"))
}

func consume_end(rest **Token, tok *Token) bool {
	if equal(tok, "}") {
		*rest = tok.next
		return true
	}

	if equal(tok, ",") && equal(tok.next, "}") {
		*rest = tok.next.next
		return true
	}

	return false
}

/*
// enum-specifier = ident? "{" enum-list? "}"
//	| ident ("{" enum-list? "}")?
//
// enum-list      = ident ("=" num)? ("," ident ("=" num)?)* ","?
*/
func enum_specifier(rest **Token, tok *Token) *Type {
	ty := enum_type()

	// Read a struct tag.
	var tag *Token
	if tok.kind == TK_IDENT {
		tag = tok
		tok = tok.next
	}

	if tag != nil && !equal(tok, "{") {
		ty := find_tag(tag)
		if nil == ty {
			error_tok(tag, "unknown enum type")
		}
		if ty.kind != TY_ENUM {
			error_tok(tag, "not an enum tag")
		}
		*rest = tok
		return ty
	}

	tok = skip(tok, "{")

	// Read an enum-list.
	i := 0
	val := 0
	for !consume_end(rest, tok) {
		if i > 0 {
			tok = skip(tok, ",")
		}
		i++

		name := get_ident(tok)
		tok = tok.next

		if equal(tok, "=") {
			val = int(const_expr(&tok, tok.next))
		}

		sc := push_scope(name)
		sc.enum_ty = ty
		sc.enum_val = val
		val++
	}

	if tag != nil {
		push_tag_scope(tag, ty)
	}
	return ty
}

// typeof-specifier = "(" (expr | typename) ")"
func typeof_specifier(rest **Token, tok *Token) *Type {
	tok = skip(tok, "(")

	var ty *Type
	if is_typename(tok) {
		ty = typename(&tok, tok)
	} else {
		node := expr(&tok, tok)
		add_type(node)
		ty = node.ty
	}
	*rest = skip(tok, ")")
	return ty
}

// Generate code for computing a VLA size.
func compute_vla_size(ty *Type, tok *Token) *Node {
	node := new_node(ND_NULL_EXPR, tok)
	if ty.base != nil {
		node = new_binary(ND_COMMA, node, compute_vla_size(ty.base, tok), tok)
	}

	if ty.kind != TY_VLA {
		return node
	}

	var base_sz *Node
	if ty.base.kind == TY_VLA {
		base_sz = new_var_node(ty.base.vla_size, tok)
	} else {
		base_sz = new_num(int64(ty.base.size), tok)
	}

	ty.vla_size = new_lvar("", ty_ulong)
	expr := new_binary(ND_ASSIGN, new_var_node(ty.vla_size, tok),
		new_binary(ND_MUL, ty.vla_len, base_sz, tok),
		tok)
	return new_binary(ND_COMMA, node, expr, tok)
}

func new_alloca(sz *Node) *Node {
	node := new_unary(ND_FUNCALL, new_var_node(builtin_alloca, sz.tok), sz.tok)
	node.func_ty = builtin_alloca.ty
	node.ty = builtin_alloca.ty.return_ty
	node.args = sz
	add_type(sz)
	return node
}

// declaration = declspec (declarator ("=" expr)? ("," declarator ("=" expr)?)*)? ";"
func declaration(rest **Token, tok *Token, basety *Type, attr *VarAttr) *Node {
	head := Node{}
	var cur *Node = &head
	i := 0

	for !equal(tok, ";") {
		if i > 0 {
			tok = skip(tok, ",")
		}
		i++

		ty := declarator(&tok, tok, basety)

		if ty.kind == TY_VOID {
			error_tok(tok, "variable declared void")
		}

		if nil == ty.name {
			error_tok(ty.name_pos, "variable name omitted")
		}

		if attr != nil && attr.is_static {
			// static local variable
			varr := new_anon_gvar(ty)
			push_scope(get_ident(ty.name)).varr = varr
			if equal(tok, "=") {
				gvar_initializer(&tok, tok.next, varr)
			}
			continue
		}

		// Generate code for computing a VLA size. We need to do this
		// even if ty is not VLA because ty may be a pointer to VLA
		// (e.g. int (*foo)[n][m] where n and m are variables.)
		cur.next = new_unary(ND_EXPR_STMT, compute_vla_size(ty, tok), tok)
		cur = cur.next

		if ty.kind == TY_VLA {
			if equal(tok, "=") {
				error_tok(tok, "variable-sized object may not be initialized")
			}

			// Variable length arrays (VLAs) are translated to alloca() calls.
			// For example, `int x[n+2]` is translated to `tmp = n + 2,
			// x = alloca(tmp)`.
			varr := new_lvar(get_ident(ty.name), ty)
			tok := ty.name
			expr := new_binary(ND_ASSIGN, new_vla_ptr(varr, tok),
				new_alloca(new_var_node(ty.vla_size, tok)),
				tok)

			cur.next = new_unary(ND_EXPR_STMT, expr, tok)
			cur = cur.next
			continue
		}

		varr := new_lvar(get_ident(ty.name), ty)
		if attr != nil && attr.align != 0 {
			varr.align = attr.align
		}

		if equal(tok, "=") {
			expr := lvar_initializer(&tok, tok.next, varr)
			cur.next = new_unary(ND_EXPR_STMT, expr, tok)
			cur = cur.next
		}

		if varr.ty.size < 0 {
			error_tok(ty.name, "variable has incomplete type")
		}
		if varr.ty.kind == TY_VOID {
			error_tok(ty.name, "variable declared void")
		}
	}

	node := new_node(ND_BLOCK, tok)
	node.body = head.next
	*rest = tok.next
	return node
}

func skip_excess_element(tok *Token) *Token {
	if equal(tok, "{") {
		tok = skip_excess_element(tok.next)
		return skip(tok, "}")
	}

	assign(&tok, tok)
	return tok
}

// string-initializer = string-literal
func string_initializer(rest **Token, tok *Token, init *Initializer) {
	if init.is_flexible {
		*init = *new_initializer(array_of(init.ty.base, tok.ty.array_len), false)
	}

	len := min(init.ty.array_len, tok.ty.array_len)

	switch init.ty.base.size {
	case 1:
		str := []byte(tok.lexeme)
		for i := 0; i < len; i++ {
			init.children[i].expr = new_num(int64(str[i]), tok)
		}
	case 2:
		str := tok.str16
		for i := 0; i < len; i++ {
			init.children[i].expr = new_num(int64(str[i]), tok)
		}
	case 4:
		str := tok.str32
		for i := 0; i < len; i++ {
			init.children[i].expr = new_num(int64(str[i]), tok)
		}
	default:
		unreachable()
	}

	*rest = tok.next
}

// array-designator = "[" const-expr "]"
//
// C99 added the designated initializer to the language, which allows
// programmers to move the "cursor" of an initializer to any element.
// The syntax looks like this:
//
//	int x[10] = { 1, 2, [5]=3, 4, 5, 6, 7 };
//
// `[5]` moves the cursor to the 5th element, so the 5th element of x
// is set to 3. Initialization then continues forward in order, so
// 6th, 7th, 8th and 9th elements are initialized with 4, 5, 6 and 7,
// respectively. Unspecified elements (in this case, 3rd and 4th
// elements) are initialized with zero.
//
// Nesting is allowed, so the following initializer is valid:
//
//	int x[5][10] = { [5][8]=1, 2, 3 };
//
// It sets x[5][8], x[5][9] and x[6][0] to 1, 2 and 3, respectively.
//
// Use `.fieldname` to move the cursor for a struct initializer. E.g.
//
//	struct { int a, b, c; } x = { .c=5 };
//
// The above initializer sets x.c to 5.
func array_designator(rest **Token, tok *Token, ty *Type, begin *int, end *int) {
	*begin = int(const_expr(&tok, tok.next))
	if *begin >= ty.array_len {
		error_tok(tok, "array designator index exceeds array bounds")
	}

	if equal(tok, "...") {
		*end = int(const_expr(&tok, tok.next))
		if *end >= ty.array_len {
			error_tok(tok, "array designator index exceeds array bounds")
		}
		if *end < *begin {
			error_tok(tok, "array designator range [%d, %d] is empty", *begin, *end)
		}
	} else {
		*end = *begin
	}

	*rest = skip(tok, "]")
}

// struct-designator = "." ident
func struct_designator(rest **Token, tok *Token, ty *Type) *Member {
	start := tok
	tok = skip(tok, ".")
	if tok.kind != TK_IDENT {
		error_tok(tok, "expected a field designator")
	}

	for mem := ty.members; mem != nil; mem = mem.next {
		// Anonymous struct member
		if mem.ty.kind == TY_STRUCT && "" == mem.name {
			if get_struct_member(mem.ty, tok) != nil {
				*rest = start
				return mem
			}
			continue
		}

		// Regular struct member
		if mem.name == tok.lexeme {
			*rest = tok.next
			return mem
		}
	}

	error_tok(tok, "struct has no such member")
	return nil //Won't be reached
}

// designation = ("[" const-expr "]" | "." ident)* "="? initializer
func designation(rest **Token, tok *Token, init *Initializer) {
	if equal(tok, "[") {
		if init.ty.kind != TY_ARRAY {
			error_tok(tok, "array index in non-array initializer")
		}
		var begin, end int
		array_designator(&tok, tok, init.ty, &begin, &end)

		var tok2 *Token
		for i := begin; i <= end; i++ {
			designation(&tok2, tok, init.children[i])
		}
		array_initializer2(rest, tok2, init, begin+1)
		return
	}

	if equal(tok, ".") && init.ty.kind == TY_STRUCT {
		mem := struct_designator(&tok, tok, init.ty)
		designation(&tok, tok, init.children[mem.idx])
		init.expr = nil
		struct_initializer2(rest, tok, init, mem.next)
		return
	}

	if equal(tok, ".") && init.ty.kind == TY_UNION {
		mem := struct_designator(&tok, tok, init.ty)
		init.mem = mem
		designation(rest, tok, init.children[mem.idx])
		return
	}

	if equal(tok, ".") {
		error_tok(tok, "field name not in struct or union initializer")
	}

	if equal(tok, "=") {
		tok = tok.next
	}
	initializer2(rest, tok, init)
}

// An array length can be omitted if an array has an initializer
// (e.g. `int x[] = {1,2,3}`). If it's omitted, count the number
// of initializer elements.
func count_array_init_elements(tok *Token, ty *Type) int {
	first := true
	dummy := new_initializer(ty.base, true)

	i, maxx := int64(0), int64(0)

	for !consume_end(&tok, tok) {
		if !first {
			tok = skip(tok, ",")
		}
		first = false

		if equal(tok, "[") {
			i = const_expr(&tok, tok.next)
			if equal(tok, "...") {
				i = const_expr(&tok, tok.next)
			}
			tok = skip(tok, "]")
			designation(&tok, tok, dummy)
		} else {
			initializer2(&tok, tok, dummy)
		}

		i++
		maxx = max(maxx, i)
	}
	return int(maxx)
}

// array-initializer1 = "{" initializer ("," initializer)* ","? "}"
func array_initializer1(rest **Token, tok *Token, init *Initializer) {
	tok = skip(tok, "{")

	if init.is_flexible {
		len := count_array_init_elements(tok, init.ty)
		*init = *new_initializer(array_of(init.ty.base, len), false)
	}

	first := true

	if init.is_flexible {
		len := count_array_init_elements(tok, init.ty)
		*init = *new_initializer(array_of(init.ty.base, len), false)
	}

	for i := 0; !consume_end(rest, tok); i++ {
		if !first {
			tok = skip(tok, ",")
		}
		first = false

		if equal(tok, "[") {
			var begin, end int
			array_designator(&tok, tok, init.ty, &begin, &end)

			var tok2 *Token
			for j := begin; j <= end; j++ {
				designation(&tok2, tok, init.children[j])
			}
			tok = tok2
			i = end
			continue
		}

		if i < init.ty.array_len {
			initializer2(&tok, tok, init.children[i])
		} else {
			tok = skip_excess_element(tok)
		}
	}
}

// array-initializer2 = initializer ("," initializer)*
func array_initializer2(rest **Token, tok *Token, init *Initializer, i int) {
	if init.is_flexible {
		len := count_array_init_elements(tok, init.ty)
		*init = *new_initializer(array_of(init.ty.base, len), false)
	}

	for i < init.ty.array_len && !is_end(tok) {
		start := tok
		if i > 0 {
			tok = skip(tok, ",")
		}

		if equal(tok, "[") || equal(tok, ".") {
			*rest = start
			return
		}

		initializer2(&tok, tok, init.children[i])
		i++
	}
	*rest = tok
}

// struct-initializer1 = "{" initializer ("," initializer)* ","? "}"
func struct_initializer1(rest **Token, tok *Token, init *Initializer) {
	tok = skip(tok, "{")

	mem := init.ty.members
	first := true

	for !consume_end(rest, tok) {
		if !first {
			tok = skip(tok, ",")
		}
		first = false

		if equal(tok, ".") {
			mem = struct_designator(&tok, tok, init.ty)
			designation(&tok, tok, init.children[mem.idx])
			mem = mem.next
			continue
		}

		if mem != nil {
			initializer2(&tok, tok, init.children[mem.idx])
			mem = mem.next
		} else {
			tok = skip_excess_element(tok)
		}
	}
}

// struct-initializer2 = initializer ("," initializer)*
func struct_initializer2(rest **Token, tok *Token, init *Initializer, mem *Member) {
	first := true

	for mem != nil && !is_end(tok) {
		start := tok

		if !first {
			tok = skip(tok, ",")
		}
		first = false

		if equal(tok, "[") || equal(tok, ".") {
			*rest = start
			return
		}

		initializer2(&tok, tok, init.children[mem.idx])
		mem = mem.next
	}
	*rest = tok
}

func union_initializer(rest **Token, tok *Token, init *Initializer) {
	// Unlike structs, union initializers take only one initializer,
	// and that initializes the first union member by default.
	// You can initialize other member using a designated initializer.
	if equal(tok, "{") && equal(tok.next, ".") {
		mem := struct_designator(&tok, tok.next, init.ty)
		init.mem = mem
		designation(&tok, tok, init.children[mem.idx])
		*rest = skip(tok, "}")
		return
	}

	init.mem = init.ty.members

	if equal(tok, "{") {
		initializer2(&tok, tok.next, init.children[0])
		consume(&tok, tok, ",")
		*rest = skip(tok, "}")
	} else {
		initializer2(rest, tok, init.children[0])
	}
}

/*
// initializer = string-initializer | array-initializer
//             | struct-initializer | union-initializer
//             | assign
*/
func initializer2(rest **Token, tok *Token, init *Initializer) {
	if init.ty.kind == TY_ARRAY && tok.kind == TK_STR {
		string_initializer(rest, tok, init)
		return
	}

	if init.ty.kind == TY_ARRAY {
		if equal(tok, "{") {
			array_initializer1(rest, tok, init)
		} else {
			array_initializer2(rest, tok, init, 0)
		}
		return
	}

	if init.ty.kind == TY_STRUCT {
		if equal(tok, "{") {
			struct_initializer1(rest, tok, init)
			return
		}

		// A struct can be initialized with another struct. E.g.
		// `struct T x = y;` where y is a variable of type `struct T`.
		// Handle that case first.
		expr := assign(rest, tok)
		add_type(expr)
		if expr.ty.kind == TY_STRUCT {
			init.expr = expr
			return
		}

		struct_initializer2(rest, tok, init, init.ty.members)
		return
	}

	if init.ty.kind == TY_UNION {
		union_initializer(rest, tok, init)
		return
	}

	if equal(tok, "{") {
		// An initializer for a scalar variable can be surrounded by
		// braces. E.g. `int x = {3};`. Handle that case.
		initializer2(&tok, tok.next, init)
		*rest = skip(tok, "}")
		return
	}

	init.expr = assign(rest, tok)
}

func copy_struct_type(ty *Type) *Type {
	ty = copy_type(ty)

	head := Member{}
	cur := &head
	for mem := ty.members; mem != nil; mem = mem.next {
		m := Member{}
		m = *mem
		cur.next = &m
		cur = cur.next
	}

	ty.members = head.next
	return ty
}

func initializer(rest **Token, tok *Token, ty *Type, new_ty **Type) *Initializer {
	init := new_initializer(ty, true)
	initializer2(rest, tok, init)

	if (ty.kind == TY_STRUCT || ty.kind == TY_UNION) && ty.is_flexible {
		ty = copy_struct_type(ty)

		mem := ty.members
		for mem.next != nil {
			mem = mem.next
		}
		mem.ty = init.children[mem.idx].ty
		ty.size += mem.ty.size

		*new_ty = ty
		return init
	}

	*new_ty = init.ty
	return init

}

func init_desg_expr(desg *InitDesg, tok *Token) *Node {
	if desg.varr != nil {
		return new_var_node(desg.varr, tok)
	}

	if desg.member != nil {
		node := new_unary(ND_MEMBER, init_desg_expr(desg.next, tok), tok)
		node.member = desg.member
		return node
	}

	lhs := init_desg_expr(desg.next, tok)
	rhs := new_num(int64(desg.idx), tok)
	return new_unary(ND_DEREF, new_add(lhs, rhs, tok), tok)
}

func create_lvar_init(init *Initializer, ty *Type, desg *InitDesg, tok *Token) *Node {
	if ty.kind == TY_ARRAY {
		node := new_node(ND_NULL_EXPR, tok)
		for i := 0; i < ty.array_len; i++ {
			desg2 := InitDesg{next: desg, idx: i}
			rhs := create_lvar_init(init.children[i], ty.base, &desg2, tok)
			node = new_binary(ND_COMMA, node, rhs, tok)
		}
		return node
	}

	if ty.kind == TY_STRUCT && nil == init.expr {
		node := new_node(ND_NULL_EXPR, tok)

		for mem := ty.members; mem != nil; mem = mem.next {
			desg2 := InitDesg{next: desg, idx: 0, member: mem}
			rhs := create_lvar_init(init.children[mem.idx], mem.ty, &desg2, tok)
			node = new_binary(ND_COMMA, node, rhs, tok)
		}
		return node
	}

	if ty.kind == TY_UNION {
		var mem *Member
		if init.mem != nil {
			mem = init.mem
		} else {
			mem = ty.members
		}

		desg2 := InitDesg{next: desg, idx: 0, member: mem}
		return create_lvar_init(init.children[mem.idx], mem.ty, &desg2, tok)
	}

	if nil == init.expr {
		return new_node(ND_NULL_EXPR, tok)
	}

	lhs := init_desg_expr(desg, tok)
	return new_binary(ND_ASSIGN, lhs, init.expr, tok)
}

// A variable definition with an initializer is a shorthand notation
// for a variable definition followed by assignments. This function
// generates assignment expressions for an initializer. For example,
// `int x[2][2] = {{6, 7}, {8, 9}}` is converted to the following
// expressions:
//
//	x[0][0] = 6;
//	x[0][1] = 7;
//	x[1][0] = 8;
//	x[1][1] = 9;
func lvar_initializer(rest **Token, tok *Token, varr *Obj) *Node {
	init := initializer(rest, tok, varr.ty, &varr.ty)
	desg := InitDesg{next: nil, idx: 0, member: nil, varr: varr}

	// If a partial initializer list is given, the standard requires
	// that unspecified elements are set to 0. Here, we simply
	// zero-initialize the entire memory region of a variable before
	// initializing it with user-supplied values.
	lhs := new_node(ND_MEMZERO, tok)
	lhs.varr = varr

	rhs := create_lvar_init(init, varr.ty, &desg, tok)
	return new_binary(ND_COMMA, lhs, rhs, tok)
}

func read_buf(buf *[]byte, offset int, sz int) uint64 {
	if sz == 1 {
		by := (*buf)[offset]
		return uint64(by)
	}
	if sz == 2 {
		return uint64(binary.LittleEndian.Uint16((*buf)[offset:]))
	}
	if sz == 4 {
		return uint64(binary.LittleEndian.Uint32((*buf)[offset:]))
	}
	if sz == 8 {
		return uint64(binary.LittleEndian.Uint64((*buf)[offset:]))
	}
	unreachable()
	return 0 //Won't be reached
}

func write_buf(buf *[]byte, offset int, val uint64, sz int) {
	replace := []byte{}
	if sz == 1 {
		by := byte(val)
		replace = append(replace, by)
	} else if sz == 2 {
		u16 := uint16(val)
		replace = binary.LittleEndian.AppendUint16(replace, u16)
	} else if sz == 4 {
		u32 := uint32(val)
		replace = binary.LittleEndian.AppendUint32(replace, u32)
	} else if sz == 8 {
		replace = binary.LittleEndian.AppendUint64(replace, val)
	} else {
		unreachable()
	}

	for i, by := range replace {
		(*buf)[offset+i] = by
	}
}

func f32_to_buf(buf []byte, f32 float32) {
	binary.LittleEndian.PutUint32(buf, math.Float32bits(f32))
}

func f64_to_buf(buf []byte, f64 float64) {
	binary.LittleEndian.PutUint64(buf, math.Float64bits(f64))
}

func write_gvar_data(cur *Relocation, init *Initializer, ty *Type, buf *[]byte, offset int) *Relocation {
	if ty.kind == TY_ARRAY {
		sz := ty.base.size
		for i := 0; i < ty.array_len; i++ {
			cur = write_gvar_data(cur, init.children[i], ty.base, buf, offset+sz*i)
		}
		return cur
	}

	if ty.kind == TY_STRUCT {
		for mem := ty.members; mem != nil; mem = mem.next {
			if mem.is_bitfield {
				expr := init.children[mem.idx].expr
				if nil == expr {
					break
				}

				loc := offset + mem.offset
				oldval := read_buf(buf, loc, mem.ty.size)
				newval := uint64(eval(expr))
				mask := uint64((1 << mem.bit_width) - 1)
				combined := oldval | ((newval & mask) << mem.bit_offset)
				write_buf(buf, loc, combined, mem.ty.size)
			} else {
				cur = write_gvar_data(cur, init.children[mem.idx], mem.ty, buf, offset+mem.offset)
			}
		}
		return cur
	}

	if ty.kind == TY_UNION {
		if nil == init.mem {
			return cur
		}
		return write_gvar_data(cur, init.children[init.mem.idx], init.mem.ty, buf, offset)
	}

	if nil == init.expr {
		return cur
	}

	if ty.kind == TY_FLOAT {
		f32_to_buf((*buf)[offset:], float32(eval_double(init.expr)))
		return cur
	}

	if ty.kind == TY_DOUBLE {
		f64_to_buf((*buf)[offset:], eval_double(init.expr))
		return cur
	}

	var label *string
	val := eval2(init.expr, &label)

	if label == nil {
		write_buf(buf, offset, uint64(val), ty.size)
		return cur
	}

	rel := Relocation{}
	rel.offset = offset
	rel.label = label
	rel.addend = val
	cur.next = &rel
	return cur.next
}

// Initializers for global variables are evaluated at compile-time and
// embedded to .data section. This function serializes Initializer
// objects to a flat byte array. It is a compile error if an
// initializer list contains a non-constant expression.
func gvar_initializer(rest **Token, tok *Token, varr *Obj) {
	init := initializer(rest, tok, varr.ty, &varr.ty)

	head := Relocation{}
	buf := make([]byte, varr.ty.size)
	write_gvar_data(&head, init, varr.ty, &buf, 0)

	varr.init_data = buf
	varr.rel = head.next
}

var tnmap map[string]bool = make(map[string]bool)
var tn = []string{"void", "_Bool", "char", "short", "int", "long", "struct", "union",
	"typedef", "enum", "static", "extern", "_Alignas", "signed", "unsigned",
	"const", "volatile", "auto", "register", "restrict", "__restrict",
	"__restrict__", "_Noreturn", "float", "double", "typeof", "inline",
	"_Thread_local", "__thread", "_Atomic",
}

// Returns true if a given token represents a type.
func is_typename(tok *Token) bool {
	if len(tnmap) == 0 {
		for _, s := range tn {
			tnmap[s] = true
		}
	}

	return true == tnmap[tok.lexeme] || nil != find_typedef(tok)
}

// asm-stmt = "asm" ("volatile" | "inline")* "(" string-literal ")"
func asm_stmt(rest **Token, tok *Token) *Node {
	node := new_node(ND_ASM, tok)
	tok = tok.next

	for equal(tok, "volatile") || equal(tok, "inline") {
		tok = tok.next
	}

	tok = skip(tok, "(")
	if tok.kind != TK_STR || tok.ty.base.kind != TY_CHAR {
		error_tok(tok, "expected string literal")
	}
	node.asm_str = tok.lexeme
	*rest = skip(tok.next, ")")
	return node
}

/*
// stmt = "return" expr? ";"
//      | "if" "(" expr ")" stmt ("else" stmt)?
//      | "switch" "(" expr ")" stmt
//      | "case" const-expr ("..." const-expr)? ":" stmt
//      | "default" ":" stmt
//      | "for" "(" expr-stmt expr? ";" expr? ")" stmt
//      | "while" "(" expr ")" stmt
//      | "do" stmt "while" "(" expr ")" ";"
//      | "asm" asm-stmt
//      | "goto" (ident | "*" expr) ";"
//      | "break" ";"
//      | "continue" ";"
//      | ident ":" stmt
//      | "{" compound-stmt
//      | expr-stmt
*/
func stmt(rest **Token, tok *Token) *Node {
	if equal(tok, "return") {
		node := new_node(ND_RETURN, tok)
		if consume(rest, tok.next, ";") {
			return node
		}

		exp := expr(&tok, tok.next)
		*rest = skip(tok, ";")

		add_type(exp)
		ty := parse_current_fn.ty.return_ty
		if ty.kind != TY_STRUCT && ty.kind != TY_UNION {
			exp = new_cast(exp, parse_current_fn.ty.return_ty)
		}
		node.lhs = exp
		return node
	}

	if equal(tok, "if") {
		node := new_node(ND_IF, tok)
		tok = skip(tok.next, "(")
		node.cond = expr(&tok, tok)
		tok = skip(tok, ")")
		node.then = stmt(&tok, tok)
		if equal(tok, "else") {
			node.els = stmt(&tok, tok.next)
		}
		*rest = tok
		return node
	}

	if equal(tok, "switch") {
		node := new_node(ND_SWITCH, tok)
		tok = skip(tok.next, "(")
		node.cond = expr(&tok, tok)
		tok = skip(tok, ")")

		sw := current_switch
		current_switch = node

		brk := brk_label
		node.brk_label = new_unique_name()
		brk_label = node.brk_label

		node.then = stmt(rest, tok)

		current_switch = sw
		brk_label = brk
		return node
	}

	if equal(tok, "case") {
		if nil == current_switch {
			error_tok(tok, "stray case")
		}
		node := new_node(ND_CASE, tok)

		begin := const_expr(&tok, tok.next)
		var end int64

		if equal(tok, "...") {
			// [GNU] Case ranges, e.g. "case 1 ... 5:"
			end = const_expr(&tok, tok.next)
			if end < begin {
				error_tok(tok, "empty case range specified")
			}
		} else {
			end = begin
		}

		tok = skip(tok, ":")
		node.label = new_unique_name()
		node.lhs = stmt(rest, tok)
		node.begin = begin
		node.end = end
		node.case_next = current_switch.case_next
		current_switch.case_next = node
		return node
	}

	if equal(tok, "default") {
		if nil == current_switch {
			error_tok(tok, "stray default")
		}

		node := new_node(ND_CASE, tok)
		tok = skip(tok.next, ":")
		node.label = new_unique_name()
		node.lhs = stmt(rest, tok)
		current_switch.default_case = node
		return node
	}

	if equal(tok, "for") {
		node := new_node(ND_FOR, tok)
		tok = skip(tok.next, "(")

		enter_scope()

		brk, cont := brk_label, cont_label
		node.brk_label, node.cont_label = new_unique_name(), new_unique_name()
		brk_label, cont_label = node.brk_label, node.cont_label

		if is_typename(tok) {
			basety := declspec(&tok, tok, nil)
			node.init = declaration(&tok, tok, basety, nil)
		} else {
			node.init = expr_stmt(&tok, tok)
		}

		if !equal(tok, ";") {
			node.cond = expr(&tok, tok)
		}
		tok = skip(tok, ";")

		if !equal(tok, ")") {
			node.inc = expr(&tok, tok)
		}
		tok = skip(tok, ")")

		node.then = stmt(rest, tok)

		leave_scope()
		brk_label, cont_label = brk, cont
		return node
	}

	if equal(tok, "while") {
		node := new_node(ND_FOR, tok)
		tok = skip(tok.next, "(")
		node.cond = expr(&tok, tok)
		tok = skip(tok, ")")

		brk, cont := brk_label, cont_label
		node.brk_label, node.cont_label = new_unique_name(), new_unique_name()
		brk_label, cont_label = node.brk_label, node.cont_label

		node.then = stmt(rest, tok)

		brk_label, cont_label = brk, cont
		return node
	}

	if equal(tok, "do") {
		node := new_node(ND_DO, tok)

		brk, cont := brk_label, cont_label
		node.brk_label, node.cont_label = new_unique_name(), new_unique_name()
		brk_label, cont_label = node.brk_label, node.cont_label

		node.then = stmt(&tok, tok.next)

		brk_label, cont_label = brk, cont

		tok = skip(tok, "while")
		tok = skip(tok, "(")
		node.cond = expr(&tok, tok)
		tok = skip(tok, ")")
		*rest = skip(tok, ";")
		return node
	}

	if equal(tok, "asm") {
		return asm_stmt(rest, tok)
	}

	if equal(tok, "goto") {
		if equal(tok.next, "*") {
			// [GNU] `goto *ptr` jumps to the address specified by `ptr`.
			node := new_node(ND_GOTO_EXPR, tok)
			node.lhs = expr(&tok, tok.next.next)
			*rest = skip(tok, ";")
			return node
		}

		node := new_node(ND_GOTO, tok)
		node.label = get_ident(tok.next)
		node.goto_next = gotos
		gotos = node
		*rest = skip(tok.next.next, ";")
		return node
	}

	if equal(tok, "break") {
		if brk_label == "" {
			error_tok(tok, "stray break")
		}
		node := new_node(ND_GOTO, tok)
		node.unique_label = brk_label
		*rest = skip(tok.next, ";")
		return node
	}

	if equal(tok, "continue") {
		if cont_label == "" {
			error_tok(tok, "stray continue")
		}
		node := new_node(ND_GOTO, tok)
		node.unique_label = cont_label
		*rest = skip(tok.next, ";")
		return node
	}

	if tok.kind == TK_IDENT && equal(tok.next, ":") {
		node := new_node(ND_LABEL, tok)
		node.label = tok.lexeme
		node.unique_label = new_unique_name()
		node.lhs = stmt(rest, tok.next.next)
		node.goto_next = labels
		labels = node
		return node
	}

	if equal(tok, "{") {
		return compound_stmt(rest, tok.next)
	}

	return expr_stmt(rest, tok)
}

// compound-stmt = (typedef | declaration | stmt)* "}"
func compound_stmt(rest **Token, tok *Token) *Node {
	node := new_node(ND_BLOCK, tok)

	var head Node
	var cur *Node = &head

	enter_scope()

	for !equal(tok, "}") {
		if is_typename(tok) && !equal(tok.next, ":") {
			attr := VarAttr{}
			basety := declspec(&tok, tok, &attr)

			if attr.is_typedef {
				tok = parse_typedef(tok, basety)
				continue
			}

			if is_function(tok) {
				tok = function(tok, basety, &attr)
				continue
			}

			if attr.is_extern {
				tok = global_variable(tok, basety, &attr)
				continue
			}

			cur.next = declaration(&tok, tok, basety, &attr)
			cur = cur.next
		} else {
			cur.next = stmt(&tok, tok)
			cur = cur.next
		}
		add_type(cur)
	}

	leave_scope()

	node.body = head.next
	*rest = tok.next
	return node
}

// expr-stmt = expr? ";"
func expr_stmt(rest **Token, tok *Token) *Node {
	if equal(tok, ";") {
		*rest = tok.next
		return new_node(ND_BLOCK, tok)
	}

	node := new_node(ND_EXPR_STMT, tok)
	node.lhs = expr(&tok, tok)
	*rest = skip(tok, ";")
	return node
}

// expr = assign ("," expr)?
func expr(rest **Token, tok *Token) *Node {
	node := assign(&tok, tok)

	if equal(tok, ",") {
		return new_binary(ND_COMMA, node, expr(rest, tok.next), tok)
	}

	*rest = tok
	return node
}

func eval(node *Node) int64 {
	return eval2(node, nil)
}

// Evaluate a given node as a constant expression.
//
// A constant expression is either just a number or ptr+n where ptr
// is a pointer to a global variable and n is a postiive/negative
// number. The latter form is accepted only as an initialization
// expression for a global variable.
func eval2(node *Node, label **string) int64 {
	add_type(node)

	if is_flonum(node.ty) {
		return int64(eval_double(node))
	}

	switch node.kind {
	case ND_ADD:
		return eval2(node.lhs, label) + eval(node.rhs)
	case ND_SUB:
		return eval2(node.lhs, label) - eval(node.rhs)
	case ND_MUL:
		return eval(node.lhs) * eval(node.rhs)
	case ND_DIV:
		if node.ty.is_unsigned {
			return int64(uint64(eval(node.lhs)) / uint64(eval(node.rhs)))
		}
		l := eval(node.lhs)
		r := eval(node.rhs)
		return l / r
	case ND_NEG:
		return -eval(node.lhs)
	case ND_MOD:
		if node.ty.is_unsigned {
			return int64(uint64(eval(node.lhs)) % uint64(eval(node.rhs)))
		}
		return eval(node.lhs) % eval(node.rhs)
	case ND_BITAND:
		return eval(node.lhs) & eval(node.rhs)
	case ND_BITOR:
		return eval(node.lhs) | eval(node.rhs)
	case ND_BITXOR:
		return eval(node.lhs) ^ eval(node.rhs)
	case ND_SHL:
		return eval(node.lhs) << eval(node.rhs)
	case ND_SHR:
		if node.ty.is_unsigned && node.ty.size == 8 {
			return int64(uint64(eval(node.lhs)) >> eval(node.rhs))
		}
		return eval(node.lhs) >> eval(node.rhs)
	case ND_EQ:
		if eval(node.lhs) == eval(node.rhs) {
			return 1
		} else {
			return 0
		}
	case ND_NE:
		if eval(node.lhs) != eval(node.rhs) {
			return 1
		} else {
			return 0
		}
	case ND_LT:
		b := false
		if node.lhs.ty.is_unsigned {
			b = uint64(eval(node.lhs)) < uint64(eval(node.rhs))
		} else {
			b = eval(node.lhs) < eval(node.rhs)
		}

		if b {
			return 1
		} else {
			return 0
		}
	case ND_LE:
		b := false
		if node.lhs.ty.is_unsigned {
			b = uint64(eval(node.lhs)) <= uint64(eval(node.rhs))
		} else {
			b = eval(node.lhs) <= eval(node.rhs)
		}

		if b {
			return 1
		} else {
			return 0
		}
	case ND_COND:
		if 0 != eval(node.cond) {
			return eval2(node.then, label)
		} else {
			return eval2(node.els, label)
		}
	case ND_COMMA:
		return eval2(node.rhs, label)
	case ND_NOT:
		if 0 == eval(node.lhs) {
			return 1
		} else {
			return 0
		}
	case ND_BITNOT:
		return ^eval(node.lhs)
	case ND_LOGAND:
		if 0 != eval(node.lhs) && 0 != eval(node.rhs) {
			return 1
		} else {
			return 0
		}
	case ND_LOGOR:
		if 0 != eval(node.lhs) || 0 != eval(node.rhs) {
			return 1
		} else {
			return 0
		}
	case ND_CAST:
		val := eval2(node.lhs, label)
		if is_integer(node.ty) {
			switch node.ty.size {
			case 1:
				if node.ty.is_unsigned {
					val = int64(uint8(val))
				} else {
					val = int64(int8(val))
				}
			case 2:
				if node.ty.is_unsigned {
					val = int64(uint16(val))
				} else {
					val = int64(int16(val))
				}
			case 4:
				if node.ty.is_unsigned {
					val = int64(uint32(val))
				} else {
					val = int64(int32(val))
				}
			}
		}
		return val
	case ND_ADDR:
		return eval_rval(node.lhs, label)
	case ND_LABEL_VAL:
		*label = &node.unique_label
		return 0
	case ND_MEMBER:
		if nil == label {
			error_tok(node.tok, "not a compile-time constant")
		}
		if node.ty.kind != TY_ARRAY {
			error_tok(node.tok, "invalid initializer")
		}
		return eval_rval(node.lhs, label) + int64(node.member.offset)
	case ND_VAR:
		if nil == label {
			error_tok(node.tok, "not a compile-time constant")
		}
		if node.varr.ty.kind != TY_ARRAY && node.varr.ty.kind != TY_FUNC {
			error_tok(node.tok, "invalid initializer")
		}
		*label = &node.varr.name
		return 0

	case ND_NUM:
		return node.val
	}

	error_tok(node.tok, "not a compile-time constant")
	return 0 //Won't be reached
}

func eval_rval(node *Node, label **string) int64 {
	switch node.kind {
	case ND_VAR:
		if node.varr.is_local {
			error_tok(node.tok, "not a compile-time constant")
		}
		*label = &node.varr.name
		return 0
	case ND_DEREF:
		return eval2(node.lhs, label)
	case ND_MEMBER:
		return eval_rval(node.lhs, label) + int64(node.member.offset)
	}

	error_tok(node.tok, "invalid initializer")
	return 0 //Won't be reached
}

func is_const_expr(node *Node) bool {
	add_type(node)

	switch node.kind {
	case ND_ADD, ND_SUB, ND_MUL, ND_DIV, ND_BITAND, ND_BITOR, ND_BITXOR, ND_SHL, ND_SHR, ND_EQ, ND_NE, ND_LT, ND_LE, ND_LOGAND, ND_LOGOR:
		return is_const_expr(node.lhs) && is_const_expr(node.rhs)
	case ND_COND:
		if !is_const_expr(node.cond) {
			return false
		}
		if 0 != eval(node.cond) {
			return is_const_expr(node.then)
		} else {
			return is_const_expr(node.els)
		}
	case ND_COMMA:
		return is_const_expr(node.rhs)
	case ND_NEG, ND_NOT, ND_BITNOT, ND_CAST:
		return is_const_expr(node.lhs)
	case ND_NUM:
		return true
	}

	return false
}

func const_expr(rest **Token, tok *Token) int64 {
	node := conditional(rest, tok)
	return eval(node)
}

func eval_double(node *Node) float64 {
	add_type(node)

	if is_integer(node.ty) {
		if node.ty.is_unsigned {
			return float64(uint64(eval(node)))
		}
		return float64(eval(node))
	}

	switch node.kind {
	case ND_ADD:
		return eval_double(node.lhs) + eval_double(node.rhs)
	case ND_SUB:
		return eval_double(node.lhs) - eval_double(node.rhs)
	case ND_MUL:
		return eval_double(node.lhs) * eval_double(node.rhs)
	case ND_DIV:
		return eval_double(node.lhs) / eval_double(node.rhs)
	case ND_NEG:
		return -eval_double(node.lhs)
	case ND_COND:
		var ret float64
		cond := eval_double(node.cond)
		if cond != 0.0 {
			ret = eval_double(node.then)
		} else {
			ret = eval_double(node.els)
		}
		return ret
	case ND_COMMA:
		return eval_double(node.rhs)
	case ND_CAST:
		if is_flonum(node.lhs.ty) {
			return eval_double(node.lhs)
		}
		return float64(eval(node.lhs))
	case ND_NUM:
		return node.fval
	}

	error_tok(node.tok, "not a compile-time constant")
	return 0.0 //Won't be reached
}

// Convert op= operators to expressions containing an assignment.
//
// In general, `A op= C` is converted to “tmp = &A, *tmp = *tmp op B`.
// However, if a given expression is of form `A.x op= C`, the input is
// converted to `tmp = &A, (*tmp).x = (*tmp).x op C` to handle assignments
// to bitfields.
func to_assign(binary *Node) *Node {
	add_type(binary.lhs)
	add_type(binary.rhs)
	tok := binary.tok

	// Convert `A.x op= C` to `tmp = &A, (*tmp).x = (*tmp).x op C`.
	if binary.lhs.kind == ND_MEMBER {
		varr := new_lvar("", pointer_to(binary.lhs.lhs.ty))

		expr1 := new_binary(ND_ASSIGN, new_var_node(varr, tok),
			new_unary(ND_ADDR, binary.lhs.lhs, tok), tok)

		expr2 := new_unary(ND_MEMBER,
			new_unary(ND_DEREF, new_var_node(varr, tok), tok),
			tok)
		expr2.member = binary.lhs.member

		expr3 := new_unary(ND_MEMBER,
			new_unary(ND_DEREF, new_var_node(varr, tok), tok),
			tok)
		expr3.member = binary.lhs.member

		expr4 := new_binary(ND_ASSIGN, expr2,
			new_binary(binary.kind, expr3, binary.rhs, tok),
			tok)

		return new_binary(ND_COMMA, expr1, expr4, tok)
	}

	// If A is an atomic type, Convert `A op= B` to
	//
	// ({
	//   T1 *addr = &A; T2 val = (B); T1 old = *addr; T1 new;
	//   do {
	//    new = old op val;
	//   } while (!atomic_compare_exchange_strong(addr, &old, new));
	//   new;
	// })
	if binary.lhs.ty.is_atomic {
		head := Node{}
		cur := &head

		addr := new_lvar("", pointer_to(binary.lhs.ty))
		val := new_lvar("", binary.rhs.ty)
		old := new_lvar("", binary.lhs.ty)
		new := new_lvar("", binary.lhs.ty)

		cur.next =
			new_unary(ND_EXPR_STMT,
				new_binary(ND_ASSIGN, new_var_node(addr, tok),
					new_unary(ND_ADDR, binary.lhs, tok), tok),
				tok)
		cur = cur.next

		cur.next =
			new_unary(ND_EXPR_STMT,
				new_binary(ND_ASSIGN, new_var_node(val, tok), binary.rhs, tok),
				tok)
		cur = cur.next

		cur.next =
			new_unary(ND_EXPR_STMT,
				new_binary(ND_ASSIGN, new_var_node(old, tok),
					new_unary(ND_DEREF, new_var_node(addr, tok), tok), tok),
				tok)
		cur = cur.next

		loop := new_node(ND_DO, tok)
		loop.brk_label = new_unique_name()
		loop.cont_label = new_unique_name()

		body := new_binary(ND_ASSIGN,
			new_var_node(new, tok),
			new_binary(binary.kind, new_var_node(old, tok),
				new_var_node(val, tok), tok),
			tok)

		loop.then = new_node(ND_BLOCK, tok)
		loop.then.body = new_unary(ND_EXPR_STMT, body, tok)

		cas := new_node(ND_CAS, tok)
		cas.cas_addr = new_var_node(addr, tok)
		cas.cas_old = new_unary(ND_ADDR, new_var_node(old, tok), tok)
		cas.cas_new = new_var_node(new, tok)
		loop.cond = new_unary(ND_NOT, cas, tok)

		cur.next = loop
		cur = cur.next

		cur.next = new_unary(ND_EXPR_STMT, new_var_node(new, tok), tok)
		cur = cur.next

		node := new_node(ND_STMT_EXPR, tok)
		node.body = head.next
		return node
	}

	// Convert `A op= B` to ``tmp = &A, *tmp = *tmp op B`.
	varr := new_lvar("", pointer_to(binary.lhs.ty))

	expr1 := new_binary(ND_ASSIGN, new_var_node(varr, tok),
		new_unary(ND_ADDR, binary.lhs, tok), tok)

	expr2 :=
		new_binary(ND_ASSIGN,
			new_unary(ND_DEREF, new_var_node(varr, tok), tok),
			new_binary(binary.kind,
				new_unary(ND_DEREF, new_var_node(varr, tok), tok),
				binary.rhs,
				tok),
			tok)

	return new_binary(ND_COMMA, expr1, expr2, tok)
}

/*
// assign    = conditional (assign-op assign)?
// assign-op = "=" | "+=" | "-=" | "*=" | "/=" | "%=" | "&=" | "|=" | "^="
//           | "<<=" | ">>="
*/
func assign(rest **Token, tok *Token) *Node {
	node := conditional(&tok, tok)

	if equal(tok, "=") {
		return new_binary(ND_ASSIGN, node, assign(rest, tok.next), tok)
	}

	if equal(tok, "+=") {
		return to_assign(new_add(node, assign(rest, tok.next), tok))
	}

	if equal(tok, "-=") {
		return to_assign(new_sub(node, assign(rest, tok.next), tok))
	}

	if equal(tok, "*=") {
		return to_assign(new_binary(ND_MUL, node, assign(rest, tok.next), tok))
	}

	if equal(tok, "/=") {
		return to_assign(new_binary(ND_DIV, node, assign(rest, tok.next), tok))
	}

	if equal(tok, "%=") {
		return to_assign(new_binary(ND_MOD, node, assign(rest, tok.next), tok))
	}

	if equal(tok, "&=") {
		return to_assign(new_binary(ND_BITAND, node, assign(rest, tok.next), tok))
	}

	if equal(tok, "|=") {
		return to_assign(new_binary(ND_BITOR, node, assign(rest, tok.next), tok))
	}

	if equal(tok, "^=") {
		return to_assign(new_binary(ND_BITXOR, node, assign(rest, tok.next), tok))
	}

	if equal(tok, "<<=") {
		return to_assign(new_binary(ND_SHL, node, assign(rest, tok.next), tok))
	}

	if equal(tok, ">>=") {
		return to_assign(new_binary(ND_SHR, node, assign(rest, tok.next), tok))
	}

	*rest = tok
	return node
}

// conditional = logor ("?" expr? ":" conditional)?
func conditional(rest **Token, tok *Token) *Node {
	cond := logor(&tok, tok)

	if !equal(tok, "?") {
		*rest = tok
		return cond
	}

	if equal(tok.next, ":") {
		// [GNU] Compile `a ?: b` as `tmp = a, tmp ? tmp : b`.
		add_type(cond)
		varr := new_lvar("", cond.ty)
		lhs := new_binary(ND_ASSIGN, new_var_node(varr, tok), cond, tok)
		rhs := new_node(ND_COND, tok)
		rhs.cond = new_var_node(varr, tok)
		rhs.then = new_var_node(varr, tok)
		rhs.els = conditional(rest, tok.next.next)
		return new_binary(ND_COMMA, lhs, rhs, tok)
	}

	node := new_node(ND_COND, tok)
	node.cond = cond
	node.then = expr(&tok, tok.next)
	tok = skip(tok, ":")
	node.els = conditional(rest, tok)
	return node
}

// logor = logand ("||" logand)*
func logor(rest **Token, tok *Token) *Node {
	node := logand(&tok, tok)
	for equal(tok, "||") {
		start := tok
		node = new_binary(ND_LOGOR, node, logand(&tok, tok.next), start)
	}
	*rest = tok
	return node
}

// logand = bitor ("&&" bitor)*
func logand(rest **Token, tok *Token) *Node {
	node := bitor(&tok, tok)
	for equal(tok, "&&") {
		start := tok
		node = new_binary(ND_LOGAND, node, bitor(&tok, tok.next), start)
	}
	*rest = tok
	return node
}

// bitor = bitxor ("|" bitxor)*
func bitor(rest **Token, tok *Token) *Node {
	node := bitxor(&tok, tok)
	for equal(tok, "|") {
		start := tok
		node = new_binary(ND_BITOR, node, bitxor(&tok, tok.next), start)
	}
	*rest = tok
	return node
}

// bitxor = bitand ("^" bitand)*
func bitxor(rest **Token, tok *Token) *Node {
	node := bitand(&tok, tok)
	for equal(tok, "^") {
		start := tok
		node = new_binary(ND_BITXOR, node, bitand(&tok, tok.next), start)
	}
	*rest = tok
	return node
}

// bitand = equality ("&" equality)*
func bitand(rest **Token, tok *Token) *Node {
	node := equality(&tok, tok)
	for equal(tok, "&") {
		start := tok
		node = new_binary(ND_BITAND, node, equality(&tok, tok.next), start)
	}
	*rest = tok
	return node
}

// equality = relational ("==" relational | "!=" relational)*
func equality(rest **Token, tok *Token) *Node {
	node := relational(&tok, tok)

	for {
		start := tok
		if equal(tok, "==") {
			node = new_binary(ND_EQ, node, relational(&tok, tok.next), start)
			continue
		}

		if equal(tok, "!=") {
			node = new_binary(ND_NE, node, relational(&tok, tok.next), start)
			continue
		}

		*rest = tok
		return node
	}
}

// relational = shift ("<" shift | "<=" shift | ">" shift | ">=" shift)*
func relational(rest **Token, tok *Token) *Node {
	node := shift(&tok, tok)

	for {
		start := tok
		if equal(tok, "<") {
			node = new_binary(ND_LT, node, shift(&tok, tok.next), start)
			continue
		}

		if equal(tok, "<=") {
			node = new_binary(ND_LE, node, shift(&tok, tok.next), start)
			continue
		}

		if equal(tok, ">") {
			node = new_binary(ND_LT, shift(&tok, tok.next), node, start)
			continue
		}

		if equal(tok, ">=") {
			node = new_binary(ND_LE, shift(&tok, tok.next), node, start)
			continue
		}

		*rest = tok
		return node
	}
}

// shift = add ("<<" add | ">>" add)*
func shift(rest **Token, tok *Token) *Node {
	node := add(&tok, tok)

	for {
		start := tok

		if equal(tok, "<<") {
			node = new_binary(ND_SHL, node, add(&tok, tok.next), start)
			continue
		}

		if equal(tok, ">>") {
			node = new_binary(ND_SHR, node, add(&tok, tok.next), start)
			continue
		}

		*rest = tok
		return node
	}
}

// In C, `+` operator is overloaded to perform the pointer arithmetic.
// If p is a pointer, p+n adds not n but sizeof(*p)*n to the value of p,
// so that p+n points to the location n elements (not bytes) ahead of p.
// In other words, we need to scale an integer value before adding to a
// pointer value. This function takes care of the scaling.
func new_add(lhs *Node, rhs *Node, tok *Token) *Node {
	add_type(lhs)
	add_type(rhs)

	// num + num
	if is_numeric(lhs.ty) && is_numeric(rhs.ty) {
		return new_binary(ND_ADD, lhs, rhs, tok)
	}

	if lhs.ty.base != nil && rhs.ty.base != nil {
		error_tok(tok, "invalid operands")
	}

	// Canonicalize `num + ptr` to `ptr + num`.
	if lhs.ty.base == nil && rhs.ty.base != nil {
		tmp := lhs
		lhs = rhs
		rhs = tmp
	}

	// VLA + num
	if lhs.ty.base.kind == TY_VLA {
		rhs = new_binary(ND_MUL, rhs, new_var_node(lhs.ty.base.vla_size, tok), tok)
		return new_binary(ND_ADD, lhs, rhs, tok)
	}

	// ptr + num
	rhs = new_binary(ND_MUL, rhs, new_long(int64(lhs.ty.base.size), tok), tok)
	return new_binary(ND_ADD, lhs, rhs, tok)
}

// Like `+`, `-` is overloaded for the pointer type.
func new_sub(lhs *Node, rhs *Node, tok *Token) *Node {
	add_type(lhs)
	add_type(rhs)

	// num - num
	if is_numeric(lhs.ty) && is_numeric(rhs.ty) {
		return new_binary(ND_SUB, lhs, rhs, tok)
	}

	// VLA - num
	if lhs.ty.base.kind == TY_VLA {
		rhs = new_binary(ND_MUL, rhs, new_var_node(lhs.ty.base.vla_size, tok), tok)
		add_type(rhs)
		node := new_binary(ND_SUB, lhs, rhs, tok)
		node.ty = lhs.ty
		return node
	}

	// ptr - num
	if lhs.ty.base != nil && is_integer(rhs.ty) {
		rhs = new_binary(ND_MUL, rhs, new_long(int64(lhs.ty.base.size), tok), tok)
		add_type(rhs)
		node := new_binary(ND_SUB, lhs, rhs, tok)
		node.ty = lhs.ty
		return node
	}

	// ptr - ptr, which returns how many elements are between the two.
	if lhs.ty.base != nil && rhs.ty.base != nil {
		node := new_binary(ND_SUB, lhs, rhs, tok)
		node.ty = ty_long
		return new_binary(ND_DIV, node, new_num(int64(lhs.ty.base.size), tok), tok)
	}

	error_tok(tok, "invalid operands")
	return nil //won't be reached
}

// add = mul ("+" mul | "-" mul)*
func add(rest **Token, tok *Token) *Node {
	node := mul(&tok, tok)

	for {
		start := tok

		if equal(tok, "+") {
			node = new_add(node, mul(&tok, tok.next), start)
			continue
		}

		if equal(tok, "-") {
			node = new_sub(node, mul(&tok, tok.next), start)
			continue
		}

		*rest = tok
		return node
	}
}

// mul = cast ("*" cast | "/" cast | "%" cast)*
func mul(rest **Token, tok *Token) *Node {
	node := cast(&tok, tok)

	for {
		start := tok

		if equal(tok, "*") {
			node = new_binary(ND_MUL, node, cast(&tok, tok.next), start)
			continue
		}

		if equal(tok, "/") {
			node = new_binary(ND_DIV, node, cast(&tok, tok.next), start)
			continue
		}

		if equal(tok, "%") {
			node = new_binary(ND_MOD, node, cast(&tok, tok.next), start)
			continue
		}

		*rest = tok
		return node
	}
}

// cast = "(" type-name ")" cast | unary
func cast(rest **Token, tok *Token) *Node {
	if equal(tok, "(") && is_typename(tok.next) {
		start := tok
		ty := typename(&tok, tok.next)
		tok = skip(tok, ")")

		// compound literal
		if equal(tok, "{") {
			return unary(rest, start)
		}

		// type cast
		node := new_cast(cast(rest, tok), ty)
		node.tok = start
		return node
	}

	return unary(rest, tok)
}

/*
// unary = ("+" | "-" | "*" | "&" | "!" | "~") cast
//	| ("++" | "--") unary
//  | "&&" ident
//	| postfix
*/
func unary(rest **Token, tok *Token) *Node {
	if equal(tok, "+") {
		return cast(rest, tok.next)
	}

	if equal(tok, "-") {
		return new_unary(ND_NEG, cast(rest, tok.next), tok)
	}

	if equal(tok, "&") {
		lhs := cast(rest, tok.next)
		add_type(lhs)
		if lhs.kind == ND_MEMBER && lhs.member.is_bitfield {
			error_tok(tok, "cannot take address of bitfield")
		}
		return new_unary(ND_ADDR, lhs, tok)
	}

	if equal(tok, "*") {
		// [https://www.sigbus.info/n1570#6.5.3.2p4] This is an oddity
		// in the C spec, but dereferencing a function shouldn't do
		// anything. If foo is a function, `*foo`, `**foo` or `*****foo`
		// are all equivalent to just `foo`.
		node := cast(rest, tok.next)
		add_type(node)
		if node.ty.kind == TY_FUNC {
			return node
		}
		return new_unary(ND_DEREF, node, tok)
	}

	if equal(tok, "!") {
		return new_unary(ND_NOT, cast(rest, tok.next), tok)
	}

	if equal(tok, "~") {
		return new_unary(ND_BITNOT, cast(rest, tok.next), tok)
	}

	// Read ++i as i+=1
	if equal(tok, "++") {
		return to_assign(new_add(unary(rest, tok.next), new_num(1, tok), tok))
	}

	// Read --i as i-=1
	if equal(tok, "--") {
		return to_assign(new_sub(unary(rest, tok.next), new_num(1, tok), tok))
	}

	// [GNU] labels-as-values
	if equal(tok, "&&") {
		node := new_node(ND_LABEL_VAL, tok)
		node.label = get_ident(tok.next)
		node.goto_next = gotos
		gotos = node
		*rest = tok.next.next
		return node
	}

	return postfix(rest, tok)
}

// struct-members = (declspec declarator (","  declarator)* ";")*
func struct_members(rest **Token, tok *Token, ty *Type) {
	head := Member{}
	cur := &head
	idx := 0

	for !equal(tok, "}") {
		attr := VarAttr{}
		basety := declspec(&tok, tok, &attr)
		first := true

		// Anonymous struct member
		if (basety.kind == TY_STRUCT || basety.kind == TY_UNION) && consume(&tok, tok, ";") {
			mem := &Member{}
			mem.ty = basety
			mem.idx = idx
			idx++
			if attr.align != 0 {
				mem.align = attr.align
			} else {
				mem.align = mem.ty.align
			}
			cur.next = mem
			cur = cur.next
			continue
		}

		// Regular struct members
		for !consume(&tok, tok, ";") {
			if !first {
				tok = skip(tok, ",")
			}
			first = false

			mem := Member{}
			mem.ty = declarator(&tok, tok, basety)

			if mem.ty.name == nil {
				mem.name = ""
			} else {
				mem.name = mem.ty.name.lexeme
			}
			mem.idx = idx
			idx++

			if attr.align != 0 {
				mem.align = attr.align
			} else {
				mem.align = mem.ty.align
			}

			if consume(&tok, tok, ":") {
				mem.is_bitfield = true
				mem.bit_width = int(const_expr(&tok, tok))
			}

			cur.next = &mem
			cur = cur.next
		}
	}

	// If the last element is an array of incomplete type, it's
	// called a "flexible array member". It should behave as if
	// if were a zero-sized array.
	if cur != &head && cur.ty.kind == TY_ARRAY && cur.ty.array_len < 0 {
		cur.ty = array_of(cur.ty.base, 0)
		ty.is_flexible = true
	}

	*rest = tok.next
	ty.members = head.next
}

// attribute = ("__attribute__" "(" "(" "packed" ")" ")")*
func attribute_list(tok *Token, ty *Type) *Token {
	for consume(&tok, tok, "__attribute__") {
		tok = skip(tok, "(")
		tok = skip(tok, "(")

		first := true

		for !consume(&tok, tok, ")") {
			if !first {
				tok = skip(tok, ",")
			}
			first = false

			if consume(&tok, tok, "packed") {
				ty.is_packed = true
				continue
			}

			if consume(&tok, tok, "aligned") {
				tok = skip(tok, "(")
				ty.align = int(const_expr(&tok, tok))
				tok = skip(tok, ")")
				continue
			}

			error_tok(tok, "unknown attribute")
		}

		tok = skip(tok, ")")
	}

	return tok
}

// struct-union-decl = ident? ("{" struct-members)?
func struct_union_decl(rest **Token, tok *Token) *Type {
	ty := struct_type()
	tok = attribute_list(tok, ty)

	// Read a tag.
	var tag *Token = nil
	if tok.kind == TK_IDENT {
		tag = tok
		tok = tok.next
	}

	if tag != nil && !equal(tok, "{") {
		*rest = tok

		ty2 := find_tag(tag)
		if ty2 != nil {
			return ty2
		}

		ty.size = -1
		push_tag_scope(tag, ty)
		return ty
	}

	tok = skip(tok, "{")

	// Construct a struct object.
	struct_members(&tok, tok, ty)
	*rest = attribute_list(tok, ty)

	if tag != nil {
		// If this is a redefinition, overwrite a previous type.
		// Otherwise, register the struct type.
		ty2 := scope.tags[tag.lexeme]
		if ty2 != nil {
			*ty2 = *ty
			return ty2
		}
		push_tag_scope(tag, ty)
	}

	return ty
}

// struct-decl = struct-union-decl
func struct_decl(rest **Token, tok *Token) *Type {
	ty := struct_union_decl(rest, tok)
	ty.kind = TY_STRUCT

	if ty.size < 0 {
		return ty
	}

	// Assign offsets within the struct to members.
	bits := 0
	for mem := ty.members; mem != nil; mem = mem.next {
		if mem.is_bitfield && mem.bit_width == 0 {
			// Zero-width anonymous bitfield has a special meaning.
			// It affects only alignment.
			bits = align_to(bits, mem.ty.size*8)
		} else if mem.is_bitfield {
			sz := mem.ty.size
			if bits/(sz*8) != (bits+mem.bit_width-1)/(sz*8) {
				bits = align_to(bits, sz*8)
			}

			mem.offset = align_down(bits/8, sz)
			mem.bit_offset = bits % (sz * 8)
			bits += mem.bit_width
		} else {
			if !ty.is_packed {
				bits = align_to(bits, mem.align*8)
			}
			mem.offset = bits / 8
			bits += mem.ty.size * 8
		}

		if !ty.is_packed && ty.align < mem.align {
			ty.align = mem.align
		}
	}
	ty.size = align_to(bits, ty.align*8) / 8
	return ty
}

// union-decl = struct-union-decl
func union_decl(rest **Token, tok *Token) *Type {
	ty := struct_union_decl(rest, tok)
	ty.kind = TY_UNION

	if ty.size < 0 {
		return ty
	}

	// If union, we don't have to assign offsets because they
	// are already initialized to zero. We need to compute the
	// alignment and the size though.
	for mem := ty.members; mem != nil; mem = mem.next {
		if ty.align < mem.align {
			ty.align = mem.align
		}
		if ty.size < mem.ty.size {
			ty.size = mem.ty.size
		}
	}
	ty.size = align_to(ty.size, ty.align)
	return ty
}

// Find a struct member by name.
func get_struct_member(ty *Type, tok *Token) *Member {
	for mem := ty.members; mem != nil; mem = mem.next {
		// Anonymous struct member
		if (mem.ty.kind == TY_STRUCT || mem.ty.kind == TY_UNION) && (mem.name == "") {
			if nil != get_struct_member(mem.ty, tok) {
				return mem
			}
			continue
		}

		// Regular struct member
		if mem.name == tok.lexeme {
			return mem
		}
	}
	return nil
}

// Create a node representing a struct member access, such as foo.bar
// where foo is a struct and bar is a member name.
//
// C has a feature called "anonymous struct" which allows a struct to
// have another unnamed struct as a member like this:
//
//	struct { struct { int a; }; int b; } x;
//
// The members of an anonymous struct belong to the outer struct's
// member namespace. Therefore, in the above example, you can access
// member "a" of the anonymous struct as "x.a".
//
// This function takes care of anonymous structs.
func struct_ref(node *Node, tok *Token) *Node {
	add_type(node)
	if node.ty.kind != TY_STRUCT && node.ty.kind != TY_UNION {
		error_tok(node.tok, "not a struct nor a union")
	}

	ty := node.ty

	for {
		mem := get_struct_member(ty, tok)
		if nil == mem {
			error_tok(tok, "no such member")
		}
		node = new_unary(ND_MEMBER, node, tok)
		node.member = mem
		if mem.name != "" {
			break
		}
		ty = mem.ty
	}
	return node
}

// Convert A++ to `(typeof A)((A += 1) - 1)`
func new_inc_dec(node *Node, tok *Token, addend int) *Node {
	add_type(node)
	return new_cast(new_add(to_assign(new_add(node, new_num(int64(addend), tok), tok)),
		new_num(int64(-addend), tok), tok),
		node.ty)
}

/*
// postfix = "(" type-name ")" "{" initializer-list "}"
//         = ident "(" func-args ")" postfix-tail*
//         | primary postfix-tail*
//
// postfix-tail = "[" expr "]"
//              | "(" func-args ")"
//              | "." ident
//              | "->" ident
//              | "++"
//              | "--"
*/
func postfix(rest **Token, tok *Token) *Node {
	if equal(tok, "(") && is_typename(tok.next) {
		// Compound literal
		start := tok
		ty := typename(&tok, tok.next)
		tok = skip(tok, ")")

		if scope.next == nil {
			varr := new_anon_gvar(ty)
			gvar_initializer(rest, tok, varr)
			return new_var_node(varr, start)
		}

		varr := new_lvar("", ty)
		lhs := lvar_initializer(rest, tok, varr)
		rhs := new_var_node(varr, tok)
		return new_binary(ND_COMMA, lhs, rhs, start)
	}

	node := primary(&tok, tok)

	for {
		if equal(tok, "(") {
			node = funcall(&tok, tok.next, node)
			continue
		}

		if equal(tok, "[") {
			// x[y] is short for *(x+y)
			start := tok
			idx := expr(&tok, tok.next)
			tok = skip(tok, "]")
			node = new_unary(ND_DEREF, new_add(node, idx, start), start)
			continue
		}

		if equal(tok, ".") {
			node = struct_ref(node, tok.next)
			tok = tok.next.next
			continue
		}

		if equal(tok, "->") {
			// x->y is short for (*x).y
			node = new_unary(ND_DEREF, node, tok)
			node = struct_ref(node, tok.next)
			tok = tok.next.next
			continue
		}

		if equal(tok, "++") {
			node = new_inc_dec(node, tok, 1)
			tok = tok.next
			continue
		}

		if equal(tok, "--") {
			node = new_inc_dec(node, tok, -1)
			tok = tok.next
			continue
		}

		*rest = tok
		return node
	}
}

// funcall = (assign ("," assign)*)? ")"
func funcall(rest **Token, tok *Token, fn *Node) *Node {
	add_type(fn)

	if fn.ty.kind != TY_FUNC && (fn.ty.kind != TY_PTR || fn.ty.base.kind != TY_FUNC) {
		error_tok(fn.tok, "not a function")
	}

	var ty *Type
	if fn.ty.kind == TY_FUNC {
		ty = fn.ty
	} else {
		ty = fn.ty.base
	}
	param_ty := ty.params

	head := Node{}
	cur := &head

	for !equal(tok, ")") {
		if cur != &head {
			tok = skip(tok, ",")
		}

		arg := assign(&tok, tok)
		add_type(arg)

		if nil == param_ty && !ty.is_variadic {
			error_tok(tok, "too many arguments")
		}

		if param_ty != nil {
			if param_ty.kind != TY_STRUCT && param_ty.kind != TY_UNION {
				arg = new_cast(arg, param_ty)
			}
			param_ty = param_ty.next
		} else if arg.ty.kind == TY_FLOAT {
			// If parameter type is omitted (e.g. in "..."), float
			// arguments are promoted to double.
			arg = new_cast(arg, ty_double)
		}

		cur.next = arg
		cur = cur.next
	}

	if param_ty != nil {
		error_tok(tok, "too few arguments")
	}

	*rest = skip(tok, ")")

	node := new_unary(ND_FUNCALL, fn, tok)
	node.func_ty = ty
	node.ty = ty.return_ty
	node.args = head.next

	// If a function returns a struct, it is caller's responsibility
	// to allocate a space for the return value.
	if node.ty.kind == TY_STRUCT || node.ty.kind == TY_UNION {
		node.ret_buffer = new_lvar("", node.ty)
	}

	return node
}

// generic-selection = "(" assign "," generic-assoc ("," generic-assoc)* ")"
//
// generic-assoc = type-name ":" assign
//
//	| "default" ":" assign
func generic_selection(rest **Token, tok *Token) *Node {
	start := tok
	tok = skip(tok, "(")

	ctrl := assign(&tok, tok)
	add_type(ctrl)

	t1 := ctrl.ty
	if t1.kind == TY_FUNC {
		t1 = pointer_to(t1)
	} else if t1.kind == TY_ARRAY {
		t1 = pointer_to(t1.base)
	}

	var ret *Node

	for !consume(rest, tok, ")") {
		tok = skip(tok, ",")

		if equal(tok, "default") {
			tok = skip(tok.next, ":")
			node := assign(&tok, tok)
			if nil == ret {
				ret = node
			}
			continue
		}

		t2 := typename(&tok, tok)
		tok = skip(tok, ":")
		node := assign(&tok, tok)
		if is_compatible(t1, t2) {
			ret = node
		}
	}

	if nil == ret {
		error_tok(start, "controlling expression type not compatible with any generic association type")
	}
	return ret
}

/*
// primary = "(" "{" stmt+ "}" ")"
//         | "(" expr ")"
//         | "sizeof" "(" type-name ")"
//         | "sizeof" unary
//         | "_Alignof" "(" type-name ")"
//         | "_Alignof" unary
//         | "_Generic" generic-selection
//         | "__builtin_types_compatible_p" "(" type-name, type-name, ")"
//         | "__builtin_reg_class" "(" type-name ")"
//         | ident
//         | str
//         | num
*/
func primary(rest **Token, tok *Token) *Node {
	start := tok

	if equal(tok, "(") && equal(tok.next, "{") {
		// This is a GNU statement expresssion.
		node := new_node(ND_STMT_EXPR, tok)
		node.body = compound_stmt(&tok, tok.next.next).body
		*rest = skip(tok, ")")
		return node
	}

	if equal(tok, "(") {
		node := expr(&tok, tok.next)
		*rest = skip(tok, ")")
		return node
	}

	if equal(tok, "sizeof") && equal(tok.next, "(") && is_typename(tok.next.next) {
		ty := typename(&tok, tok.next.next)
		*rest = skip(tok, ")")

		if ty.kind == TY_VLA {
			if ty.vla_size != nil {
				return new_var_node(ty.vla_size, tok)
			}

			lhs := compute_vla_size(ty, tok)
			rhs := new_var_node(ty.vla_size, tok)
			return new_binary(ND_COMMA, lhs, rhs, tok)
		}

		return new_ulong(int64(ty.size), start)
	}

	if equal(tok, "sizeof") {
		node := unary(rest, tok.next)
		add_type(node)
		if node.ty.kind == TY_VLA {
			return new_var_node(node.ty.vla_size, tok)
		}
		return new_ulong(int64(node.ty.size), tok)
	}

	if equal(tok, "_Alignof") && equal(tok.next, "(") && is_typename(tok.next.next) {
		ty := typename(&tok, tok.next.next)
		*rest = skip(tok, ")")
		return new_ulong(int64(ty.align), tok)
	}

	if equal(tok, "_Alignof") {
		node := unary(rest, tok.next)
		add_type(node)
		return new_ulong(int64(node.ty.align), tok)
	}

	if equal(tok, "_Generic") {
		return generic_selection(rest, tok.next)
	}

	if equal(tok, "__builtin_types_compatible_p") {
		tok = skip(tok.next, "(")
		t1 := typename(&tok, tok)
		tok = skip(tok, ",")
		t2 := typename(&tok, tok)
		*rest = skip(tok, ")")
		var ret int64
		if is_compatible(t1, t2) {
			ret = 1
		} else {
			ret = 0
		}
		return new_num(ret, start)
	}

	if equal(tok, "__builtin_reg_class") {
		tok = skip(tok.next, "(")
		ty := typename(&tok, tok)
		*rest = skip(tok, ")")

		if is_integer(ty) || ty.kind == TY_PTR {
			return new_num(0, start)
		}
		if is_flonum(ty) {
			return new_num(1, start)
		}
		return new_num(2, start)
	}

	if equal(tok, "__builtin_compare_and_swap") {
		node := new_node(ND_CAS, tok)
		tok = skip(tok.next, "(")
		node.cas_addr = assign(&tok, tok)
		tok = skip(tok, ",")
		node.cas_old = assign(&tok, tok)
		tok = skip(tok, ",")
		node.cas_new = assign(&tok, tok)
		*rest = skip(tok, ")")
		return node
	}

	if equal(tok, "__builtin_atomic_exchange") {
		node := new_node(ND_EXCH, tok)
		tok = skip(tok.next, "(")
		node.lhs = assign(&tok, tok)
		tok = skip(tok, ",")
		node.rhs = assign(&tok, tok)
		*rest = skip(tok, ")")
		return node
	}

	if tok.kind == TK_IDENT {
		// Variable or enum constant
		sc := find_var(tok)
		*rest = tok.next

		// For "static inline" function
		if sc != nil && sc.varr != nil && sc.varr.is_function {
			if parse_current_fn != nil {
				parse_current_fn.refs = append(parse_current_fn.refs, sc.varr.name)
			} else {
				sc.varr.is_root = true
			}
		}

		if sc != nil {
			if sc.varr != nil {
				return new_var_node(sc.varr, tok)
			}
			if sc.enum_ty != nil {
				return new_num(int64(sc.enum_val), tok)
			}
		}

		if equal(tok.next, "(") {
			error_tok(tok, "implicit declaration of a function")
		}
		error_tok(tok, "undefined variable")
	}

	if tok.kind == TK_STR {
		varr := new_str_literal_ex(tok, tok.ty)
		*rest = tok.next
		return new_var_node(varr, tok)
	}

	if tok.kind == TK_NUM {
		var node *Node
		if is_flonum(tok.ty) {
			node = new_node(ND_NUM, tok)
			node.fval = tok.fval
		} else {
			node = new_num(tok.val, tok)
		}

		node.ty = tok.ty
		*rest = tok.next
		return node
	}

	error_tok(tok, "expected an expression")
	return nil //won't be reached
}

func parse_typedef(tok *Token, basety *Type) *Token {
	first := true

	for !consume(&tok, tok, ";") {
		if !first {
			tok = skip(tok, ",")
		}
		first = false

		ty := declarator(&tok, tok, basety)
		if nil == ty.name {
			error_tok(ty.name_pos, "typedef name omitted")
		}
		push_scope(get_ident(ty.name)).type_def = ty
	}
	return tok
}

func create_param_lvars(param *Type) {
	if param != nil {
		create_param_lvars(param.next)
		if nil == param.name {
			error_tok(param.name_pos, "parameter name omitted")
		}
		new_lvar(get_ident(param.name), param)
	}
}

// This function matches gotos or labels-as-values with labels.
//
// We cannot resolve gotos as we parse a function because gotos
// can refer a label that appears later in the function.
// So, we need to do this after we parse the entire function.
func resolve_goto_labels() {
	for x := gotos; x != nil; x = x.goto_next {
		for y := labels; y != nil; y = y.goto_next {
			if x.label == y.label {
				x.unique_label = y.unique_label
				break
			}
		}

		if x.unique_label == "" {
			error_tok(x.tok.next, "use of undeclared label")
		}
	}

	gotos = nil
	labels = nil
}

func find_func(name string) *Obj {
	sc := scope
	for sc.next != nil {
		sc = sc.next
	}

	sc2 := sc.vars[name]
	if sc2 != nil && sc2.varr != nil && sc2.varr.is_function {
		return sc2.varr
	}

	return nil
}

func mark_live(varr *Obj) {
	if !varr.is_function || varr.is_live {
		return
	}
	varr.is_live = true

	for i := 0; i < len(varr.refs); i++ {
		fn := find_func(varr.refs[i])
		if fn != nil {
			mark_live(fn)
		}
	}
}

func function(tok *Token, basety *Type, attr *VarAttr) *Token {
	ty := declarator(&tok, tok, basety)
	if nil == ty.name {
		error_tok(ty.name_pos, "function name omitted")
	}

	name_str := get_ident(ty.name)

	fn := find_func(name_str)
	if fn != nil {
		// Redeclaration
		if !fn.is_function {
			error_tok(tok, "redeclared as a different kind of symbol")
		}
		if fn.is_definition && equal(tok, "{") {
			error_tok(tok, "redefinition of %s", name_str)
		}
		if !fn.is_static && attr.is_static {
			error_tok(tok, "static declaration follows a non-static declaration")
		}
		fn.is_definition = fn.is_definition || equal(tok, "{")
	} else {
		fn = new_gvar(name_str, ty)
		fn.is_function = true
		fn.is_definition = equal(tok, "{")
		fn.is_static = attr.is_static || (attr.is_inline && !attr.is_extern)
		fn.is_inline = attr.is_inline
	}

	fn.is_root = !(fn.is_static && fn.is_inline)

	if consume(&tok, tok, ";") {
		return tok
	}

	parse_current_fn = fn
	locals = nil
	enter_scope()
	create_param_lvars(ty.params)

	// A buffer for a struct/union return value is passed
	// as the hidden first parameter.
	rty := ty.return_ty
	if (rty.kind == TY_STRUCT || rty.kind == TY_UNION) && rty.size > 16 {
		new_lvar("", pointer_to(rty))
	}

	fn.params = locals

	if ty.is_variadic {
		fn.va_area = new_lvar("__va_area__", array_of(ty_char, 136))
	}
	fn.alloca_bottom = new_lvar("__alloca_size__", pointer_to(ty_char))

	tok = skip(tok, "{")

	// [https://www.sigbus.info/n1570#6.4.2.2p1] "__func__" is
	// automatically defined as a local variable containing the
	// current function name.
	var b strings.Builder
	b.WriteString(fn.name)
	b.WriteByte(0)
	s := b.String()
	push_scope("__func__").varr =
		new_str_literal(s, array_of(ty_char, len(s)))

	// [GNU] __FUNCTION__ is yet another name of __func__.
	push_scope("__FUNCTION__").varr =
		new_str_literal(s, array_of(ty_char, len(s)))

	fn.body = compound_stmt(&tok, tok)
	fn.locals = locals
	leave_scope()
	resolve_goto_labels()
	return tok
}

func global_variable(tok *Token, basety *Type, attr *VarAttr) *Token {
	first := true

	for !consume(&tok, tok, ";") {
		if !first {
			tok = skip(tok, ",")
		}
		first = false

		ty := declarator(&tok, tok, basety)
		if nil == ty.name {
			error_tok(ty.name_pos, "variable name omitted")
		}

		varr := new_gvar(get_ident(ty.name), ty)
		varr.is_definition = !attr.is_extern
		varr.is_static = attr.is_static
		varr.is_tls = attr.is_tls
		if attr.align != 0 {
			varr.align = attr.align
		}

		if equal(tok, "=") {
			gvar_initializer(&tok, tok.next, varr)
		} else if !attr.is_extern && !attr.is_tls {
			varr.is_tentative = true
		}
	}
	return tok
}

// Lookahead tokens and returns true if a given token is a start
// of a function definition or declaration.
func is_function(tok *Token) bool {
	if equal(tok, ";") {
		return false
	}

	dummy := Type{}
	ty := declarator(&tok, tok, &dummy)
	return ty.kind == TY_FUNC
}

// Remove redundant tentative definitions.
func scan_globals() {
	head := Obj{}
	cur := &head

	for varr := globals; varr != nil; varr = varr.next {
		if !varr.is_tentative {
			cur.next = varr
			cur = cur.next
			continue
		}

		// Find another definition of the same identifier.
		var2 := globals
		for var2 != nil {
			if varr != var2 && var2.is_definition && varr.name == var2.name {
				break
			}
			var2 = var2.next
		}

		// If there's another definition, the tentative definition
		// is redundant
		if var2 == nil {
			cur.next = varr
			cur = cur.next
		}
	}

	cur.next = nil
	globals = head.next
}

func declare_builtin_functions() {
	ty := func_type(pointer_to(ty_void))
	ty.params = copy_type(ty_int)
	builtin_alloca = new_gvar("alloca", ty)
	builtin_alloca.is_definition = false
}

// program = (typedef | function-definition | global-variable)*
func parse(tok *Token) *Obj {
	declare_builtin_functions()
	globals = nil

	for tok.kind != TK_EOF {
		attr := VarAttr{}
		basety := declspec(&tok, tok, &attr)

		// Typedef
		if attr.is_typedef {
			tok = parse_typedef(tok, basety)
			continue
		}

		// Function
		if is_function(tok) {
			tok = function(tok, basety, &attr)
			continue
		}

		// Global variable
		tok = global_variable(tok, basety, &attr)
	}

	for varr := globals; varr != nil; varr = varr.next {
		if varr.is_root {
			mark_live(varr)
		}
	}

	// Remove redundant tentative definitions.
	scan_globals()
	return globals
}
