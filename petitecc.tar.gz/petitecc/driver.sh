#!/bin/bash
tmp=`mktemp -d /tmp/petitecc-test-XXXXXX`
trap 'rm -rf $tmp' INT TERM HUP EXIT
echo > $tmp/empty.c

check() {
    if [ $? -eq 0 ]; then
        echo "testing $1 ... passed"
    else
        echo "testing $1 ... failed ($?)"
        exit 1
    fi
}

# -o
rm -f $tmp/out
./petitecc -c -o=$tmp/out $tmp/empty.c
[ -f $tmp/out ]
check -o

# --help
./petitecc --help 2>&1 | grep -q petitecc
check --help

# -S
echo 'int main() {}' | ./petitecc -S -o=- -x=c - | grep -q 'main:'
check -S

# Default output file
rm -f $tmp/out.o $tmp/out.s
echo 'int main() {}' > $tmp/out.c
(cd $tmp; $OLDPWD/petitecc -c out.c)
[ -f $tmp/out.o ]
check 'default output file (o)'

(cd $tmp; $OLDPWD/petitecc -c -S out.c)
[ -f $tmp/out.s ]
check 'default output file (S)'

# Multiple input files
rm -f $tmp/foo.o $tmp/bar.o
echo 'int x;' > $tmp/foo.c
echo 'int y;' > $tmp/bar.c
(cd $tmp; $OLDPWD/petitecc -c $tmp/foo.c $tmp/bar.c)
[ -f $tmp/foo.o ] && [ -f $tmp/bar.o ]
check 'multiple input files (o)'

rm -f $tmp/foo.s $tmp/bar.s
echo 'int x;' > $tmp/foo.c
echo 'int y;' > $tmp/bar.c
(cd $tmp; $OLDPWD/petitecc -c -S $tmp/foo.c $tmp/bar.c)
[ -f $tmp/foo.s ] && [ -f $tmp/bar.s ]
check 'multiple input files (S)'

# Run linker
rm -f $tmp/foo
echo 'int main() { return 0; }' | ./petitecc -o=$tmp/foo -x=c -x=c -
$tmp/foo
check linker

rm -f $tmp/foo
echo 'int bar(); int main() { return bar(); }' > $tmp/foo.c
echo 'int bar() { return 42; }' > $tmp/bar.c
./petitecc -o $tmp/foo $tmp/foo.c $tmp/bar.c
$tmp/foo
[ "$?" = 42 ]
check linker

# a.out
rm -f $tmp/a.out
echo 'int main() {}' > $tmp/foo.c
(cd $tmp; $OLDPWD/petitecc foo.c)
[ -f $tmp/a.out ]
check a.out

# -E
echo foo > $tmp/out
echo "#include \"$tmp/out\"" | ./petitecc -E -x=c - | grep -q foo
check -E

echo foo > $tmp/out1
echo "#include \"$tmp/out1\"" | ./petitecc -E -o=$tmp/out2 -x=c -
cat $tmp/out2 | grep -q foo
check '-E and -o'

# -I
mkdir $tmp/dir
echo foo > $tmp/dir/i-option-test
echo "#include \"i-option-test\"" | ./petitecc -I=$tmp/dir -E -x=c - | grep -q foo
check -I

# -D
echo foo | ./petitecc -D foo -E -x=c - | grep -q 1
check -D

# -D
echo foo | ./petitecc -D foo=bar -E -x=c - | grep -q bar
check -D

# -U
echo foo | ./petitecc -D foo=bar -U=foo -E -x=c - | grep -q foo
check -U

# ignored options
./petitecc -c -O -Wall -g -std=c11 -ffreestanding -fno-builtin \
         -fno-omit-frame-pointer -fno-stack-protector -fno-strict-aliasing \
         -m64 -mno-red-zone -w -o=/dev/null $tmp/empty.c
check 'ignored options'

# BOM marker
printf $'\xef\xbb\xbfxyz\n' | ./petitecc -E -o=- -x=c - | grep -q '^xyz'
check 'BOM marker'

# Inline functions
echo 'inline void foo() {}' > $tmp/inline1.c
echo 'inline void foo() {}' > $tmp/inline2.c
echo 'int main() { return 0; }' > $tmp/inline3.c
./petitecc -o=/dev/null $tmp/inline1.c $tmp/inline2.c $tmp/inline3.c
check inline

echo 'extern inline void foo() {}' > $tmp/inline1.c
echo 'int foo(); int main() { foo(); }' > $tmp/inline2.c
./petitecc -o=/dev/null $tmp/inline1.c $tmp/inline2.c
check inline

echo 'static inline void f1() {}' | ./petitecc -o=- -S -x=c - | grep -v -q f1:
check inline

echo 'static inline void f1() {} void foo() { f1(); }' | ./petitecc -o=- -S -x=c - | grep -q f1:
check inline

echo 'static inline void f1() {} static inline void f2() { f1(); } void foo() { f1(); }' | ./petitecc -o=- -S -x=c - | grep -q f1:
check inline

echo 'static inline void f1() {} static inline void f2() { f1(); } void foo() { f1(); }' | ./petitecc -o=- -S -x=c - | grep -v -q f2:
check inline

echo 'static inline void f1() {} static inline void f2() { f1(); } void foo() { f2(); }' | ./petitecc -o=- -S -x=c - | grep -q f1:
check inline

echo 'static inline void f1() {} static inline void f2() { f1(); } void foo() { f2(); }' | ./petitecc -o=- -S -x=c - | grep -q f2:
check inline

echo 'static inline void f2(); static inline void f1() { f2(); } static inline void f2() { f1(); } void foo() {}' | ./petitecc -o=- -S -x=c - | grep -v -q f1:
check inline

echo 'static inline void f2(); static inline void f1() { f2(); } static inline void f2() { f1(); } void foo() {}' | ./petitecc -o=- -S -x=c - | grep -v -q f2:
check inline

echo 'static inline void f2(); static inline void f1() { f2(); } static inline void f2() { f1(); } void foo() { f1(); }' | ./petitecc -o=- -S -x=c - | grep -q f1:
check inline

echo 'static inline void f2(); static inline void f1() { f2(); } static inline void f2() { f1(); } void foo() { f1(); }' | ./petitecc -o=- -S -x=c - | grep -q f2:
check inline

echo 'static inline void f2(); static inline void f1() { f2(); } static inline void f2() { f1(); } void foo() { f2(); }' | ./petitecc -o=- -S -x=c - | grep -q f1:
check inline

echo 'static inline void f2(); static inline void f1() { f2(); } static inline void f2() { f1(); } void foo() { f2(); }' | ./petitecc -o=- -S -x=c - | grep -q f2:
check inline

# -idirafter
mkdir -p $tmp/dir1 $tmp/dir2
echo foo > $tmp/dir1/idirafter
echo bar > $tmp/dir2/idirafter
echo "#include \"idirafter\"" | ./petitecc -I=$tmp/dir1 -I=$tmp/dir2 -E -x=c - | grep -q foo
check -idirafter
echo "#include \"idirafter\"" | ./petitecc -idirafter $tmp/dir1 -I=$tmp/dir2 -E -x=c - | grep -q bar
check -idirafter

# -fcommon
echo 'int foo;' | ./petitecc -S -o=- -x=c - | grep -q '\.comm foo'
check '-fcommon (default)'

echo 'int foo;' | ./petitecc -fcommon -S -o=- -x=c - | grep -q '\.comm foo'
check '-fcommon'

# -fno-common
echo 'int foo;' | ./petitecc -fno-common -S -o=- -x=c - | grep -q '^foo:'
check '-fno-common'

# -include
echo foo > $tmp/out.h
echo bar | ./petitecc -include $tmp/out.h -E -o=- -x=c - | grep -q -z 'foo.*bar'
check -include
echo NULL | ./petitecc -I=include -include stdio.h -E -o=- -x=c - | grep -q 0
check -include

# -x
echo 'int x;' | ./petitecc -c -x=c -o $tmp/foo.o -
check -xc
echo 'x:' | ./petitecc -c -x=assembler -o $tmp/foo.o -
check '-x assembler'

echo 'int x;' > $tmp/foo.c
./petitecc -c -x=assembler -x=none -o=$tmp/foo.o $tmp/foo.c
check '-x none'

# -E
echo foo | ./petitecc -E - | grep -q foo
check -E

# .a file
echo 'void foo() {}' | ./petitecc -c -x=c -o=$tmp/foo.o -
echo 'void bar() {}' | ./petitecc -c -x=c -o=$tmp/bar.o -
ar rcs $tmp/foo.a $tmp/foo.o $tmp/bar.o
echo 'void foo(); void bar(); int main() { foo(); bar(); }' > $tmp/main.c
./petitecc -o=$tmp/foo $tmp/main.c $tmp/foo.a
check '.a'

# .so file
echo 'void foo() {}' | cc -fPIC -c -xc -o $tmp/foo.o -
echo 'void bar() {}' | cc -fPIC -c -xc -o $tmp/bar.o -
cc -shared -o $tmp/foo.so $tmp/foo.o $tmp/bar.o
echo 'void foo(); void bar(); int main() { foo(); bar(); }' > $tmp/main.c
./petitecc -o=$tmp/foo $tmp/main.c $tmp/foo.so
check '.so'

# -M
echo '#include "out2.h"' > $tmp/out.c
echo '#include "out3.h"' >> $tmp/out.c
touch $tmp/out2.h $tmp/out3.h
./petitecc -M -I=$tmp $tmp/out.c | grep -q -z '^out.o: .*/out\.c .*/out2\.h .*/out3\.h'
check -M

# -MF
./petitecc -MF=$tmp/mf -M -I=$tmp $tmp/out.c
grep -q -z '^out.o: .*/out\.c .*/out2\.h .*/out3\.h' $tmp/mf
check -MF

# -MP
./petitecc -MF=$tmp/mp -MP -M -I=$tmp $tmp/out.c
grep -q '^.*/out2.h:' $tmp/mp
check -MP
grep -q '^.*/out3.h:' $tmp/mp
check -MP

# -MT
./petitecc -MT=foo -M -I=$tmp $tmp/out.c | grep -q '^foo:'
check -MT
./petitecc -MT=foo -MT=bar -M -I=$tmp $tmp/out.c | grep -q '^foo bar:'
check -MT

# -MD
echo '#include "out2.h"' > $tmp/md2.c
echo '#include "out3.h"' > $tmp/md3.c
(cd $tmp; $OLDPWD/petitecc -c -MD -I=. md2.c md3.c)
grep -q -z '^md2.o:.* md2\.c .* ./out2\.h' $tmp/md2.d
check -MD
grep -q -z '^md3.o:.* md3\.c .* ./out3\.h' $tmp/md3.d
check -MD

./petitecc -c -MD -MF $tmp/md-mf.d -I=. $tmp/md2.c
grep -q -z '^md2.o:.*md2\.c .*/out2\.h' $tmp/md-mf.d
check -MD

echo 'extern int bar; int foo() { return bar; }' | ./petitecc -fPIC -x=c -c -o=$tmp/foo.o -
cc -shared -o $tmp/foo.so $tmp/foo.o
echo 'int foo(); int bar=3; int main() { foo(); }' > $tmp/main.c
./petitecc -o=$tmp/foo $tmp/main.c $tmp/foo.so
check -fPIC

# #include_next
mkdir -p $tmp/next1 $tmp/next2 $tmp/next3
echo '#include "file1.h"' > $tmp/file.c
echo '#include_next "file1.h"' > $tmp/next1/file1.h
echo '#include_next "file2.h"' > $tmp/next2/file1.h
echo 'foo' > $tmp/next3/file2.h
./petitecc -I=$tmp/next1 -I=$tmp/next2 -I=$tmp/next3 -E $tmp/file.c | grep -q foo
check '#include_next'

# -static
echo 'extern int bar; int foo() { return bar; }' > $tmp/foo.c
echo 'int foo(); int bar=3; int main() { foo(); }' > $tmp/bar.c
./petitecc -static -o=$tmp/foo $tmp/foo.c $tmp/bar.c
check -static
file $tmp/foo | grep -q 'statically linked'
check -static

# -shared
echo 'extern int bar; int foo() { return bar; }' > $tmp/foo.c
echo 'int foo(); int bar=3; int main() { foo(); }' > $tmp/bar.c
./petitecc -fPIC -shared -o=$tmp/foo.so $tmp/foo.c $tmp/bar.c
check -shared

# -L
echo 'extern int bar; int foo() { return bar; }' > $tmp/foo.c
./petitecc -fPIC -shared -o=$tmp/libfoobar.so $tmp/foo.c
echo 'int foo(); int bar=3; int main() { foo(); }' > $tmp/bar.c
./petitecc -o=$tmp/foo -L=$tmp -l=foobar $tmp/bar.c 
check -L

# -Wl,
echo 'int foo() {}' | ./petitecc -c -o=$tmp/foo.o -x=c -
echo 'int foo() {}' | ./petitecc -c -o=$tmp/bar.o -x=c -
echo 'int main() {}' | ./petitecc -c -o=$tmp/baz.o -x=c -
./petitecc -Wl=-z,muldefs,--gc-sections -o=$tmp/foo $tmp/foo.o $tmp/bar.o $tmp/baz.o
check -Wl,

# -Xlinker
echo 'int foo() {}' | ./petitecc -c -o=$tmp/foo.o -x=c -
echo 'int foo() {}' | ./petitecc -c -o=$tmp/bar.o -x=c -
echo 'int main() {}' | ./petitecc -c -o=$tmp/baz.o -x=c -
./petitecc -Xlinker=-z -Xlinker=muldefs -Xlinker=--gc-sections -o=$tmp/foo $tmp/foo.o $tmp/bar.o $tmp/baz.o
check -Xlinker

echo OK
